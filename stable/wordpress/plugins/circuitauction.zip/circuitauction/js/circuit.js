/**
 * @file
 */
jQuery(document).ready(function ($) {

    $('#update-json-button').on('click', function(e) {
        e.preventDefault();
        $.post(
            ajax_object.ajax_url,
            {
                action: 'ca_sales_get_json_action',
                post_id: $('#post_ID').val(), // Get the current post ID
            },
            function(response) {
                alert('Server response: ' + response);
            }
        );
    });

});