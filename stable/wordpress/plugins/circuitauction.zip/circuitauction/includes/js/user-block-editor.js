(function() {
    const { registerBlockType } = wp.blocks;
    const { createElement } = wp.element;

    registerBlockType('circuit-auction/user-block', {
    title: 'User Block',
    icon: 'admin-users',
    category: 'circuit',
    attributes: {},

    edit: function(props) {
        return createElement(
            'div',
            { className: 'ca-user-block-preview' },
            createElement('h3', null, 'User Block'),
            createElement('div', { style: { background: '#f0f0f0', padding: '20px', textAlign: 'center' } },
                'User menu will render here'
            )
        );
    },

    save: function() {
        return null; // Use PHP render callback
    }
    });
})();
