(function() {
    const { registerBlockType } = wp.blocks;
    const { InspectorControls } = wp.editor;
    const { PanelBody, TextControl, SelectControl, ToggleControl } = wp.components;
    const { createElement, Fragment } = wp.element;
    const { Component } = wp.element;

    // Helper component to manage state for year generation
    class SalesArchiveEdit extends Component {
        constructor(props) {
            super(props);
            this.state = {
                years: []
            };
        }

        componentDidMount() {
            this.generateYears();
        }

        componentDidUpdate(prevProps) {
            // Regenerate years if first_year changes
            if (prevProps.attributes.first_year !== this.props.attributes.first_year) {
                this.generateYears();
            }
        }

        generateYears() {
            const { attributes } = this.props;
            const firstYear = parseInt(attributes.first_year);
            
            if (!firstYear || isNaN(firstYear)) {
                this.setState({ years: [] });
                return;
            }

            // Generate years from firstYear to current year + 45 days (like React component)
            const today = new Date();
            const futureDate = new Date(today);
            futureDate.setDate(today.getDate() + 45);
            const endYear = futureDate.getFullYear();

            const yearsArray = [];
            for (let year = endYear; year >= firstYear; year--) {
                yearsArray.push(year);
            }
            
            this.setState({ years: yearsArray });
        }

        render() {
            const { attributes, setAttributes } = this.props;
            const { years } = this.state;

            return createElement(
                Fragment,
                null,
                createElement(
                    InspectorControls,
                    null,
                    createElement(
                        PanelBody,
                        { title: 'Display Settings' },
                        
                        // DISPLAY MODE
                        createElement(SelectControl, {
                            label: 'Display Mode',
                            help: 'Choose how sales are displayed.',
                            value: attributes.display_mode,
                            onChange: (value) => setAttributes({ display_mode: value }),
                            options: [
                                { label: 'Default (User can toggle Grid/List)', value: '' },
                                { label: 'Grid (3 columns)', value: 'grid' },
                                { label: 'List (Full details)', value: 'list' },
                                { label: 'Minimal (Image + Title + Date)', value: 'minimal' }
                            ]
                        }),
                        
                        // SHOW FEATURED ITEMS
                        createElement(ToggleControl, {
                            label: 'Show Featured Items',
                            help: 'Display a carousel of featured items for each sale.',
                            checked: attributes.show_featured_items,
                            onChange: (value) => setAttributes({ show_featured_items: value })
                        }),
                        
                        // ITEM DISPLAY MODE - only show if featured items enabled
                        attributes.show_featured_items && createElement(SelectControl, {
                            label: 'Featured Items Display',
                            help: 'How featured items are shown in the carousel.',
                            value: attributes.item_display,
                            onChange: (value) => setAttributes({ item_display: value }),
                            options: [
                                { label: 'Full Display (title, pricing, gallery)', value: '' },
                                { label: 'Lot Number Only (minimal)', value: 'lot-number' }
                            ]
                        })
                    ),
                    
                    createElement(
                        PanelBody,
                        { title: 'Filter Settings', initialOpen: false },
                        
                        // REMOVE FILTERS TOGGLE
                        createElement(ToggleControl, {
                            label: 'Hide All Filters',
                            help: 'Remove the entire filter section from the page.',
                            checked: attributes.remove_filters,
                            onChange: (value) => setAttributes({ remove_filters: value })
                        }),
                        
                        // Only show filter options if remove_filters is false
                        !attributes.remove_filters && createElement(Fragment, null,
                            createElement('hr', { style: { margin: '16px 0' } }),
                            
                            // YEAR FILTER CONFIGURATION
                            createElement('h4', { style: { marginTop: '16px', marginBottom: '8px', fontSize: '13px', fontWeight: '600' } }, 'Year Filter'),
                            createElement(TextControl, {
                                label: 'Enable Year Filter (Starting Year)',
                                help: 'Enter a starting year (e.g., 2020) to show a year filter dropdown. Leave empty to hide year filter.',
                                value: attributes.first_year,
                                onChange: (value) => setAttributes({ first_year: value }),
                                placeholder: 'e.g., 2020',
                                type: 'number'
                            })
                        )
                    ),
                    
                    createElement(
                        PanelBody,
                        { title: 'Pre-Filter Sales (Hidden from Users)', initialOpen: false },
                        createElement('p', { 
                            style: { 
                                fontSize: '12px', 
                                color: '#666', 
                                marginTop: '0',
                                marginBottom: '16px',
                                padding: '8px',
                                background: '#f0f0f0',
                                borderRadius: '4px'
                            } 
                        },
                            '⚠️ These filters are applied automatically and completely hidden from users. Use these to create filtered views like "2024 Sales" or "Stamp Department Sales".'
                        ),
                        
                        // PRESET SEARCH
                        createElement(TextControl, {
                            label: 'Search Term',
                            help: 'Pre-filter sales by search term.',
                            value: attributes.search,
                            onChange: (value) => setAttributes({ search: value }),
                            placeholder: 'e.g., Chinese Art'
                        }),
                        
                        // PRESET YEAR - only show if first_year is set
                        years.length > 0 ? createElement(SelectControl, {
                            label: 'Specific Year',
                            help: 'Lock to a specific year and hide the year filter.',
                            value: attributes.year,
                            onChange: (value) => setAttributes({ year: value }),
                            options: [
                                { label: 'All Years (show filter)', value: '' },
                                ...years.map(year => ({ label: year.toString(), value: year.toString() }))
                            ]
                        }) : null,
                        
                        // PRESET DEPARTMENT - Simplified text input
                        createElement(TextControl, {
                            label: 'Department',
                            help: 'Pre-filter by department ID or name (e.g., "124" or "memorabilia"). Hides the department filter.',
                            value: attributes.department,
                            onChange: (value) => setAttributes({ department: value }),
                            placeholder: 'e.g., stamps or 124'
                        }),
                        
                        // PRESET STATUS
                        createElement(SelectControl, {
                            label: 'Status',
                            help: 'Pre-filter by sale status and hide the status filter.',
                            value: attributes.status,
                            onChange: (value) => setAttributes({ status: value }),
                            options: [
                                { label: 'All Sales (show filter)', value: '' },
                                { label: 'Both Active + Closed', value: 'both' },
                                { label: 'Active Sales Only', value: 'published_on_site' },
                                { label: 'Closed Sales Only', value: 'finished' }
                            ]
                        })
                    )
                ),
                createElement(
                    'div',
                    { className: 'ca-sales-archive-preview' },
                    createElement('h3', null, 'Sales List'),
                    createElement('div', { 
                        style: { 
                            background: '#f0f0f0', 
                            padding: '20px', 
                            textAlign: 'center',
                            borderRadius: '4px'
                        } 
                    },
                        'Sales List will render here',
                        createElement('br'),
                        createElement('small', { style: { color: '#666' } }, 'Configure settings in the sidebar →')
                    )
                )
            );
        }
    }

    registerBlockType('circuit-auction/sales-archive', {
        title: 'Sales List',
        icon: 'archive',
        category: 'circuit',
        attributes: {
            first_year: {
                type: 'string',
                default: ''
            },
            display_mode: {
                type: 'string',
                default: ''
            },
            remove_filters: {
                type: 'boolean',
                default: false
            },
            search: {
                type: 'string',
                default: ''
            },
            year: {
                type: 'string',
                default: ''
            },
            department: {
                type: 'string',
                default: ''
            },
            status: {
                type: 'string',
                default: ''
            },
            show_featured_items: {
                type: 'boolean',
                default: false
            },
            item_display: {
                type: 'string',
                default: ''
            }
        },

        edit: function(props) {
            return createElement(SalesArchiveEdit, props);
        },

        save: function() {
            return null; // Use PHP render callback
        }
    });
})();