(function() {
    const { registerBlockType } = wp.blocks;
    const { InspectorControls } = wp.editor;
    const { PanelBody, TextControl, SelectControl } = wp.components;
    const { createElement, Fragment } = wp.element;

    registerBlockType('circuit-auction/featured-items', {
    title: 'Featured Items',
    icon: 'star-filled',
    category: 'circuit',
    attributes: {
        sale_nid: {
            type: 'string',
            default: ''
        },
        display_mode: {
            type: 'string',
            default: ''
        }
    },

    edit: function(props) {
        const { attributes, setAttributes } = props;

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: 'Featured Items Settings' },
                    createElement(TextControl, {
                        label: 'Sale NID (Node ID)',
                        value: attributes.sale_nid,
                        onChange: (value) => setAttributes({ sale_nid: value }),
                        placeholder: 'e.g., 123 - leave empty for current published'
                    }),
                    createElement(SelectControl, {
                        label: 'Display Mode',
                        value: attributes.display_mode,
                        onChange: (value) => setAttributes({ display_mode: value }),
                        options: [
                            { label: 'Carousel Only (No Sale Info)', value: '' },
                            { label: 'Sale Image', value: 'sale-image' },
                            { label: 'Full Sale Info', value: 'sale-info' }
                        ]
                    })
                )
            ),
            createElement(
                'div',
                { className: 'ca-featured-items-preview' },
                createElement('h3', null, 'Featured Items'),
                createElement('p', null, 'Sale NID: ' + (attributes.sale_nid || 'Not set')),
                createElement('p', null, 'Display Mode: ' + (attributes.display_mode || 'Carousel only')),
                createElement('div', { style: { background: '#f0f0f0', padding: '20px', textAlign: 'center' } },
                    'Featured Items carousel will render here'
                )
            )
        );
    },

    save: function() {
        return null; // Use PHP render callback
    }
    });
})();
