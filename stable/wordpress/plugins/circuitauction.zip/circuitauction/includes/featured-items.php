<?php

// Widget class removed - use Gutenberg block instead

/**
 * Register block for Gutenberg editor
 */
function ca_register_featured_items_gutenberg_block() {
	if (!function_exists('register_block_type')) {
		return;
	}

	wp_register_script(
		'ca-featured-items-editor',
		plugins_url('js/featured-items-editor.js', __FILE__),
		['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
		'2.0.1'
	);

	register_block_type('circuit-auction/featured-items', [
		'editor_script' => 'ca-featured-items-editor',
		'render_callback' => 'ca_render_featured_items_block',
		'attributes' => [
			'sale_nid' => [
				'type' => 'string',
				'default' => ''
			],
			'display_mode' => [
				'type' => 'string',
				'default' => ''
			]
		]
	]);
}
add_action('init', 'ca_register_featured_items_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_featured_items_block($attributes) {
	$data_attrs = [];

	// Add data-sale-nid (required)
	if (!empty($attributes['sale_nid'])) {
		$data_attrs[] = 'data-sale-nid="' . esc_attr($attributes['sale_nid']) . '"';
	}

	// Add data-display-mode if set (sale-image|sale-info)
	if (!empty($attributes['display_mode'])) {
		$data_attrs[] = 'data-display-mode="' . esc_attr($attributes['display_mode']) . '"';
	}

	$data_attrs_string = implode(' ', $data_attrs);

	return '<div id="ca-featured-items" ' . $data_attrs_string . ' class="circuit-user-ui"></div>';
}
