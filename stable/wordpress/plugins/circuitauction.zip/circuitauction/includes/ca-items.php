<?php

define('SERVER_ITEM_STATUS_SOLD', 'sold');
define('SERVER_ITEM_STATUS_UNSOLD', 'unsold');
define('SERVER_ITEM_STATUS_CREDITED', 'credited');
/**
 * Indicate if an Item is up for sale (pre or post live sale).
 *
 * Originally, the status called `unknown` so we left the value as is but
 * changed the constant name and the label on the field.
 */
define('SERVER_ITEM_STATUS_UP_FOR_SALE', 'unknown');


/**
 *
 */
function ca_items_register_post_type() {
	$labels = [
		'name'                  => 'Items',
		'singular_name'         => 'Item',
		'add_new'               => 'Add New',
		'add_new_item'          => 'Add New Item',
		'edit_item'             => 'Edit Item',
		'new_item'              => 'New Item',
		'view_item'             => 'View Item',
		'view_items'            => 'View Items',
		'search_items'          => 'Search Items',
		'not_found'             => 'No items found',
		'not_found_in_trash'    => 'No items found in Trash',
		'parent_item_colon'     => 'Parent Item:',
		'all_items'             => 'All Items',
		'archives'              => 'Item Archives',
		'attributes'            => 'Item Attributes',
		'menu_name'             => 'Items',
		'filter_items_list'     => 'Filter items list',
		'items_list_navigation' => 'Items list navigation',
		'items_list'            => 'Items list',
	];

	$args = [
		'label'               => 'Item',
		'description'         => 'Item post type',
		'labels'              => $labels,
		'supports'            => [ 'title', 'editor', 'thumbnail' ],
		'hierarchical'        => FALSE,
		'public'              => TRUE,
		'show_ui'             => TRUE,
		'show_in_menu'        => TRUE,
		'menu_position'       => 5,
		'show_in_admin_bar'   => TRUE,
		'show_in_nav_menus'   => TRUE,
		'can_export'          => TRUE,
		'has_archive'         => FALSE,
		'exclude_from_search' => FALSE,
		'publicly_queryable'  => TRUE,
		'capability_type'     => 'post',
		'show_in_rest' => true,
		'rest_base' => 'item',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	];
	// Register the custom post type
	register_post_type( 'item', $args );
	flush_rewrite_rules();
}

add_action( 'init', 'ca_items_register_post_type', 0 );

/**
 * This function adds a new meta box to the post editor.
 */
function ca_items_add_meta_boxes() {
	add_meta_box( 'ca_items_meta_box', 'Item Meta Data', 'ca_items_meta_box_callback', 'item' );
}

add_action( 'add_meta_boxes', 'ca_items_add_meta_boxes' );

/**
 * Add form elements to the meta box.
 * This function displays the custom fields in the post editor.
 */
function ca_items_meta_box_callback( $post ) {
	$sale        = ca_items_get_custom_meta( $post->ID, 'sale', TRUE );
	$json_data   = ca_items_get_custom_meta( $post->ID, 'json_data', TRUE );
	$last_update = ca_items_get_custom_meta( $post->ID, 'last_update', TRUE );
	$uuid        = ca_items_get_custom_meta( $post->ID, 'uuid', TRUE );
	$sold_status = ca_items_get_custom_meta( $post->ID, 'sold_status', TRUE );
	$language    = ca_items_get_custom_meta( $post->ID, 'language', TRUE );

	echo '<label for="sale">Sale</label>';
	echo '<input id="sale" name="sale" type="text" value="' . esc_attr( $sale ) . '">';
	echo '<div></div><label for="last_update">Last Update</label>';
	echo '<input id="last_update" name="last_update" type="text" value="' . esc_attr( $last_update ) . '">';
	echo wp_date( 'Y-m-d H:i:s', $last_update) . '</div>';
	echo '<label for="uuid">UUID</label>';
	echo '<input id="uuid" name="uuid" type="text" value="' . esc_attr( $uuid ) . '">';
	echo '<label for="sold_status">Sold status</label>';
	echo '<input id="sold_status" name="sold_status" type="text" value="' . esc_attr( $sold_status ) . '">';
	echo '<label for="sale">Language</label>';
	echo '<input id="language" name="language" type="text" value="' . esc_attr( $language ) . '">';
	echo '<br><br>';
	echo '<label for="json_data">JSON Data</label>';
	// Display json using.
	d($json_data);
}

/**
 * @param $post_id
 * @param $meta_key
 *
 * @return mixed|string
 */
function ca_items_get_custom_meta($post_id, $meta_key) {
	global $wpdb;
	$table_name = $wpdb->prefix . 'itemmeta';

	$result = $wpdb->get_var($wpdb->prepare(
		"SELECT meta_value FROM $table_name WHERE post_id = %d AND meta_key = %s ORDER BY meta_id DESC LIMIT 1",
		$post_id,
		$meta_key
	));

	if ($result !== null) {
		return maybe_unserialize($result);
	} else {
		return '';
	}
}

/**
 * @param $post_id
 * @param $meta_key
 * @param $meta_value
 */
function ca_items_create_custom_meta_field($post_id, $meta_key, $meta_value, $type = 'insert') {
	global $wpdb;
	$table_name = $wpdb->prefix . 'itemmeta';

	// Serialize the value if it's an array or object
	$serialized_meta_value = maybe_serialize( $meta_value );
	// Insert or replace data.
	$wpdb->{$type}(
		$table_name,
		[
			'post_id'    => $post_id,
			'meta_key'   => $meta_key,
			'meta_value' => $serialized_meta_value
		],
		[ '%d', '%s', '%s' ]
	);
}

/**
 * Add a last_update column to the admin view for the "item" post type.
 */
function ca_add_last_update_column($columns) {
	$columns['last_update'] = 'Last Update';
	return $columns;
}
add_filter('manage_item_posts_columns', 'ca_add_last_update_column');

/**
 * Populate the new "last_update" column with data.
 */
function ca_populate_last_update_column($column_name, $post_id) {
	if ($column_name == 'last_update') {
		$last_update = ca_items_get_custom_meta($post_id, 'last_update', true);
		if (!empty($last_update)) {
			echo date('Y/m/d H:i:s', $last_update);
		}
	}
}
add_action('manage_item_posts_custom_column', 'ca_populate_last_update_column', 10, 2);

/**
 * Make the "last_update" column sortable.
 */
function ca_make_last_update_column_sortable($columns) {
	$columns['last_update'] = 'last_update';
	return $columns;
}
add_filter('manage_edit-item_sortable_columns', 'ca_make_last_update_column_sortable');


/**
 * This function saves the custom fields when the post is saved.
 *
 * @see ca_items_meta_box_callback();
 * @see ca_sales_meta_box_callback();
 */
function ca_items_save_meta_data( $post_id ) {
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return;
	}

	$post_type = get_post_type($post_id);

	// Check if it's the 'item' or 'sale' custom post type.
	if ('item' !== $post_type && 'sale' !== $post_type) {
		return;
	}

	// Check user permissions
	if (!current_user_can('edit_post', $post_id)) {
		return;
	}

	// Get all custom fields.
	switch ($post_type) {
		case 'item':
			$custom_fields = [
				// json_data is read only, so we don't process.
				'sale' => $_POST['sale'],
				'last_update' => $_POST['last_update'],
				'uuid' => $_POST['uuid'],
				'sold_status' => $_POST['sold_status'],
				'language' => $_POST['language'],
			];
			break;
		case 'sale':
			$custom_fields = [
				// json_data is read only, so we don't process.
				'last_update' => $_POST['last_update'],
				'uuid' => $_POST['uuid'],
				'language' => $_POST['language'],
				'nid' => $_POST['nid'],
			];
			break;
	}

	// Save all custom fields in the 'itemmeta' table
	foreach ($custom_fields as $meta_key => $meta_value) {
		ca_items_create_custom_meta_field($post_id, $meta_key, $meta_value,  'replace');
	}
}

add_action( 'save_post', 'ca_items_save_meta_data' );

/**
 * Remove the body field from the post editor.
 */
function ca_items_remove_body_field() {
	remove_post_type_support( 'item', 'editor' );
	remove_post_type_support( 'sale', 'editor' );
}

add_action( 'init', 'ca_items_remove_body_field' );

/**
 * Load js and css for Gallery.
 */
function ca_items_enqueue_load() {
	if (!in_array(get_post_type(), ['item', 'sale'])) {
		return;
	}
	// Add libraries for image gallery.
	// see https://github.com/alexanderdickson/waitForImages
	$base_path = '/wp-content/themes/ca-theme';
	wp_enqueue_script( 'waitforimages', $base_path . '/js/jquery.waitforimages.js', [], '1.0.0', TRUE );
	wp_enqueue_script( 'jquery.zoom', $base_path . '/js/jquery.zoom.min.js', [], '1.0.0', TRUE );
	wp_enqueue_script( 'photoswipe', $base_path . '/js/photoswipe.min.js', [], '1.0.0', TRUE );
	wp_enqueue_script( 'photoswipe-default', $base_path . '/js/photoswipe-ui-default.min.js', [], '1.0.0', TRUE );
	wp_enqueue_style( 'photoswipe-css', $base_path . '/css/photoswipe.min.css' );
	wp_enqueue_style( 'default-skin-css', $base_path . '/css/default-skin.min.css' );
	wp_enqueue_script( 'circuit-gallery-zoom', $base_path . '/js/circuit-gallery-zoom.js', [], '1.0.0', TRUE );
}

add_action( 'wp_enqueue_scripts', 'ca_items_enqueue_load' );

/**
 *
 */
function ca_items_recaptcha_script() {
	echo '<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?render=explicit" async defer></script>';
}
add_action( 'wp_head', 'ca_items_recaptcha_script' );

