<?php

define( 'SERVER_SALE_FLOW_STATUS_NEW', 'new' );
define( 'SERVER_SALE_FLOW_STATUS_READY_TO_PUBLISH', 'ready_to_publish' );
define( 'SERVER_SALE_FLOW_STATUS_PUBLISHED_ON_SITE', 'published_on_site' );
define( 'SERVER_SALE_FLOW_STATUS_FINISHED', 'finished' );
define( 'CA_SEARCH_API_DEFAULT_ITEM_PER_PAGE', 25 );

/**
 * This code creates a new post type called "Sale" with two extra fields.
 * "json_data" and "last_update" and "uuid". The fields are displayed in the
 * post editor and can be saved along with the post.
 */
function ca_sales_register_post_type() {
	$labels = [
		'name'                  => 'Sales',
		'singular_name'         => 'Sale',
		'add_new'               => 'Add New',
		'add_new_sale'          => 'Add New Sale',
		'edit_sale'             => 'Edit Sale',
		'new_sale'              => 'New Sale',
		'view_sale'             => 'View Sale',
		'view_sales'            => 'View Sales',
		'search_sales'          => 'Search Sales',
		'not_found'             => 'No sales found',
		'not_found_in_trash'    => 'No sales found in Trash',
		'parent_sale_colon'     => 'Parent Sale:',
		'all_sales'             => 'All Sales',
		'archives'              => 'Sale Archives',
		'attributes'            => 'Sale Attributes',
		'menu_name'             => 'Sales',
		'filter_sales_list'     => 'Filter sales list',
		'sales_list_navigation' => 'Sales list navigation',
		'sales_list'            => 'Sales list',
	];

	$args = [
		'label'               => 'Sale',
		'description'         => 'Sale post type',
		'labels'              => $labels,
		'supports'            => [ 'title', 'editor', 'thumbnail' ],
		'hierarchical'        => FALSE,
		'public'              => TRUE,
		'show_ui'             => TRUE,
		'show_in_menu'        => TRUE,
		'menu_position'       => 5,
		'show_in_admin_bar'   => TRUE,
		'show_in_nav_menus'   => TRUE,
		'can_export'          => TRUE,
		'has_archive'         => FALSE,
		'exclude_from_search' => FALSE,
		'publicly_queryable'  => TRUE,
		'capability_type'     => 'post',
	];
	// Register the custom post type
	register_post_type( 'sale', $args );
	flush_rewrite_rules();
}

add_action( 'init', 'ca_sales_register_post_type', 0 );

/**
 * This function adds a new meta box to the post editor.
 */
function ca_sales_add_meta_boxes() {
	add_meta_box( 'ca_sales_meta_box', 'Sale Meta Data', 'ca_sales_meta_box_callback', 'sale' );
}

add_action( 'add_meta_boxes', 'ca_sales_add_meta_boxes' );

/**
 * @return void
 */
function ca_sales_enqueue_custom_scripts() {
	wp_enqueue_script( 'ca-sales', plugins_url( 'circuitauction/js/circuit.js', '' ) );
	wp_localize_script( 'ca-sales', 'ajax_object', [ 'ajax_url' => admin_url( 'admin-ajax.php' ) ] );
}

add_action( 'admin_enqueue_scripts', 'ca_sales_enqueue_custom_scripts' );

/**
 * Create a button on sale edit page to manually update the json data.
 */
function handle_ca_sales_get_json_action() {
	$post_id = isset( $_POST['post_id'] ) ? intval( $_POST['post_id'] ) : 0;
	if ( $post_id > 0 ) {
		// Your server-side code here.
		ca_sync_update_sale_from_server( $post_id );
		echo "Success: Updated json $post_id";
	} else {
		echo "Error: Invalid post ID";
	}
	wp_die(); // All ajax handlers should die when finished
}

add_action( 'wp_ajax_ca_sales_get_json_action', 'handle_ca_sales_get_json_action' ); // For logged in users

/**
 * Add form elements to the meta box.
 * This function displays the custom fields in the post editor.
 */
function ca_sales_meta_box_callback( $post ) {
	$json_data   = ca_items_get_custom_meta( $post->ID, 'json_data' );
	$last_update = ca_items_get_custom_meta( $post->ID, 'last_update' );
	$uuid        = ca_items_get_custom_meta( $post->ID, 'uuid' );
	$sale_status = ca_items_get_custom_meta( $post->ID, 'sale_status' );
	$language    = ca_items_get_custom_meta( $post->ID, 'language' );
	$nid         = ca_items_get_custom_meta( $post->ID, 'nid' );

	echo '<label for="last_update">Last Update</label>';
	echo '<input id="last_update" name="last_update" type="text" value="' . esc_attr( $last_update ) . '">';
	echo wp_date( 'Y-m-d H:i:s', $last_update );
	echo '<label for="uuid">UUID</label>';
	echo '<input id="uuid" name="uuid" type="text" value="' . esc_attr( $uuid ) . '">';
	echo '<label for="sale_status">Sale status</label>';
	echo '<input id="sale_status" name="sale_status" type="text" value="' . esc_attr( $sale_status ) . '">';
	echo '<label for="nid">Node id in BO</label>';
	echo '<input id="nid" name="nid" type="text" value="' . esc_attr( $nid ) . '">';
	echo '<label for="sale">Language</label>';
	echo '<input id="language" name="language" type="text" value="' . esc_attr( $language ) . '">';
	echo '<br><br>';
	echo '<button id="update-json-button" class="button">Update Json</button>';
	echo '<label for="json_data">JSON Data</label>';
	// Display json using.
	d( $json_data );
}

/**
 * Search solr in BO server.
 *
 * @param $sale_id
 * @param $string_to_search
 * @param array $arguments
 *
 * https://backoffice.ddev.site/api/sale-search?filter[field_sale][value]=1600716&filter[language][value]=en&sort=field_lot_number
 *
 * @return string
 */
function ca_sale_search() {
	$arguments = $_GET;
	// Sanitize the arguments.
	foreach ( $arguments['filter'] as &$field ) {
		if ( isset( $field['value'] ) ) {
			$field['value'] = sanitize_text_field( $field['value'] );
		} elseif ( isset( $field['values'] ) ) {
			$field['values'] = sanitize_text_field( $field['values'] );
		}
	}
	$arguments['sort'] = sanitize_text_field( $arguments['sort'] );

	// Search string.
	$string_to_search = isset( $arguments['search'] ) ? sanitize_text_field( $arguments['search'] ) : '';
	unset( $arguments['search'] );

	// We use pager and not page, since WP uses page and remove it from the url.
	if ( isset( $arguments['pager'] ) ) {
		$arguments['page'] = $arguments['pager'];
		unset( $arguments['pager'] );
	}

	// Base url for the API.
	$url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/api/v1.0/sale-search/' . $string_to_search;

	$query_string = http_build_query( $arguments );
	if ( ! empty( $query_string ) ) {
		$url .= '?' . $query_string;
	}

	// Log the request URL.
	if ( get_option( 'ca_log_api_requests', FALSE ) ) {
		$msg = 'Search Request URL: <a href="' . $url . '">' . $url . '</a>';
		error_log( $msg );
		ca_set_custom_message( $msg );
	}

	// Set the request arguments, including the timeout.
	$request_args = [
		'timeout' => 30,
	];

	// Make the request.
	$result = wp_remote_get( $url, $request_args );

	if ( is_wp_error( $result ) ) {
		error_log( 'Search Error : ' . $result->get_error_message() );
		if ( get_option( 'ca_log_api_requests', FALSE ) ) {
			ca_set_custom_message( 'Search Error : ' . $result->get_error_message() );
		}
		$result = [];
	} else {
		$result = json_decode( $result['body'], TRUE );
	}

	$result['count'] = $result['count'] ?? '0';

	return $result;
}

/**
 * @param $term_id
 * @param $field_name
 * @param $self_url
 * @param false $remove
 *
 * @return string
 */
function ca_sale_get_facet_url( $term_id, $field_name, $self_url, $remove = FALSE ) {
	$arguments = $_GET;
	if ( $remove ) {
		$string_array = explode( ',', $arguments['filter'][ $field_name ]['values'] );
		if ( ( $key = array_search( $term_id, $string_array ) ) !== FALSE ) {
			unset( $string_array[ $key ] );
		}
		$arguments['filter'][ $field_name ]['values'] = implode( ',', $string_array );
	} else {
		// Multiple facets.
		$other_values = '';
		if ( ! empty( $arguments['filter'][ $field_name ]['values'] ) ) {
			$other_values = ",{$arguments['filter'][$field_name]['values']}";
		}
		$arguments['filter'][ $field_name ]['values']   = $term_id . $other_values;
		$arguments['filter'][ $field_name ]['operator'] = 'IN';
	}

	return $self_url . '?' . http_build_query( $arguments );
}

/**
 * @param $page_number
 * @param $self_url
 *
 * @return string
 */
function ca_sale_get_pager_url( $page_number, $self_url ) {
	$params          = $_GET;
	$params['pager'] = $page_number;

	return $self_url . '?' . http_build_query( $params );
}

/**
 * When in context or item, get sale parent.
 */
function ca_sale_get_current_sale_uuid() {
	if (!empty($id = ca_sale_get_active_sale_id())) {
		return ca_items_get_custom_meta($id, 'uuid');
	}
	return null;
}

/**
 * Get active sale ID.
 */
function ca_sale_get_active_sale_id() {
	return ca_sale_get_active_sale_uuid(true);
}

/**
 * Get active sale UUID.
 */
function ca_sale_get_active_sale_uuid($return_id = false) {
	global $post;
	// Check if we're on an item page
	if ($post && $post->post_type === 'item') {
		if ($return_id) {
			$id = ca_items_get_custom_meta(get_the_ID(), 'sale');
			return $id;
		}
		$variables = ca_items_get_custom_meta(get_the_ID(), 'json_data');
		return $variables->sale_uuid;
	}

	// Check for sale page - using explicit post type check
	if ($post && $post->post_type === 'sale') {
		if ($return_id) {
			return $post->ID;
		}
		return ca_items_get_custom_meta($post->ID, 'uuid');
	}

	// Fallback to first sale
	if ($id = ca_get_first_published_sale()) {
		if ($return_id) {
			return $id;
		}
		return ca_items_get_custom_meta($id, 'uuid');
	}

	return NULL;
}


function ca_get_first_published_sale() {
	global $wpdb;

	$query = "
    SELECT p.ID
    FROM {$wpdb->posts} AS p
    INNER JOIN {$wpdb->prefix}itemmeta AS m ON (p.ID = m.post_id)
    WHERE p.post_type = 'sale'
    AND p.post_status = 'publish'
    AND m.meta_key = 'sale_status'
    AND m.meta_value = 'published_on_site'
    ";

	$results = $wpdb->get_results( $query );

	if ( isset( $results[0]->ID ) ) {
		return $results[0]->ID;
	}

	return NULL;

}


/**
 * Search across all sales in BO server.
 * Uses same endpoint as ca_sale_search() but without field_sale filter
 *
 * @return array
 */
function ca_global_sale_search() {
	$arguments = $_GET;
	
	// Sanitize the arguments
	foreach ( $arguments['filter'] as &$field ) {
		if ( isset( $field['value'] ) ) {
			$field['value'] = sanitize_text_field( $field['value'] );
		} elseif ( isset( $field['values'] ) ) {
			$field['values'] = sanitize_text_field( $field['values'] );
		}
	}
	
	if (isset($arguments['sort'])) {
		$arguments['sort'] = sanitize_text_field( $arguments['sort'] );
	}

	// Search string
	$string_to_search = isset( $arguments['search'] ) ? sanitize_text_field( $arguments['search'] ) : '';
	unset( $arguments['search'] );

	// Handle pagination
	if ( isset( $arguments['pager'] ) ) {
		$arguments['page'] = $arguments['pager'];
		unset( $arguments['pager'] );
	}

	// Base url for the API - same endpoint as sale search but without field_sale filter
	$url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/api/v1.0/sale-search/' . $string_to_search;

	$query_string = http_build_query( $arguments );
	if ( ! empty( $query_string ) ) {
		$url .= '?' . $query_string;
	}

	// Log the request URL
	if ( get_option( 'ca_log_api_requests', FALSE ) ) {
		$msg = 'Global Search Request URL: <a href="' . $url . '">' . $url . '</a>';
		error_log( $msg );
		ca_set_custom_message( $msg );
	}

	// Set the request arguments, including the timeout
	$request_args = [
		'timeout' => 30,
	];

	// Make the request
	$result = wp_remote_get( $url, $request_args );

	if ( is_wp_error( $result ) ) {
		error_log( 'Global Search Error : ' . $result->get_error_message() );
		if ( get_option( 'ca_log_api_requests', FALSE ) ) {
			ca_set_custom_message( 'Global Search Error : ' . $result->get_error_message() );
		}
		$result = [];
	} else {
		$result = json_decode( $result['body'], TRUE );
	}

	$result['count'] = $result['count'] ?? '0';

	return $result;
}

/**
 * Get facet URL for global search
 *
 * @param $term_id
 * @param $field_name
 * @param $self_url
 * @param bool $remove
 *
 * @return string
 */
function ca_global_search_get_facet_url( $term_id, $field_name, $self_url, $remove = FALSE ) {
	$arguments = $_GET;
	
	if ( $remove ) {
		$string_array = explode( ',', $arguments['filter'][ $field_name ]['values'] );
		if ( ( $key = array_search( $term_id, $string_array ) ) !== FALSE ) {
			unset( $string_array[ $key ] );
		}
		$arguments['filter'][ $field_name ]['values'] = implode( ',', $string_array );
	} else {
		// Multiple facets
		$other_values = '';
		if ( ! empty( $arguments['filter'][ $field_name ]['values'] ) ) {
			$other_values = ",{$arguments['filter'][$field_name]['values']}";
		}
		$arguments['filter'][ $field_name ]['values']   = $term_id . $other_values;
		$arguments['filter'][ $field_name ]['operator'] = 'IN';
	}

	return $self_url . '?' . http_build_query( $arguments );
}