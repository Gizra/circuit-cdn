<?php

/**
 * Register block for Gutenberg editor
 */
function ca_register_sale_sessions_gutenberg_block() {
	if (!function_exists('register_block_type')) {
		return;
	}

	wp_register_script(
		'ca-sale-sessions-editor',
		plugins_url('js/sale-sessions-editor.js', __FILE__),
		['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
		'2.0.1'
	);

	register_block_type('circuit-auction/sale-sessions', [
		'editor_script' => 'ca-sale-sessions-editor',
		'render_callback' => 'ca_render_sale_sessions_block',
		'attributes' => [
			'sale_nid' => [
				'type' => 'string',
				'default' => ''
			]
		]
	]);
}
add_action('init', 'ca_register_sale_sessions_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_sale_sessions_block($attributes) {
	// Build the sale-info custom element
	if (!empty($attributes['sale_nid'])) {
		return '<div id="ca-sale-info" data-sale-nid="' . esc_attr($attributes['sale_nid']) . '" class="circuit-user-ui"></div>';
	}

	return '<div id="ca-sale-info"></div>';
}
