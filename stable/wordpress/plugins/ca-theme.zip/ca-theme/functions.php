<?php


/**
 * Enqueue your sub-theme's styleshee, this stylesheet is used for development
 * purpose.
 */
function ca_theme_enqueue_styles() {
	wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'parent-style' ) );
}
add_action( 'wp_enqueue_scripts', 'ca_theme_enqueue_styles' );


use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://cdn.circuitauction.com/stable/wordpress/plugins/theme.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'circuitauction'
);
