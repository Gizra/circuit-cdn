<?php
/**
 * The template for displaying single Item custom post type content.
 *
 * @package ca-theme
 */

$sale_id   = get_the_ID();
$sale_nid  = ca_items_get_custom_meta( $sale_id, 'nid' );

// Default to the first page of results.
if (empty($_GET)) {
	$_GET = [
		'sort'   => 'field_lot_number',
		'filter' => [
			'field_sale' => [
				'value' => $sale_nid,
			],
			'language'   => [
				'value' => 'en',
			],
		],
	];
}
$results = ca_sale_search();
$self_url = get_permalink();


// Set the query variable 'results' to be used in content-pager.php
set_query_var('results', $results);
set_query_var('self_url', $self_url);

?>

<header class="entry-header alignwide">
	<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
</header>

<main id="main" class="site-main alignwide">
    <div class="container">
        <h1 class="page-title">Search</h1>

	    <?php $parent_display = 0; ?>
	    <?php if (!empty($results['facets'])) : ?>
		    <?php foreach ($results['facets'] as $field_name => $facets) : ?>
                <div class="<?php echo $field_name; ?> ">
                    <h3><?php echo $field_name;?></h3>
                    <ul class="horizontal-list">
					    <?php foreach ($facets as $key => $term) : ?>
						    <?php if ($field_name == 'field_category' && $parent_display != $term['parent']) : ?>
							    <?php continue; ?>
						    <?php endif; ?>
                            <!--       Add remove facet link              -->
                            <?php $activated_facets = []; ?>
                            <?php if (isset($_GET['filter'][$field_name])) : ?>
                                <?php $activated_facets = array_flip(explode(',', $_GET['filter'][$field_name]['values'])); ?>
                            <?php endif; ?>
                            <?php if (isset($activated_facets[$term['tid']])) : ?>
                                <li>
                                    <a rel="nofollow" href="<?php echo ca_sale_get_facet_url($term['tid'], $field_name, $self_url, TRUE); ?>">
                                        <?php echo "(-)"; ?>
                                    </a>
                                    <?php echo "{$term['label']}"; ?>
                                </li>
                            <?php else : ?>
                                <li>
                                    <a rel="nofollow" href="<?php echo ca_sale_get_facet_url($term['tid'], $field_name, $self_url); ?>">
                                        <?php echo "{$term['label']} ({$term['count']})"; ?>
                                    </a>
                                </li>
                            <?php endif; ?>
					    <?php endforeach; ?>
                    </ul>
                </div>
		    <?php endforeach; ?>
	    <?php endif; ?>

        <form role="search" method="get" class="custom-search-form" action="<?php echo $self_url; ?>">
            <input type="text" name="search" placeholder="Search by text..." value="<?php echo $_GET['search'] ?? ''; ?>">
            <input type="text" name="filter[field_lot_number][value]" placeholder="Search by lot number..." value="<?php echo $_GET['filter']['field_lot_number']['value'] ?? ''; ?>">
            <input type="hidden" name="filter[field_sale][value]" value="<?php echo $sale_nid; ?>">
            <input type="hidden" name="filter[language][value]" value="<?php echo 'en'; ?>">
            <input type="hidden" name="sort" value="field_lot_number">
            <input type="submit" value="Search">
        </form>

	    <?php get_template_part('template-parts/content', 'pager'); ?>

        <?php
		if ( isset( $results ) ) :
			echo '<div class="search-results">';
			echo '<span class="search-count"> Found ' . $results['count'] . ' Results</span>';
            if ( isset( $results['data'] ) ) :
                foreach ( $results['data'] as $item_result) :
                    $item_id = ca_get_post_id_by_uuid($item_result['uuid']);
                    $item_post = get_post($item_id);
                    // Set up the global post data with your custom post
                    setup_postdata($GLOBALS['post'] = $item_post);

                    get_template_part( 'template-parts/content', 'single-item' );
                    // Reset the global post data after using setup_postdata()
                    wp_reset_postdata();
                endforeach;
		    endif;
			echo '</div>';
		endif;
		?>

	    <?php get_template_part('template-parts/content', 'pager'); ?>
    </div>
</main>