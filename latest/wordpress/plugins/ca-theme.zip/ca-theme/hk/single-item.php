<?php
/**
 * The template for displaying all single items.
 *
 * This template file starts with the standard header and footer for your theme,
 * and includes the main content loop for single items.
 * Inside the loop, the template calls the get_template_part() function, which
 * loads the template for the individual post content.
 * The the_post_navigation() function is used to display links to the previous
 * and next post.
 * If comments are enabled, the template calls the comments template.
 * You can then customize this template to suit your needs, for example you can
 * use the custom fields that you have created before by using the
 * get_post_meta() function.
 * Make sure to save the file and upload it to your server.
 * Once you have created the single-item.php template file, WordPress will
 * automatically use it to display the single view of the "Item" post type.
 * You can also use the template file to display the single view of the "Item"
 */

get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div id="content">
            <?php
            while ( have_posts() ) :

                the_widget( 'Ca_Sale_Catalog_Part_Block' );
                the_widget( 'Ca_Sale_Sessions_Block' );

                the_post();

                get_template_part( 'template-parts/content', 'single-item' );

                // the_post_navigation();

                // If comments are open or we have at least one comment, load up the comment template.
                if ( comments_open() || get_comments_number() ) :
                    comments_template();
                endif;

            endwhile; // End of the loop.
            ?>
        </div>
    </main><!-- #main -->
</div><!-- #primary -->

<!-- <?php //get_sidebar(); ?> -->
<?php get_footer(); ?>
