<?php
$results = get_query_var('results', []);
$self_url = get_query_var('self_url', '');
?>
<nav class="pagination">
    <ul class="pagination horizontal-pager">
        <?php
        // Get current page number from the query string
        $current_page = isset($_GET['pager']) ? (int)$_GET['pager'] : 0;
        
        // Calculate pagination values
        $total_results = isset($results['count']) ? (int)$results['count'] : 0;
        $max_per_page = $_GET['range'] ?? CA_SEARCH_API_DEFAULT_ITEM_PER_PAGE;
        $total_pages = ceil($total_results / $max_per_page);
        
        // First page link
        if ($current_page > 0) : ?>
            <li class="page-item">
                <a class="page-link" href="<?php echo ca_sale_get_pager_url(0, $self_url); ?>" aria-label="First">
                  <span >&laquo;&laquo; First</span>
                </a>
            </li>
        <?php endif; ?>

        <?php if (isset($results) && isset($results['previous'])) : ?>
            <li class="page-item">
                <a class="page-link" 
                   href="<?php echo ca_sale_get_pager_url($current_page - 1, $self_url); ?>" 
                   aria-label="Previous">
                    <span >&laquo; <?php echo $results['previous']['title']; ?></span>
                </a>
            </li>
        <?php endif; ?>

        <?php
        // Calculate the start and end pages for the direct links
        $start_page = max($current_page - 4, 0);
        $end_page = min($current_page + 4, $total_pages - 1);

        // Output the direct links
        for ($i = $start_page; $i <= $end_page; $i++) :
            $link_href = ca_sale_get_pager_url($i, $self_url);
            $link_title = $i + 1;
            $link_class = $i == $current_page ? 'active' : '';
        ?>
            <li class="page-item <?php echo $link_class; ?>">
                <?php if ($i !== $current_page) : ?>
                    <a class="page-link" href="<?php echo $link_href; ?>"><?php echo $link_title; ?></a>
                <?php else : ?>
                    <span class="page-link"><?php echo $link_title; ?></span>
                <?php endif; ?>
            </li>
        <?php endfor; ?>

        <?php if (isset($results) && isset($results['next']) && $current_page < $total_pages - 1) : ?>
					<li class="page-item">
						<a class="page-link"
							href="<?php echo ca_sale_get_pager_url($current_page + 1, $self_url); ?>"
							aria-label="Next">
							<span ><?php echo $results['next']['title']; ?> &raquo;</span>
						</a>
					</li>
				<?php endif; ?>

        <?php 
        // Last page link
        if ($current_page < $total_pages - 1) : ?>
            <li class="page-item">
                <a class="page-link" 
                   href="<?php echo ca_sale_get_pager_url($total_pages - 1, $self_url); ?>" 
                   aria-label="Last">
                    <span >Last &raquo;&raquo;</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>