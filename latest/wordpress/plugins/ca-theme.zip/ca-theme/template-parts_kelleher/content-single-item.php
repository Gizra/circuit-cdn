<?php
/**
 * The template for displaying single Item custom post type content.
 *
 * @package ca-theme
 */

$variables = ca_items_get_custom_meta( get_the_ID(), 'json_data' );
// Replace with dynamic language.
$language    = ca_items_get_custom_meta( get_the_ID(), 'language' );
$post_type   = get_query_var( 'post_type', '' );
$breadcrumbs = ca_items_breadcrumb( get_the_ID(), $variables, $language );
?>

<!--Data to be used in elm.js script -->
<?php if ( empty( $variables->withdrawn_hide ) && ! empty( $variables->item_pre_live_sale_embed ) ): ?>
  <div id="data-container-<?php the_ID(); ?>" class="data-container"
       style="display:none;"
       data-page="item_pre_live_sale"
       data-language="<?php print $language; ?>"
       data-sale-uuid="<?php print $variables->sale_uuid; ?>"
       data-item-uuid="<?php print $variables->uuid; ?>"
       data-base-host-url="<?php print home_url(); ?>"
       data-backend-url="<?php print $variables->bid_server_url; ?>"
       data-circuit-bid-url="<?php print $variables->bid_app_url; ?>"
       data-currency="<?php print get_option( 'ca_currency', 'EUR' ); ?>"
       data-site-short-name="<?php print $variables->site_short_name; ?>">
  </div>
<?php endif; ?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <header class="entry-header alignwide">
    <!--Display breadcrumbs -->
    <?php if ( ! empty( $breadcrumbs ) ): ?>
      <div class="breadcrumbs">
        <?php print $breadcrumbs; ?>
      </div>
    <?php endif; ?>

  </header><!-- .entry-header -->
  <div class="single-lot alignwide">
    <!--		--><?php //print $sale_info; ?>
    <div class="lot <?php print $variables->sold_status_class; ?>">
      <div class="first">
        <div class="lot-image">
          <?php if ( empty( $variables->withdrawn_hide ) ): ?>
            <?php get_template_part( 'template-parts/content', 'gallery' ); ?>
          <?php endif; ?>
        </div>
      </div>
      <div class="second">
        <?php if ( $post_type == 'sale' ): ?>
        <a href="<?php print the_permalink(); ?>">
          <?php endif; ?>
          <div class="lot-titles">
            <div class="title">
              <h4 class="lot-no">
                <span class="bold">Lot #:</span>
                <?php print sprintf( __( '%s', 'ca-text-domain' ), $variables->lot_number ?? '' ); ?>
                <?php if ( ! empty( $variables->$language->taxwarning ) ): ?>
                  <span class="item-dots">
                                    <?php print $variables->$language->taxwarning->dot; ?>
                                </span>
                  <div class="item-dot-text">
                    <?php print $variables->$language->taxwarning->message; ?>
                  </div>
                <?php endif; ?>
              </h4>
            </div>
            <h1 class="items-title">
              <?php print $variables->$language->title ?? ''; ?>
            </h1>
            <?php if ( ! empty( $variables->$language->subtitle ) ): ?>
              <div class="sub-title">
                <h5><?php print $variables->$language->subtitle; ?></h5>
              </div>
            <?php endif; ?>

            <?php if ( ! empty( $variables->withdrawn ) ): ?>
              <div class="withdrawn">
                <?php _e( 'Lot withdrawn from sale', 'ca-text-domain' ); ?>
              </div>
            <?php endif; ?>
          </div>
          <?php if ( $post_type == 'sale' ): ?>
        </a>
      <?php endif; ?>
        <div class="body">

          <?php if ( ! empty( $variables->publicMessage ?? FALSE ) ): ?>
            <div class="public-message">
              <?php print $variables->publicMessage; ?>
            </div>
          <?php endif; ?>

          <?php print $variables->$language->body ?? ''; ?>
        </div>

      </div>
      <div class="third">
        <div class="prices">
          <?php if ( empty( $variables->withdrawn_hide ?? FALSE ) ): ?>
            <div class="price">
              <span class="bold">Opening:</span>
              <?php echo sprintf( __( '%s', 'ca-text-domain' ), $variables->opening_price ); ?>
            </div>
          <?php endif; ?>
          <?php if ( ! empty( $variables->estimation ) ): ?>
            <div class="estimate">
              <span class="bold">Estimate:</span>
              <?php echo sprintf( __( '%s', 'ca-text-domain' ), $variables->estimation ); ?>
            </div>
          <?php endif; ?>
          <?php if ( ! empty( $variables->unsold ) ): ?>
            <div class="sold-for bold">
              <?php _e( 'Unsold', 'ca-text-domain' ); ?>
            </div>
          <?php elseif ( ! empty( $variables->soldfor ) ): ?>
            <div class="sold-for">
              <span class="bold">Sold for:</span>
              <?php echo sprintf( __( '%s', 'ca-text-domain' ), $variables->soldfor ); ?>
              <?php if ( ! empty( $variables->buyer_premium ) ): ?>
                <div class="buyer-premium">
                  <?php _e( "Including buyer's premium", 'ca-text-domain' ); ?>
                </div>
              <?php endif; ?>
            </div>
          <?php endif; ?>
        </div>
        <?php if ( empty( $variables->withdrawn_hide ) && ! empty( $variables->item_pre_live_sale_embed ) ): ?>
          <div class="bid-frame">
            <div id="<?php print $variables->uuid; ?>"></div>
          </div>
        <?php endif; ?>
        <div class="categories-symbols">
          <?php foreach ( $variables->$language->item_taxonomy as $row ): ?>
            <?php if ( ! empty( $row->rendered ) ): ?>
              <div class="<?php print $row->class_wrapper; ?> margin-bottom">
                                <span class="bold">
									<?php print $row->label; ?>:
                                </span>
                <?php print $row->rendered; ?>
              </div>
            <?php endif; ?>
          <?php endforeach; ?>

          <?php if ( ! empty( $variables->certificate_link ) ): ?>
            <div class="label certificate margin-bottom">
              <div class="bold float-left">Certificate:</div>
              <?php foreach ( $variables->certificate_link as $row ): ?>
                <?php if ( ! empty ( $row->url ) ): ?>
                  <a href="<?php print $row->url; ?>"
                     target="_blank">
                    <?php if ( ! empty ( $row->title ) ): ?>
                      <?php print $row->title; ?>
                    <?php else: ?>
                      <?php print $row->url; ?>
                    <?php endif; ?>
                  </a>
                <?php else: ?>
                  <?php print $row->title; ?>
                <?php endif; ?>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>

          <?php if ( ! empty( $variables->provenance ) ): ?>
            <div class="provenance margin-bottom">
              <span class="bold space-right">Provenance:</span>
              <?php print $variables->provenance; ?>
            </div>
          <?php endif; ?>

          <?php if ( ! empty( $variables->reference_link ) ): ?>
            <div class="label margin-bottom">
              <p class="bold float-left">References/Links:</p>
              <?php foreach ( $variables->reference_link as $row ): ?>
                <div>
                  <?php if ( ! empty ( $row->url ) ): ?>
                    <a href="<?php print $row->url; ?>"
                       target="_blank">
                      <?php if ( ! empty ( $row->title ) ): ?>
                        <?php print $row->title; ?>
                      <?php else: ?>
                        <?php print $row->url; ?>
                      <?php endif; ?>
                    </a>
                  <?php else: ?>
                    <?php print $row->title; ?>
                  <?php endif; ?>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>


        </div>
        <?php if ( $post_type == 'item' ): ?>
          <div class="lot-navigation">
            <?php if ( $variables->previous_lot ?? FALSE ): ?>
              <div class="lot-link"><a
                  href="<?php the_permalink( ca_get_post_id_by_uuid( $variables->previous_lot ) ); ?>"><?php _e( '<< Previous Lot', 'ca-text-domain' ); ?></a>
              </div>
            <?php endif; ?>
            <?php if ( $variables->next_lot ?? FALSE ): ?>
              <div class="lot-link"><a
                  href="<?php the_permalink( ca_get_post_id_by_uuid( $variables->next_lot ) ); ?>"><?php _e( 'Next Lot >>', 'ca-text-domain' ); ?></a>
              </div>
            <?php endif; ?>
          </div>

          <div class="sale-link">
            <a href="<?php the_permalink( ca_get_post_id_by_uuid( $variables->sale_uuid, 'sale' ) ); ?>"><?php _e( '<< Back to sale', 'ca-text-domain' ); ?></a>

          </div>
        <?php endif; ?>

        <?php if ( $post_type == 'sale' ): ?>
          <div class="lot-link">
            <a href="<?php print the_permalink(); ?>">
              <?php _e( 'View More Details', 'ca-text-domain' ); ?>
            </a>
          </div>
        <?php endif; ?>


      </div>

    </div>

    <!--            TODO:-->
    <!--        <div class="ask-about-item">-->
    <!--			--><?php //print $ask_about_link; ?>
    <!--        </div>-->
    <!---->
    <!--        <div class="sharelinks">-->
    <!--			--><?php //print render( $content['links'] ); ?>
    <!--        </div>-->


  </div>

</article><!-- #post-## -->
