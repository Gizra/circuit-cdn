<?php
/**
 * Template Name: Sales Archive
 * Template for displaying the sales archive page
 */

get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
        <div id="content">
            <?php
            // Include the sales archive functionality
            if (function_exists('ca_sales_archive_render')) {
                ca_sales_archive_render([
                    'range' => 10,
                    'display_mode' => 'minimal', // or 'full'
                    'status_filter' => 'both', // or 'published', 'finished'
                    'show_pagination' => true,
                    'show_results_count' => true,
                    'filters' => [
                        'search' => true,             // show/hide search input
                        'year' => true,               // show/hide year dropdown  
                        'department' => true,         // show/hide department dropdown
                        'status' => true,             // show/hide status dropdown
                        'per_page' => true,           // show/hide sales per page dropdown
                    ],
                    'show_filter_actions' => true,    // show/hide Apply/Clear buttons
                ]);

            } else {
                echo '<div class="error">Sales archive functionality not available. Make sure the plugin is activated and the ca-sales-archive.php file is included.</div>';
            }
            ?>
        </div>
    </main>
</div>

<?php get_footer(); ?>