<?php

/**
 * @var $pagename is a variable that is set in the page template using the name.
 */
/* Template Name: Pages elm */

?>

<?php get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
        <div id="content">
            <div id="<?php echo str_replace('-', '_', $pagename); ?>"></div>
		</div>
	</main>
</div>


<?php get_footer(); ?>
