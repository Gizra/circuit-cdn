<?php
/**
 * Template for displaying the global search page
 * Searches across all sales
 */

get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div id="content">
            <?php
            while ( have_posts() ) :
                the_post();
                
                get_template_part( 'template-parts/content', 'global-search' );

            endwhile; // End of the loop.
            ?>
        </div>
    </main><!-- #main -->
</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>