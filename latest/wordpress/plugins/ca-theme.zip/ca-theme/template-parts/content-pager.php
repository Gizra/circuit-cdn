<?php
$results = get_query_var('results', []);
$self_url = get_query_var('self_url', '');
?>

<nav class="pagination">
	<ul class="pagination horizontal-pager">
		<?php
		// Get current page number from the query string
		$current_page = isset($_GET['pager']) ? (int) $_GET['pager'] : 1;
		?>
		<?php if (isset($results) && isset($results['previous']) ) : ?>
			<li class="page-item">
				<a class="page-link" href="<?php echo ca_sale_get_pager_url($current_page - 1, $self_url); ?>" aria-label="Previous">
					<span aria-hidden="true">&laquo;</span>
					<span class="sr-only"><?php echo $results['previous']['title']; ?></span>
				</a>
			</li>
		<?php endif; ?>

		<?php
		// Calculate the number of pages based on the total results and the max items per page
		$total_results = isset($results['count']) ? (int) $results['count'] : 0;
		$max_per_page = 50;
		$total_pages = ceil($total_results / $max_per_page);

		// Calculate the start and end pages for the direct links
		$start_page = max($current_page - 2, 1);
		$end_page = min($current_page + 2, $total_pages);

		// Output the direct links
		for ($i = $start_page; $i <= $end_page; $i++) :
			$link_href  = ca_sale_get_pager_url($i, $self_url);
			$link_title = $i;
			$link_class = $i === $current_page ? 'active' : '';
			?>
			<li class="page-item <?php echo $link_class; ?>">
				<?php if ($i !== $current_page) : ?>
					<a class="page-link" href="<?php echo $link_href; ?>"><?php echo $link_title; ?></a>
				<?php else : ?>
					<span class="page-link"><?php echo $link_title; ?></span>
				<?php endif; ?>
			</li>
		<?php endfor; ?>

		<?php if (isset($results) && isset($results['next']) ) : ?>
			<li class="page-item">
				<a class="page-link" href="<?php echo ca_sale_get_pager_url($current_page + 1, $self_url); ?>" aria-label="Next">
					<span aria-hidden="true">&raquo;</span>
					<span class="sr-only"><?php echo $results['next']['title']; ?></span>
				</a>
			</li>
		<?php endif; ?>
	</ul>
</nav>