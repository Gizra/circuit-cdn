<?php
/**
 * The template for displaying single Item custom post type content.
 *
 * @package ca-theme
 */
$json_data = ca_items_get_custom_meta( get_the_ID(), 'json_data', TRUE );
// Get default language, this need to be replaced with dynamic language.
$language = ca_items_get_custom_meta( get_the_ID(), 'language', TRUE );
$images = $json_data->image_gallery ?? [];
if (!empty($images)) {
	$images_path = $images->images_path;
    $more_than_one_image = $images->more_than_one_image;
}
else {
	$images_path = [];
	$more_than_one_image = FALSE;
}

$alt = $json_data->$language->title ?? '';
$nid = $json_data->nid ?? '';

// Check that this is the first time we run on this loop.
// This is needed for grid view to prevent adding this code multiple times.
global $first_item;
if (empty($first_item)):
	$first_item = TRUE;
	?>
    <!-- Gallery used is: -->
    <!-- https://photoswipe.com/documentation/getting-started.html -->
    <!-- Root element of PhotoSwipe. Must have class pswp. -->
    <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

        <!-- Background of PhotoSwipe.
			 It's a separate element, as animating opacity is faster than rgba(). -->
        <div class="pswp__bg"></div>

        <!-- Slides wrapper with overflow:hidden. -->
        <div class="pswp__scroll-wrap">

            <!-- Container that holds slides. PhotoSwipe keeps only 3 slides in DOM to save memory. -->
            <!-- don't modify these 3 pswp__item elements, data is added later on. -->
            <div class="pswp__container">
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
                <div class="pswp__item"></div>
            </div>

            <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
            <div class="pswp__ui pswp__ui--hidden">

                <div class="pswp__top-bar">

                    <!--  Controls are self-explanatory. Order can be changed. -->

                    <div class="pswp__counter"></div>

                    <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>

                    <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>

                    <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>

                    <!-- Preloader demo https://codepen.io/dimsemenov/pen/yyBWoR -->
                    <!-- element will get class pswp__preloader--active when preloader is running -->
                    <div class="pswp__preloader">
                        <div class="pswp__preloader__icn">
                            <div class="pswp__preloader__cut">
                                <div class="pswp__preloader__donut"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                    <div class="pswp__share-tooltip"></div>
                </div>

                <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
                </button>

                <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
                </button>

                <div class="pswp__caption">
                    <div class="pswp__caption__center"></div>
                </div>

            </div>

        </div>

    </div>
<?php endif; ?>

<div data-nid="<?php print $nid; ?>" class="lot-images-carousel-wrapper">
    <div class="my-gallery" itemscope itemtype="http://schema.org/ImageGallery">
		<?php foreach ($images_path as $index => $image_path): ?>

            <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject"
                    data-image-id="<?php print $image_path->id; ?>"
                    class="current-zoomed-image <?php print $index == 0 ? 'active' : ''; ?>">
                <a href="<?php print $image_path->zoom; ?>" itemprop="contentUrl" data-size="<?php print $image_path->width;?>x<?php print $image_path->height;?>">
                    <img src="<?php print $image_path->big; ?>" itemprop="thumbnail" alt="Image description" />
                </a>
            </figure>
		<?php endforeach; ?>
    </div>

	<?php foreach ($images_path as $index => $image_path): ?>
        <div data-image-id="<?php print $image_path->id; ?>"
             class="current-zoomed-image <?php print $index == 0 ? 'active' : ''; ?>">
            <a download target="_blank" href="<?php print $image_path->zoom; ?>"
               class="secondary-action">
				<?php _e('Download picture', 'ca-text-domain'); ?>
            </a>
        </div>
	<?php endforeach; ?>

	<?php if ($more_than_one_image): ?>
        <div class="lot-image-thumbs">
			<?php foreach ($images_path as $index => $image_path): ?>
                <img zoom-url="<?php print $image_path->zoom; ?>"
                     data-preview="<?php print $image_path->big; ?>"
                     src="<?php print $image_path->big; ?>"
                     alt="<?php print $alt; ?>"
                     class="<?php print $index == 0 ? 'active' : ''; ?>"
                     id="<?php print $image_path->id_thumb; ?>"
                     data-nid="<?php print $nid; ?>"
                     data-big-id="<?php print $image_path->id; ?>"
                />
			<?php endforeach; ?>
        </div>
        <div class="images-count">
            <small>
                <?php
				$image_count = count($images_path);
				printf( _n( '1 PHOTO', '%s PHOTOS', $image_count, 'ca-text-domain' ), $image_count );
                ?>
            </small>
        </div>
	<?php endif; ?>
</div>
