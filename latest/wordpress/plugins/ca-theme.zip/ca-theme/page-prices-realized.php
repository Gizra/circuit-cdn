<?php
/**
 * Template for Prices Realized page
 */

get_header();

// Enqueue the CSS
ca_prices_realized_enqueue_styles();

// Render the prices realized page using the plugin function
ca_prices_realized_render([
    'title' => 'Prices Realized',
    'show_filters' => true,
    'show_pagination' => true,
    'columns' => 4,
]);

get_footer();
?>