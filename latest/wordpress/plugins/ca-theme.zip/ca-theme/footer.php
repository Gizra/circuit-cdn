<?php
/**
 * The template for displaying the footer
 */
?>
</div><!-- #content -->

<footer id="colophon" class="site-footer">
    <div class="site-info">
        <?php
            /* translators: %s: WordPress. */
            printf( esc_html__( 'Proudly powered by %s', 'your-theme-name' ), 'WordPress' );
            ?>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>