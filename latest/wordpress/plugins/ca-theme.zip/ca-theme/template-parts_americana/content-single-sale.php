<?php
/**
 * The template for displaying single Item custom post type content.
 *
 * @package ca-theme
 */

$sale_id                 = get_the_ID();
$sale_nid                = ca_items_get_custom_meta( $sale_id, 'nid' );
$json_data               = ca_items_get_custom_meta( $sale_id, 'json_data' );
$language                = ca_items_get_custom_meta( $sale_id, 'language' );

$default_number_of_items = CA_SEARCH_API_DEFAULT_ITEM_PER_PAGE;
// Default to the first page of results.
$_GET += [
	'sort'  => 'field_lot_number',
	'range' => $default_number_of_items,
];
if ( empty( $_GET['filter'] ) ) {
	$_GET['filter'] = [];
}
// Mer filters with defaults
$_GET['filter'] += [
	'field_sale' => [
		'value' => $sale_nid,
	],
	'language'   => [
		'value' => 'en',
	],
];

$results  = ca_sale_search();
$self_url = get_permalink();


// Set the query variable 'results' to be used in content-pager.php
set_query_var( 'results', $results );
set_query_var( 'self_url', $self_url );

?>
<script>
    // toggle row / grid display for items.
    jQuery(document).ready(function () {
        let saleViewMode = localStorage.getItem('sale_view_node') || 'grid';

        if (saleViewMode === 'list') {
            // Set list view.
            jQuery('.search-results')
                .addClass('row-view')
                .removeClass('grid-view');
        }

        jQuery('.fa-th').click(function () {
            jQuery('.search-results').removeClass('row-view');
            jQuery('.search-results').addClass('grid-view');
            localStorage.setItem('sale_view_node', 'grid');
        });
        jQuery('.fa-th-list').click(function () {
            jQuery('.search-results').addClass('row-view');
            jQuery('.search-results').removeClass('grid-view');
            localStorage.setItem('sale_view_node', 'list');
        });

        // Function to load the view mode from localStorage for a specific facet
        function loadFacetViewMode(facetName) {
            const storedViewMode = localStorage.getItem(`facet-collapse-${facetName}`);
            return storedViewMode || 'open'; // Default to 'open' if no stored view mode found
        }

        // Function to set the initial state based on the stored view mode
        function setInitialFacetState() {
            jQuery('.facet').each(function () {
                let $facet = jQuery(this);
                let facetName = $facet.find('.collapsible-toggle').text().trim().toLowerCase().replace(/\s+/g, '-');
                let facetViewMode = loadFacetViewMode(facetName);
                let $toggle = $facet.find('.collapsible-toggle');
                let $list = $facet.find('.horizontal-list');

                if (facetViewMode === 'open') {
                    $toggle.addClass('toggle-open');
                    $list.addClass('toggle-open');
                } else {
                    $toggle.removeClass('toggle-open');
                    $list.removeClass('toggle-open');
                }
            });
        }

        // Call the function to set the initial state
        setInitialFacetState();

        // Single click handler for toggling state
        jQuery('.collapsible-toggle').click(function () {
            let $toggle = jQuery(this);
            let $facet = $toggle.closest('.facet');
            let facetName = $toggle.text().trim().toLowerCase().replace(/\s+/g, '-');
            let $list = $facet.find('.horizontal-list');

            // Toggle the 'toggle-open' class on click
            $toggle.toggleClass('toggle-open');
            $list.toggleClass('toggle-open');

            // Update the facetViewMode based on whether the class is present
            let facetViewMode = $toggle.hasClass('toggle-open') ? 'open' : 'close';

            // Update localStorage with the new view mode
            localStorage.setItem(`facet-collapse-${facetName}`, facetViewMode);
        });


        var elements =
            '#edit-soldamount-wrapper,' +
            '#edit-status-wrapper,' +
            '#edit-my-favorites-wrapper,' +
            '#edit-openingprice-wrapper,' +
            '#edit-soldamount-wrapper,' +
            '#edit-per-page-wrapper,' +
            '#edit-sort-by-wrapper';

        var elementVisible = localStorage.getItem('search_element_visible') === 'true' || false;
        // Init hide class.
        if (elementVisible === false) {
            jQuery(elements).addClass('element-invisible');
            jQuery('.search-toggle').addClass('open');
        } else {
            jQuery('.custom-search-form').addClass('open');
        }

        jQuery('.search-toggle').click(function () {
            jQuery('.search-toggle').toggleClass('open');
            jQuery('.custom-search-form').toggleClass('open');
            jQuery(elements).toggleClass('element-invisible');
            if (elementVisible === false) {
                elementVisible = true;
            } else {
                elementVisible = false;
            }
            localStorage.setItem('search_element_visible', elementVisible);
        });

        // auto-submit code for select fields
        const selectElements = jQuery('.custom-search-form select');
        selectElements.on('change', function() {
            jQuery('.custom-search-form').submit();
        });
    });
</script>

<div class="entry-header alignwide">
    <h1 class="title"><?php print $json_data['sale'][$language]['title']; ?></h1>
	<?php if ( ! empty( $json_data['sale'][$language]['subtitle'] ) ): ?>
    <h2 class="sale-subtitle"><?php print $json_data['sale'][$language]['subtitle']; ?></h2>
	<?php endif; ?>
	<?php if ( ! empty( $json_data['sale'][$language]['body'] ) ): ?>
        <div class="sale-body">
            <?php print $json_data['sale'][$language]['body']; ?>
        </div>
    <?php endif; ?>
</div>
<header class="entry-header alignwide">
    <h1 class="title"><?php print $json_data->sale->$language->title; ?></h1>
	<?php if ( ! empty( $json_data->sale->$language->subtitle ) ): ?>
        <h2 class="sale-subtitle"><?php print $json_data->sale->$language->subtitle; ?></h2>
	<?php endif; ?>
	<?php if ( ! empty( $json_data->sale->$language->body ) ): ?>
        <div class="sale-body">
			<?php print $json_data->sale->$language->body; ?>
        </div>
	<?php endif; ?>
</header>

<main id="main" class="site-main alignwide">
    <div class="circuit-container">
		<?php $parent_display = 0; ?>
		<?php if ( ! empty( $results['facets'] ) ) : ?>
			<?php foreach ( $results['facets'] as $field_name => $facets ) : ?>
				<?php $field_display_name = $results['facets_titles'][$field_name]['title'] ?? '#'; ?>
                <div class="<?php echo $field_name; ?> facet">
                    <button class="collapsible-toggle" data-collapse-summary=""
                            aria-expanded="false">
						<?php echo $field_display_name; ?>
                        <i class="fa fa-plus"></i>
                        <i class="fa fa-minus"></i>
                    </button>
                    <ul class="horizontal-list <?php echo $field_name; ?>">
						<?php foreach ( $facets as $key => $term ) : ?>

                            <!--       Add remove facet link              -->
							<?php $activated_facets = []; ?>
							<?php if ( isset( $_GET['filter'][ $field_name ] ) ) : ?>
								<?php $activated_facets = array_flip( explode( ',', $_GET['filter'][ $field_name ]['values'] ) ); ?>
							<?php endif; ?>

							<?php if ( $field_name == 'field_category' && $parent_display != $term['parent'] && ! in_array( $term['tid'], $activated_facets ) )  : ?>
								<?php continue; ?>
							<?php endif; ?>

							<?php if ( isset( $activated_facets[ $term['tid'] ] ) ) : ?>
                                <li>
                                    <a rel="nofollow"
                                       href="<?php echo ca_sale_get_facet_url( $term['tid'], $field_name, $self_url, TRUE ); ?>">
										<?php echo "(-)"; ?>
                                    </a>
									<?php echo "{$term['label']}"; ?>
                                </li>
							<?php else : ?>
                                <li>
                                    <a rel="nofollow"
                                       href="<?php echo ca_sale_get_facet_url( $term['tid'], $field_name, $self_url ); ?>">
										<?php echo "{$term['label']} ({$term['count']})"; ?>
                                    </a>
                                </li>
							<?php endif; ?>
						<?php endforeach; ?>
                    </ul>
                </div>
			<?php endforeach; ?>
		<?php endif; ?>

        <form role="search" method="get" class="custom-search-form"
              action="<?php echo $self_url; ?>">
            <input type="hidden" name="filter[field_sale][value]"
                   value="<?php echo $sale_nid; ?>">
            <input type="hidden" name="filter[language][value]"
                   value="<?php echo 'en'; ?>">

            <div id="edit-field-lot-number-wrapper"
                 class="views-exposed-widget views-widget-filter-field_lot_number">
                <label for="edit-field-lot-number">Lot no</label>
                <div class="views-widget">
                    <div class="form-item form-type-textfield form-item-field-lot-number">
                        <input type="number" min="1" id="edit-field-lot-number"
                               name="filter[field_lot_number][value]"
                               value="<?php echo $_GET['filter']['field_lot_number']['value'] ?? ''; ?>"
                               size="30" maxlength="128" class="form-text"
                               data-twofas-input-listener="true"
                               data-twofas-element-number="2">
                    </div>
                </div>
            </div>
            <div id="edit-text-wrapper"
                 class="views-exposed-widget views-widget-filter-search_api_views_fulltext_1">
                <label for="edit-text">Search text</label>
                <div class="views-widget">
                    <div class="form-item form-type-textfield form-item-text">
                        <input type="text" id="edit-text" name="search"
                               value="<?php echo $_GET['search'] ?? ''; ?>"
                               size="30" maxlength="128" class="form-text"
                               data-twofas-input-listener="true"
                               data-twofas-element-number="3">
                    </div>
                </div>
            </div>
            <!---
            <div id="edit-status-wrapper"
                 class="views-exposed-widget views-widget-filter-status">
                <label for="edit-status">Sold Status</label>
                <div class="views-widget">
                    <div class="form-item form-type-select form-item-status">
                        <select id="edit-status" name="filter[status][value]"
                                class="form-select">
                            <option value="">- Any -</option>
                            <option value="sold" <?php echo ca_select_is_selected( 'sold', 'status' ); ?>>
                                Sold
                            </option>
                            <option value="unsold" <?php echo ca_select_is_selected( 'unsold', 'status' ); ?>>
                                Unsold
                            </option>
                        </select>
                    </div>
                </div>
            </div>
            --->
            <div id="edit-my-favorites-wrapper"
                 class="views-exposed-widget views-widget-filter-my_favorites">
                <label for="edit-my-favorites">My favorites</label>
                <div class="views-widget">
                    <div class="form-item form-type-select form-item-my-favorites">
                        <input type="hidden" name="bs_access_token" value="" id="access_token_field">
                        <select id="edit-my-favorites" name="filter[my_favorites][value]" class="form-select required">
                            <option value="0" <?php echo ca_select_is_selected( 0, 'my_favorites' ); ?>>
                                All
                            </option>
                            <option value="1" <?php echo ca_select_is_selected( 1, 'my_favorites' ); ?>>
                                Favorites
                            </option>
                        </select>

                    </div>
                </div>
            </div>
            <!---
            <div id="edit-openingprice-wrapper"
                 class="views-exposed-widget views-widget-filter-field_opening_price">
                <label for="edit-openingprice">Current Price</label>
                <div class="views-widget">
                    <div class="form-item form-type-textfield form-item-openingprice-min">
                        <input type="text" id="edit-openingprice-min"
                               name="filter[field_opening_price][min]"
                               value="<?php echo $_GET['filter']['field_opening_price']['min'] ?? ''; ?>"
                               size="30" maxlength="128" class="form-text"
                               data-twofas-input-listener="true"
                               data-twofas-element-number="4">
                    </div>
                    <div class="form-item form-type-textfield form-item-openingprice-max">
                        <label for="edit-openingprice-max">And </label>
                        <input type="text" id="edit-openingprice-max"
                               name="filter[field_opening_price][max]"
                               value="<?php echo $_GET['filter']['field_opening_price']['max'] ?? ''; ?>"
                               size="30" maxlength="128" class="form-text"
                               data-twofas-input-listener="true"
                               data-twofas-element-number="5">
                    </div>
                </div>
            </div>
            <div id="edit-soldamount-wrapper"
                 class="views-exposed-widget views-widget-filter-field_sold_for_amount">
                <label for="edit-soldamount">Sold For</label>
                <div class="views-widget">
                    <div class="form-item form-type-textfield form-item-soldamount-min">
                        <input type="text" id="edit-soldamount-min"
                               name="filter[field_sold_for_amount][min]"
                               value="<?php echo $_GET['filter']['field_sold_for_amount']['min'] ?? ''; ?>"
                               size="30" maxlength="128" class="form-text"
                               data-twofas-input-listener="true"
                               data-twofas-element-number="6">
                    </div>
                    <div class="form-item form-type-textfield form-item-soldamount-max">
                        <label for="edit-soldamount-max">And </label>
                        <input type="text" id="edit-soldamount-max"
                               name="filter[field_sold_for_amount][max]"
                               value="<?php echo $_GET['filter']['field_sold_for_amount']['max'] ?? ''; ?>"
                               size="30" maxlength="128" class="form-text"
                               data-twofas-input-listener="true"
                               data-twofas-element-number="7">
                    </div>
                </div>
            </div>
            --->

            <div id="edit-sort-by-wrapper"
                 class="views-exposed-widget views-widget-sort-by">
                <label for="edit-sort-by">Sort by </label>
                <div class="views-widget">
                    <div class="form-item form-type-select form-item-sort-by">
                        <select id="edit-sort-by" name="sort"
                                class="form-select">
                            <option value="field_lot_number" <?php echo ca_select_is_selected( 'field_lot_number', 'sort', FALSE ); ?>>
                                Lot number
                            </option>
                            <option value="-field_opening_price"<?php echo ca_select_is_selected( 'field_opening_price[desc]', 'sort', FALSE ); ?>>
                                Opening Price: High to Low
                            </option>
                            <option value="field_opening_price" <?php echo ca_select_is_selected( 'field_opening_price', 'sort', FALSE ); ?>>
                                Opening Price: Low to High
                            </option>
                            <option value="-field_sold_for_amount" <?php echo ca_select_is_selected( 'field_sold_for_amount[desc]', 'sort', FALSE ); ?>>
                                Sold For: High to Low
                            </option>
                            <option value="field_sold_for_amount" <?php echo ca_select_is_selected( 'field_sold_for_amount', 'sort', FALSE ); ?>>
                                Sold For: Low to High
                            </option>
                        </select>
                    </div>
                </div>
            </div>

            <div id="edit-per-page-wrapper"
                 class="views-exposed-widget views-widget-per-page">
                <label for="edit-items-per-page">Items per page </label>
                <div class="views-widget">
                    <div class="form-item form-type-select form-item-items-per-page">
                        <select id="edit-items-per-page" name="range"
                                class="form-select">
                            <option value="<?php echo $default_number_of_items; ?>" <?php echo ca_select_is_selected( $default_number_of_items, 'range', FALSE ); ?>><?php echo $default_number_of_items; ?></option>
                            <option value="25" <?php echo ca_select_is_selected( 25, 'range', FALSE ); ?>>
                                25
                            </option>
                            <option value="50" <?php echo ca_select_is_selected( 50, 'range', FALSE ); ?>>
                                50
                            </option>
                            <option value="100" <?php echo ca_select_is_selected( 100, 'range', FALSE ); ?>>
                                100
                            </option>
                            <option value="200" <?php echo ca_select_is_selected( 200, 'range', FALSE ); ?>>
                                200
                            </option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="views-submit-button">
                <input type="submit" id="edit-submit-sales-search"
                       value="Search" class="form-submit"
                       data-twofas-element-number="10">
            </div>
            <div class="views-reset-button">
                <a href="<?php the_permalink( $sale_id ); ?>" id="edit-reset"
                   class="form-submit" data-twofas-element-number="11">Reset</a>
            </div>
        </form>
        <div class="toggle-wrapper">
            <button class="search-toggle open">Advanced Search
                <i class="fa fa-plus"></i>
                <i class="fa fa-minus"></i>
            </button>
        </div>

		<?php
		if ( isset( $results ) ) :
			echo '
                <div class="sale-nav-top">
                    <div class="display-toggle">
                        <i class="fa fa-th"></i>
                        <i class="fa fa-th-list"></i>
                    </div>
                    <span class="search-count"> Found ' . $results['count'] . ' Results</span>
                </div>';

			get_template_part( 'template-parts/content', 'pager' );

			echo '<div class="search-results grid-view">';

			if ( isset( $results['data'] ) ) :

				$current_category = '';

				foreach ( $results['data'] as $item_result ) :

					// if new category print the category name

					$item_id = ca_get_post_id_by_uuid( $item_result['uuid'] );
					if ( empty( $item_id ) ) {
						echo "Item not synced.";
						continue;
					}
					$item_post = get_post( $item_id );
					$json_data = ca_items_get_custom_meta( $item_id, 'json_data' );
					$language = ca_items_get_custom_meta( $item_id, 'language' );

					$category = '';
					if (isset($json_data->$language->item_taxonomy)) {
						foreach ($json_data->$language->item_taxonomy as $taxonomy) {
							if ($taxonomy->class_wrapper === 'category') {
								$category = strip_tags($taxonomy->rendered);
								break;
							}
						}
					}

					// If category changes or it's the first item, display the category header
					if (!empty($category) && $category !== $current_category) {
						echo '<div class="category-header">' . esc_html($category) . '</div>';
						$current_category = $category;
					}

					// Set up the global post data with your custom post
					setup_postdata( $GLOBALS['post'] = $item_post );

					get_template_part( 'template-parts/content', 'single-item' );
					// Reset the global post data after using setup_postdata()
					wp_reset_postdata();
				endforeach;
			endif;
			echo '</div>';
		endif;
		?>

		<?php get_template_part( 'template-parts/content', 'pager' ); ?>
    </div>
</main>
