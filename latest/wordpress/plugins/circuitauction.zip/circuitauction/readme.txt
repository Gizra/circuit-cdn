=== Plugin Name ===
Contributors: CircuitAuction
Tags: auction, bidding, online auctions, e-commerce
Requires at least: 6.4
Tested up to: 6.4
Requires PHP: 8.0
Stable tag: 1.4
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integrates with Circuit Auctions

== Description ==

CircuitAuction plugin allows you to seamlessly connect your WordPress website with the Circuit Auction platform.
This integration enables you to manage auctions, display bidding information, and interact with the auction system
directly from your website.

== Installation ==

1. Upload `circuit-auction` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the plugin settings as needed.

== Changelog ==

= 1.1 =
* Support for multi language auctions.

= 1.0 =
* Initial release.


== Upgrade Notice ==

= 1.1 =
* Support for multi language auctions.
