(function() {
    const { registerBlockType } = wp.blocks;
    const { InspectorControls } = wp.editor;
    const { PanelBody, TextControl, RangeControl, ToggleControl } = wp.components;
    const { createElement, Fragment } = wp.element;

    registerBlockType('circuit-auction/prices-realized', {
    title: 'Prices Realized',
    icon: 'money-alt',
    category: 'circuit',
    attributes: {
        sale_nid: {
            type: 'string',
            default: ''
        },
        items_per_page: {
            type: 'number',
            default: 40
        },
        columns: {
            type: 'number',
            default: 4
        },
        show_filters: {
            type: 'boolean',
            default: true
        },
        show_lot_filter: {
            type: 'boolean',
            default: true
        },
        show_status_filter: {
            type: 'boolean',
            default: true
        },
        show_items_per_page: {
            type: 'boolean',
            default: true
        },
        show_pagination: {
            type: 'boolean',
            default: true
        },
        title: {
            type: 'string',
            default: ''
        }
    },

    edit: function(props) {
        const { attributes, setAttributes } = props;

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: 'General Settings' },
                    createElement(TextControl, {
                        label: 'Title',
                        value: attributes.title,
                        onChange: (value) => setAttributes({ title: value }),
                        placeholder: 'Prices Realized'
                    }),
                    createElement(TextControl, {
                        label: 'Sale nid',
                        value: attributes.sale_nid,
                        onChange: (value) => setAttributes({ sale_nid: value }),
                        placeholder: 'Leave empty to use URL'
                    }),
                    createElement(RangeControl, {
                        label: 'Items per page',
                        value: attributes.items_per_page,
                        onChange: (value) => setAttributes({ items_per_page: value }),
                        min: 10,
                        max: 100,
                        step: 10
                    }),
                    createElement(RangeControl, {
                        label: 'Number of Columns',
                        value: attributes.columns,
                        onChange: (value) => setAttributes({ columns: value }),
                        min: 1,
                        max: 4
                    })
                ),
                createElement(
                    PanelBody,
                    { title: 'Display Options' },
                    createElement(ToggleControl, {
                        label: 'Show Filters Section',
                        checked: attributes.show_filters,
                        onChange: (value) => setAttributes({ show_filters: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Lot Number Filter',
                        checked: attributes.show_lot_filter,
                        onChange: (value) => setAttributes({ show_lot_filter: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Status Filter',
                        checked: attributes.show_status_filter,
                        onChange: (value) => setAttributes({ show_status_filter: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Items Per Page Selector',
                        checked: attributes.show_items_per_page,
                        onChange: (value) => setAttributes({ show_items_per_page: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Pagination',
                        checked: attributes.show_pagination,
                        onChange: (value) => setAttributes({ show_pagination: value })
                    })
                )
            ),
            createElement(
                'div',
                { className: 'ca-prices-realized-preview' },
                createElement('h3', null, attributes.title || 'Prices Realized'),
                createElement('p', null, 'Sale nid: ' + (attributes.sale_nid || 'From URL')),
                createElement('div', { style: { background: '#f0f0f0', padding: '20px', textAlign: 'center' } },
                    'Prices Realized will render here - Configure settings in the sidebar'
                )
            )
        );
    },

    save: function() {
        return null; // Use PHP render callback
    }
    });
})();