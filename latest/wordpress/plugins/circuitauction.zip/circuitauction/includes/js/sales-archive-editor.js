const { registerBlockType } = wp.blocks;
const { InspectorControls } = wp.editor;
const { PanelBody, TextControl, SelectControl, ToggleControl, RangeControl } = wp.components;
const { createElement, Fragment } = wp.element;

registerBlockType('circuit-auction/sales-archive', {
    title: 'Sales Archive',
    icon: 'archive',
    category: 'widgets',
    attributes: {
        title: {
            type: 'string',
            default: 'Sales Archive'
        },
        limit: {
            type: 'number',
            default: 20
        },
        display_mode: {
            type: 'string',
            default: 'full'
        },
        status_filter: {
            type: 'string',
            default: 'both'
        },
        show_search: {
            type: 'boolean',
            default: true
        },
        show_year_filter: {
            type: 'boolean',
            default: true
        },
        show_department_filter: {
            type: 'boolean',
            default: true
        },
        show_status_filter: {
            type: 'boolean',
            default: true
        },
        show_pagination: {
            type: 'boolean',
            default: true
        },
        show_results_count: {
            type: 'boolean',
            default: true
        }
    },

    edit: function(props) {
        const { attributes, setAttributes } = props;

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: 'General Settings' },
                    createElement(TextControl, {
                        label: 'Title',
                        value: attributes.title,
                        onChange: (value) => setAttributes({ title: value })
                    }),
                    createElement(RangeControl, {
                        label: 'Items per page',
                        value: attributes.limit,
                        onChange: (value) => setAttributes({ limit: value }),
                        min: 5,
                        max: 50
                    }),
                    createElement(SelectControl, {
                        label: 'Display Mode',
                        value: attributes.display_mode,
                        options: [
                            { label: 'Full View', value: 'full' },
                            { label: 'Minimal View', value: 'minimal' }
                        ],
                        onChange: (value) => setAttributes({ display_mode: value })
                    }),
                    createElement(SelectControl, {
                        label: 'Status Filter',
                        value: attributes.status_filter,
                        options: [
                            { label: 'Both Published and Finished', value: 'both' },
                            { label: 'Published Only', value: 'published' },
                            { label: 'Finished Only', value: 'finished' }
                        ],
                        onChange: (value) => setAttributes({ status_filter: value })
                    })
                ),
                createElement(
                    PanelBody,
                    { title: 'Filter Options' },
                    createElement(ToggleControl, {
                        label: 'Show Search',
                        checked: attributes.show_search,
                        onChange: (value) => setAttributes({ show_search: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Year Filter',
                        checked: attributes.show_year_filter,
                        onChange: (value) => setAttributes({ show_year_filter: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Department Filter',
                        checked: attributes.show_department_filter,
                        onChange: (value) => setAttributes({ show_department_filter: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Status Filter',
                        checked: attributes.show_status_filter,
                        onChange: (value) => setAttributes({ show_status_filter: value })
                    })
                ),
                createElement(
                    PanelBody,
                    { title: 'Display Options' },
                    createElement(ToggleControl, {
                        label: 'Show Pagination',
                        checked: attributes.show_pagination,
                        onChange: (value) => setAttributes({ show_pagination: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Results Count',
                        checked: attributes.show_results_count,
                        onChange: (value) => setAttributes({ show_results_count: value })
                    })
                )
            ),
            createElement(
                'div',
                { className: 'ca-sales-archive-preview' },
                createElement('h3', null, attributes.title || 'Sales Archive'),
                createElement('p', null, `Display Mode: ${attributes.display_mode}`),
                createElement('p', null, `Items per page: ${attributes.limit}`),
                createElement('div', { style: { background: '#f0f0f0', padding: '20px', textAlign: 'center' } }, 
                    'Sales Archive Widget Preview - Configure settings in the sidebar'
                )
            )
        );
    },

    save: function() {
        return null; // Use PHP render callback
    }
});