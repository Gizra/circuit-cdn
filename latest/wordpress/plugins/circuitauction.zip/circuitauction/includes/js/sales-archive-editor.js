(function() {
    const { registerBlockType } = wp.blocks;
    const { InspectorControls } = wp.editor;
    const { PanelBody, TextControl, SelectControl, ToggleControl } = wp.components;
    const { createElement, Fragment } = wp.element;

    registerBlockType('circuit-auction/sales-archive', {
    title: 'Sales Archive',
    icon: 'archive',
    category: 'circuit',
    attributes: {
        first_year: {
            type: 'string',
            default: ''
        },
        display_mode: {
            type: 'string',
            default: ''
        },
        remove_filters: {
            type: 'boolean',
            default: false
        },
        search: {
            type: 'string',
            default: ''
        },
        year: {
            type: 'string',
            default: ''
        },
        department: {
            type: 'string',
            default: ''
        },
        status: {
            type: 'string',
            default: ''
        },
        show_featured_items: {
            type: 'boolean',
            default: false
        },
        item_display: {
            type: 'string',
            default: ''
        }
    },

    edit: function(props) {
        const { attributes, setAttributes } = props;

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: 'Display Settings' },
                    createElement(TextControl, {
                        label: 'First Year (enables year filter)',
                        value: attributes.first_year,
                        onChange: (value) => setAttributes({ first_year: value }),
                        placeholder: 'e.g., 2020'
                    }),
                    createElement(SelectControl, {
                        label: 'Display Mode',
                        value: attributes.display_mode,
                        onChange: (value) => setAttributes({ display_mode: value }),
                        options: [
                            { label: 'Default', value: '' },
                            { label: 'Grid', value: 'grid' },
                            { label: 'List', value: 'list' },
                            { label: 'Minimal', value: 'minimal' }
                        ]
                    }),
                    createElement(ToggleControl, {
                        label: 'Remove Filters (hide all filters)',
                        checked: attributes.remove_filters,
                        onChange: (value) => setAttributes({ remove_filters: value })
                    }),
                    createElement(ToggleControl, {
                        label: 'Show Featured Items',
                        checked: attributes.show_featured_items,
                        onChange: (value) => setAttributes({ show_featured_items: value })
                    }),
                    createElement(TextControl, {
                        label: 'Item Display Mode',
                        value: attributes.item_display,
                        onChange: (value) => setAttributes({ item_display: value }),
                        placeholder: 'e.g., compact, expanded'
                    })
                ),
                createElement(
                    PanelBody,
                    { title: 'Preset Filters (Hidden)' },
                    createElement(TextControl, {
                        label: 'Preset Search',
                        value: attributes.search,
                        onChange: (value) => setAttributes({ search: value }),
                        placeholder: 'Search term'
                    }),
                    createElement(TextControl, {
                        label: 'Preset Year',
                        value: attributes.year,
                        onChange: (value) => setAttributes({ year: value }),
                        placeholder: 'e.g., 2024'
                    }),
                    createElement(TextControl, {
                        label: 'Preset Department',
                        value: attributes.department,
                        onChange: (value) => setAttributes({ department: value }),
                        placeholder: 'Department name'
                    }),
                    createElement(TextControl, {
                        label: 'Preset Status',
                        value: attributes.status,
                        onChange: (value) => setAttributes({ status: value }),
                        placeholder: 'e.g., sold, unsold'
                    })
                )
            ),
            createElement(
                'div',
                { className: 'ca-sales-archive-preview' },
                createElement('h3', null, 'Sales Archive'),
                createElement('div', { style: { background: '#f0f0f0', padding: '20px', textAlign: 'center' } },
                    'Sales Archive will render here - Configure settings in the sidebar'
                )
            )
        );
    },

    save: function() {
        return null; // Use PHP render callback
    }
    });
})();
