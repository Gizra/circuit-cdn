const { registerBlockType } = wp.blocks;
const { InspectorControls } = wp.editor;
const { PanelBody, TextControl } = wp.components;
const { createElement, Fragment } = wp.element;

registerBlockType('circuit-auction/featured-items', {
    title: 'Featured Items',
    icon: 'calendar',
    category: 'widgets',
    attributes: {
        sale_uuid: {
            type: 'string',
            default: ''
        },
        title: {
            type: 'string',
            default: 'Session Details'
        }
    },

    edit: function(props) {
        const { attributes, setAttributes } = props;

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: 'Session Settings' },
                    createElement(TextControl, {
                        label: 'Title',
                        value: attributes.title,
                        onChange: (value) => setAttributes({ title: value })
                    }),
                    createElement(TextControl, {
                        label: 'Sale UUID',
                        value: attributes.sale_uuid,
                        onChange: (value) => setAttributes({ sale_uuid: value }),
                        placeholder: 'Leave empty for current sale'
                    })
                )
            ),
            createElement(
                'div',
                { className: 'ca-featured-items-preview' },
                'featured items Widget Preview'
            )
        );
    },

    save: function() {
        return null; // Use PHP render callback
    }
});