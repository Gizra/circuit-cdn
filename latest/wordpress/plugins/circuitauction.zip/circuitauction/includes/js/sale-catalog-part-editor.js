(function() {
  const { registerBlockType } = wp.blocks;
  const { InspectorControls } = wp.editor;
  const { PanelBody, SelectControl, TextControl } = wp.components;
  const { createElement, Fragment } = wp.element;

  registerBlockType('circuit-auction/sale-catalog-part', {
  title: 'Sale Catalog Part',
  icon: 'grid-view',
  category: 'circuit',
  attributes: {
    sale_id: {
      type: 'string',
      default: ''
    },
    catalog_part: {
      type: 'string',
      default: 'full'
    }
  },
  edit: function(props) {
    const { attributes, setAttributes } = props;

    return createElement(
      Fragment,
      null,
      createElement(
        InspectorControls,
        null,
        createElement(
          PanelBody,
          { title: 'Catalog Settings' },
          createElement(TextControl, {
            label: 'Sale NID (Node ID)',
            value: attributes.sale_id,
            onChange: (value) => setAttributes({ sale_id: value }),
            placeholder: 'e.g., 123 - leave empty for current published',
            required: true
          })
        )
      ),
      createElement(
        'div',
        { className: 'ca-sale-catalog-part' },
        createElement(
          'div',
          { style: { padding: '20px', textAlign: 'center' } },
          'Sale Catalog Part list: ',
          attributes.sale_id ? `Sale NID: ${attributes.sale_id}` : 'Missing Sale NID'
        )
      )
    );
  },
  save: function() {
    return null; // Use PHP render_callback instead
  }
  });
})();