jQuery(document).ready(function($) {
  function loadSaleSessions($element) {
    const saleId = $element.data('sale-id');

    $.ajax({
      url: caSaleSessions.ajaxUrl,
      type: 'POST',
      data: {
        action: 'ca_load_sale_sessions',
        nonce: caSaleSessions.nonce,
        sale_id: saleId
      },
      success: function(response) {
        if (response.success) {
          $element.html(response.data.html);
        } else {
          $element.html('<div class="ca-error">Error loading session data</div>');
        }
      },
      error: function() {
        $element.html('<div class="ca-error">Error loading session data</div>');
      }
    });
  }

  // Load session data for each block instance
  $('.ca-sale-sessions').each(function() {
    loadSaleSessions($(this));
  });
});