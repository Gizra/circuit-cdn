jQuery(document).ready(function($) {
    
    // Your existing AJAX loading function
    // Add this debugging to your loadFeaturedItems function
    function loadFeaturedItems($element) {
      const saleId = $element.data('sale-id');
      
      console.log('Loading featured items for sale ID:', saleId);
      console.log('AJAX URL:', caFeaturedItems.ajaxUrl);
      console.log('Nonce:', caFeaturedItems.nonce);
      
      $.ajax({
          url: caFeaturedItems.ajaxUrl,
          type: 'POST',
          data: {
              action: 'ca_load_featured_items',
              nonce: caFeaturedItems.nonce,
              sale_id: saleId
          },
          success: function(response) {
              console.log('AJAX Success - Full response:', response);
              
              if (response.success) {
                  console.log('Response data:', response.data);
                  $element.html(response.data.html);
                  setTimeout(function() {
                      initializeFeaturedItemsCarousel($element);
                  }, 100);
              } else {
                  console.error('AJAX returned error:', response.data);
                  $element.html('<div class="ca-error">Error: ' + (response.data.message || 'Unknown error') + '</div>');
              }
          },
          error: function(xhr, status, error) {
              console.error('AJAX Error Details:');
              console.error('Status:', status);
              console.error('Error:', error);
              console.error('Response Text:', xhr.responseText);
              console.error('Status Code:', xhr.status);
              
              $element.html('<div class="ca-error">AJAX Error: ' + error + ' (Status: ' + xhr.status + ')</div>');
          }
      });
    }

    // Initialize the main carousel system
    function initializeFeaturedItemsCarousel($container) {
        const $carousel = $container.find('.featured-items-carousel');
        const $track = $carousel.find('.carousel-track');
        const $items = $track.find('.featured-item');
        const $itemDots = $carousel.find('.item-nav-dot');
        const $progressCurrent = $carousel.find('.current-item');
        
        if ($items.length === 0) return;
        
        console.log(`Initializing main carousel with ${$items.length} items`);
        
        let currentItemIndex = 0;
        let itemCarousels = [];
        let mainCarouselTimer;
        
        // Initialize image carousels for each item
        $items.each(function(itemIndex) {
            const carousel = initializeItemImageCarousel($(this), itemIndex);
            itemCarousels.push(carousel);
        });
        
        // Show specific item
        function showItem(index) {
            console.log(`Showing main item ${index}`);
            
            // Move the track - each item is 100% of the carousel width
            const carouselWidth = $carousel.width();
            const translateX = -(index * carouselWidth);
            console.log(`Moving track by ${translateX}px (carousel width: ${carouselWidth}px)`);
            
            $track.css('transform', `translateX(${translateX}px)`);
            
            // Update navigation
            $itemDots.removeClass('active');
            $itemDots.eq(index).addClass('active');
            
            // Update progress
            $progressCurrent.text(index + 1);
            
            // Stop all image carousels except current
            itemCarousels.forEach((carousel, i) => {
                if (i === index) {
                    carousel.start();
                } else {
                    carousel.stop();
                }
            });
            
            currentItemIndex = index;
        }
        
        // Move to next item
        function nextItem() {
            const nextIndex = (currentItemIndex + 1) % $items.length;
            console.log(`Moving from item ${currentItemIndex} to ${nextIndex}`);
            showItem(nextIndex);
        }
        
        // Start the main carousel progression
        function startMainCarousel() {
            // Start with first item's image carousel
            if (itemCarousels[0]) {
                itemCarousels[0].start();
            }
        }
        
        // Handle item dot clicks
        $itemDots.on('click', function() {
            const itemIndex = $(this).data('item');
            showItem(itemIndex);
        });
        
        // Handle image carousel completion
        function onImageCarouselComplete(itemIndex) {
            console.log(`Image carousel completed for item ${itemIndex}`);
            
            // Move to next item after a brief pause
            setTimeout(() => {
                nextItem();
            }, 1000); // 1 second pause between items
        }
        
        // Initialize each item's image carousel with completion callback
        itemCarousels.forEach((carousel, index) => {
            carousel.onComplete = () => onImageCarouselComplete(index);
        });
        
        // Start the system
        showItem(0);
        startMainCarousel();
        
        // Pause on hover
        $carousel.on('mouseenter', function() {
            console.log('Pausing main carousel on hover');
            itemCarousels.forEach(carousel => carousel.pause());
        });
        
        $carousel.on('mouseleave', function() {
            console.log('Resuming main carousel after hover');
            if (itemCarousels[currentItemIndex]) {
                itemCarousels[currentItemIndex].resume();
            }
        });
    }
    
    // Initialize individual item's image carousel
    function initializeItemImageCarousel($item, itemIndex) {
        const $carousel = $item.find('.image-carousel');
        const $slides = $carousel.find('.image-slide');
        const $dots = $carousel.find('.dot');
        
        console.log(`Item ${itemIndex}: Found ${$slides.length} image slides`);
        
        if ($slides.length <= 1) {
            // Single image - complete immediately
            return {
                start: function() {
                    setTimeout(() => {
                        if (this.onComplete) this.onComplete();
                    }, 3000); // Show single image for 3 seconds
                },
                stop: function() {},
                pause: function() {},
                resume: function() {},
                onComplete: null
            };
        }
        
        let currentSlide = 0;
        let autoplayInterval;
        let isPaused = false;
        let isRunning = false;
        
        // Show specific slide
        function showSlide(index) {
            $slides.removeClass('active');
            $dots.removeClass('active');
            $slides.eq(index).addClass('active');
            $dots.eq(index).addClass('active');
            currentSlide = index;
            
            console.log(`Item ${itemIndex}: Showing image slide ${index}`);
        }
        
        // Next slide
        function nextSlide() {
            const nextIndex = (currentSlide + 1) % $slides.length;
            showSlide(nextIndex);
            
            // Check if we've completed the cycle
            if (nextIndex === 0 && carousel.onComplete) {
                console.log(`Item ${itemIndex}: Image carousel completed full cycle`);
                carousel.stop();
                carousel.onComplete();
            }
        }
        
        // Dot click handlers
        $dots.on('click', function() {
            const slideIndex = $(this).data('slide');
            showSlide(slideIndex);
        });
        
        const carousel = {
            start: function() {
                if (isRunning) return;
                console.log(`Item ${itemIndex}: Starting image carousel`);
                isRunning = true;
                isPaused = false;
                currentSlide = 0;
                showSlide(0);
                
                autoplayInterval = setInterval(() => {
                    if (!isPaused) {
                        nextSlide();
                    }
                }, 2000); // 2 seconds per image
            },
            
            stop: function() {
                console.log(`Item ${itemIndex}: Stopping image carousel`);
                isRunning = false;
                if (autoplayInterval) {
                    clearInterval(autoplayInterval);
                    autoplayInterval = null;
                }
            },
            
            pause: function() {
                console.log(`Item ${itemIndex}: Pausing image carousel`);
                isPaused = true;
            },
            
            resume: function() {
                console.log(`Item ${itemIndex}: Resuming image carousel`);
                isPaused = false;
            },
            
            onComplete: null
        };
        
        return carousel;
    }

    // Load featured items for each block instance
    $('.ca-featured-items').each(function() {
        loadFeaturedItems($(this));
    });
    
});