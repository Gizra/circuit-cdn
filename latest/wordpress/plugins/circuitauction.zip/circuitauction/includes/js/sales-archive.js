jQuery(document).ready(function($) {
    
    // Initialize view toggle functionality
    function initViewToggle() {
        const viewButtons = $('.view-btn');
        const archiveList = $('.ca-sales-archive-list');
        
        if (viewButtons.length === 0) return;
        
        viewButtons.on('click', function() {
            const view = $(this).data('view');
            
            // Update button states
            viewButtons.removeClass('active');
            $(this).addClass('active');
            
            // Update list classes
            archiveList.removeClass('ca-sales-archive-row ca-sales-archive-grid');
            archiveList.addClass('ca-sales-archive-' + view);
            
            // Store preference in sessionStorage
            sessionStorage.setItem('ca_sales_archive_view', view);
        });
        
        // Restore saved view preference
        const savedView = sessionStorage.getItem('ca_sales_archive_view');
        if (savedView) {
            const savedButton = $('.view-btn[data-view="' + savedView + '"]');
            if (savedButton.length) {
                savedButton.click();
            }
        }
    }
    
    // Initialize on page load
    initViewToggle();
    
    // Reinitialize after AJAX loads (if you add AJAX later)
    $(document).on('ca_sales_archive_loaded', function() {
        initViewToggle();
    });
    
});