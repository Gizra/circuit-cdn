jQuery(document).ready(function($) {
  function loadCatalogPart($element) {
    const saleId = $element.data('sale-id');

    $.ajax({
      url: caSaleCatalogPart.ajaxUrl,
      type: 'POST',
      data: {
        action: 'ca_load_sale_catalog_part',
        nonce: caSaleCatalogPart.nonce,
        sale_id: saleId
      },
      success: function(response) {
        if (response.success) {
          $element.html(response.data.html);
        } else {
          $element.html('<div class="ca-error">Error loading catalog data</div>');
        }
      },
      error: function() {
        $element.html('<div class="ca-error">Error loading catalog data</div>');
      }
    });
  }

  // Load catalog data for each block instance
  $('.ca-sale-catalog-part').each(function() {
    loadCatalogPart($(this));
  });
});