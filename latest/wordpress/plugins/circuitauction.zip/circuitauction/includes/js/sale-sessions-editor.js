(function() {
    const { registerBlockType } = wp.blocks;
    const { InspectorControls } = wp.editor;
    const { PanelBody, TextControl } = wp.components;
    const { createElement, Fragment } = wp.element;

    registerBlockType('circuit-auction/sale-sessions', {
    title: 'Sale Sessions',
    icon: 'info',
    category: 'circuit',
    attributes: {
        sale_nid: {
            type: 'string',
            default: ''
        }
    },

    edit: function(props) {
        const { attributes, setAttributes } = props;

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: 'Sale Sessions Settings' },
                    createElement(TextControl, {
                        label: 'Sale NID (Node ID)',
                        value: attributes.sale_nid,
                        onChange: (value) => setAttributes({ sale_nid: value }),
                        placeholder: 'e.g., 123 - leave empty for current published'
                    })
                )
            ),
            createElement(
                'div',
                { className: 'ca-sale-sessions-preview' },
                createElement('h3', null, 'Sale Sessions'),
                createElement('p', null, 'Sale NID: ' + (attributes.sale_nid || 'Not set')),
                createElement('div', { style: { background: '#f0f0f0', padding: '20px', textAlign: 'center' } },
                    'Sale sessions will render here'
                )
            )
        );
    },

    save: function() {
        return null; // Use PHP render callback
    }
    });
})();
