<?php

/**
 * Sale Catalog Part Block Class
 */
class Ca_Sale_Catalog_Part_Block extends WP_Widget {
	/**
	 * Initialize the widget
	 */
	public function __construct() {
		parent::__construct(
			'ca_sale_catalog_part', // Widget ID
			__('Circuit Auction - Sale Catalog Part', 'text_domain'), // Widget name in admin
			['description' => __('Display a specific part of the sale catalog', 'text_domain')]
		);
	}

	/**
	 * Frontend display of widget
	 */
	public function widget($args, $instance) {
		echo $args['before_widget'];

		if (!empty($instance['title'])) {
			echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
		}

		$sale_uuid = !empty($instance['sale_uuid']) ? $instance['sale_uuid'] : ca_sale_get_current_sale_uuid();
		$catalog_part = !empty($instance['catalog_part']) ? $instance['catalog_part'] : 'full';

		echo '<div id="ca-sale-catalog-part-' . esc_attr($catalog_part) . '" 
                   class="ca-sale-catalog-part" 
                   data-sale-uuid="' . esc_attr($sale_uuid) . '"
                   data-part="' . esc_attr($catalog_part) . '">';

		// Add loading state
		echo '<div class="ca-loading">Loading catalog data...</div>';
		echo '</div>';

		echo $args['after_widget'];
	}

	/**
	 * Backend widget form
	 */
	public function form($instance) {
		$title = !empty($instance['title']) ? $instance['title'] : '';
		$sale_uuid = !empty($instance['sale_uuid']) ? $instance['sale_uuid'] : '';
		$catalog_part = !empty($instance['catalog_part']) ? $instance['catalog_part'] : 'full';
		?>
      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
        <input class="widefat"
               id="<?php echo $this->get_field_id('title'); ?>"
               name="<?php echo $this->get_field_name('title'); ?>"
               type="text"
               value="<?php echo esc_attr($title); ?>">
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('sale_uuid'); ?>"><?php _e('Sale UUID:'); ?></label>
        <input class="widefat"
               id="<?php echo $this->get_field_id('sale_uuid'); ?>"
               name="<?php echo $this->get_field_name('sale_uuid'); ?>"
               type="text"
               value="<?php echo esc_attr($sale_uuid); ?>"
               placeholder="Leave empty for current sale">
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('catalog_part'); ?>"><?php _e('Catalog Part:'); ?></label>
        <select class="widefat"
                id="<?php echo $this->get_field_id('catalog_part'); ?>"
                name="<?php echo $this->get_field_name('catalog_part'); ?>">
          <option value="full" <?php selected($catalog_part, 'full'); ?>><?php _e('Full Catalog'); ?></option>
          <option value="featured" <?php selected($catalog_part, 'featured'); ?>><?php _e('Featured Items'); ?></option>
          <option value="upcoming" <?php selected($catalog_part, 'upcoming'); ?>><?php _e('Upcoming Items'); ?></option>
          <option value="recent" <?php selected($catalog_part, 'recent'); ?>><?php _e('Recently Added'); ?></option>
        </select>
      </p>
		<?php
	}

	/**
	 * Sanitize widget form values as they are saved
	 */
	public function update($new_instance, $old_instance) {
		$instance = [];
		$instance['title'] = (!empty($new_instance['title']))
			? strip_tags($new_instance['title'])
			: '';
		$instance['sale_uuid'] = (!empty($new_instance['sale_uuid']))
			? strip_tags($new_instance['sale_uuid'])
			: '';
		$instance['catalog_part'] = (!empty($new_instance['catalog_part']))
			? strip_tags($new_instance['catalog_part'])
			: 'full';
		return $instance;
	}
}

/**
 * Register the Sale Catalog Part widget
 */
function ca_register_sale_catalog_part_block() {
	register_widget('Ca_Sale_Catalog_Part_Block');
}
add_action('widgets_init', 'ca_register_sale_catalog_part_block');

/**
 * Enqueue necessary scripts and styles for the block
 */
function ca_enqueue_sale_catalog_part_assets() {
	wp_enqueue_style(
		'ca-sale-catalog-part-style',
		plugins_url('css/sale-catalog-part.css', __FILE__),
		[],
		'1.0.0'
	);

	wp_enqueue_script(
		'ca-sale-catalog-part-script',
		plugins_url('js/sale-catalog-part.js', __FILE__),
		['jquery'],
		'1.0.0',
		true
	);

	// Add localized script data
	wp_localize_script('ca-sale-catalog-part-script', 'caSaleCatalogPart', [
		'ajaxUrl' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('ca-sale-catalog-part-nonce'),
		'backendUrl' => get_option('ca_circuit_bid_backend_url', 'https://circuit-bid.ddev.site:4443'),
		'siteShortName' => get_option('ca_site_short_name', 'hk')
	]);
}
add_action('wp_enqueue_scripts', 'ca_enqueue_sale_catalog_part_assets');

/**
 * Register block for Gutenberg editor
 */
function ca_register_sale_catalog_part_gutenberg_block() {
	if (!function_exists('register_block_type')) {
		return;
	}

	wp_register_script(
		'ca-sale-catalog-part-editor',
		plugins_url('js/sale-catalog-part-editor.js', __FILE__),
		['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
		'1.0.0'
	);

	register_block_type('circuit-auction/sale-catalog-part', [
		'editor_script' => 'ca-sale-catalog-part-editor',
		'render_callback' => 'ca_render_sale_catalog_part_block',
		'attributes' => [
			'sale_uuid' => [
				'type' => 'string',
				'default' => ''
			],
			'catalog_part' => [
				'type' => 'string',
				'default' => 'full'
			]
		]
	]);
}
add_action('init', 'ca_register_sale_catalog_part_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_sale_catalog_part_block($attributes) {
	$sale_id = $attributes['sale_id'];

	ob_start();
	?>
  <div class="ca-sale-catalog-part"
       data-sale-id="<?php echo esc_attr($sale_id); ?>">
    <div class="ca-loading">Loading catalog data...</div>
  </div>
	<?php
	return ob_get_clean();
}

/**
 * AJAX handler for loading catalog data
 */
function ca_ajax_load_sale_catalog_part() {
	check_ajax_referer('ca-sale-catalog-part-nonce', 'nonce');

	$sale_id = isset($_POST['sale_id']) ? sanitize_text_field($_POST['sale_id']) : '';
	$sale_nid = ca_items_get_custom_meta($sale_id, 'nid');

	// Default to the first page of results
	$_GET += [
		'sort'  => 'field_lot_number',
    // we just need facets so one result is enough.
		'range' => 1,
	];

	$_GET['filter'] = [];
	// Merge filters with defaults
	$_GET['filter'] += [
		'field_sale' => [
			'value' => $sale_nid,
		],
		'language'   => [
			'value' => 'en',
		],
	];

	$results = ca_sale_search();
	$self_url = get_permalink($sale_id);

	ob_start();

  // debug info of $results
  // Debug search parameters
//  ca_debug([
//    'sale_id' => $sale_id,
//    'sale_nid' => $sale_nid,
//    'filters' => $_GET['filter'],
//    'sort' => $_GET['sort'],
//    'range' => $_GET['range']
//  ], 'Search Parameters');
	// No results handling
	if (empty($results['facets']) && empty($results['items'])) {
		?>
      <div class="ca-catalog-part">
        <div class="ca-error">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
          <p><?php _e('No catalog items found for this selection.', 'text_domain'); ?></p>
        </div>
      </div>
		<?php
		$html = ob_get_clean();
		wp_send_json_success([
			'html' => $html,
			'total_items' => 0,
		]);
		return;
	}

	// Render catalog parts
	$field_name = 'field_catalogue_part';
	if (!empty($results['facets'][$field_name])) {
		$field_display_name = $results['facets_titles'][$field_name]['title'] ?? __('Catalog Sections', 'text_domain');
		?>
      <div class="ca-catalog-part">
        <h3>
			<?php echo esc_html($field_display_name); ?>
          <span class="total-items"><?php printf(_n('(%d item)', '(%d items)', $results['total'], 'text_domain'), $results['total']); ?></span>
        </h3>
        <ul class="horizontal-list <?php echo esc_attr($field_name); ?>">
              <li>
                <a href="<?php echo esc_url(remove_query_arg('catalog_part', $self_url)); ?>"
                   class="view-all"
                   rel="nofollow">
					<?php _e('View All', 'text_domain'); ?>
                  <span class="count">(<?php echo esc_html($results['total']); ?>)</span>
                </a>
              </li>

			<?php foreach ($results['facets'][$field_name] as $term): ?>
              <li>
                <a href="<?php echo esc_url(ca_sale_get_facet_url($term['tid'], $field_name, $self_url)); ?>"
                   class="<?php echo $term['tid'] === $catalog_part ? 'active' : ''; ?>"
                   rel="nofollow">
					<?php echo esc_html($term['label']); ?>
                  <span class="count">(<?php echo esc_html($term['count']); ?>)</span>
                </a>
              </li>
			<?php endforeach; ?>
        </ul>
      </div>
		<?php
	}

	$html = ob_get_clean();

	wp_send_json_success([
		'html' => $html,
		'sale_id' => $sale_id,
		'total_items' => $results['total'] ?? 0,
	]);
}

add_action('wp_ajax_ca_load_sale_catalog_part', 'ca_ajax_load_sale_catalog_part');
add_action('wp_ajax_nopriv_ca_load_sale_catalog_part', 'ca_ajax_load_sale_catalog_part');