<?php

/**
 * Register block for Gutenberg editor
 */
function ca_register_sale_catalog_part_gutenberg_block() {
	if (!function_exists('register_block_type')) {
		return;
	}

	wp_register_script(
		'ca-sale-catalog-part-editor',
		plugins_url('js/sale-catalog-part-editor.js', __FILE__),
		['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
		'2.0.1'
	);

	register_block_type('circuit-auction/sale-catalog-part', [
		'editor_script' => 'ca-sale-catalog-part-editor',
		'render_callback' => 'ca_render_sale_catalog_part_block',
		'attributes' => [
			'sale_id' => [
				'type' => 'string',
				'default' => ''
			],
			'catalog_part' => [
				'type' => 'string',
				'default' => 'full'
			]
		]
	]);
}
add_action('init', 'ca_register_sale_catalog_part_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_sale_catalog_part_block($attributes) {
	$sale_post_id = !empty($attributes['sale_id']) ? $attributes['sale_id'] : ca_sale_get_active_sale_nid();
	$json_data = ca_get_sale_from_server($sale_post_id);

    $base_url = $json_data['sale']['url'];
    $filter_string = '?filter[field_catalogue_part][values]=';
    $filter_sufix = '&filter[field_catalogue_part][operator]=IN';
    $language_code = 'en';
	ob_start();

	if (empty($json_data['catalogue_part'])) {
		?>
		<div class="ca-catalog-part">
			<div class="ca-error">
				<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
					<circle cx="12" cy="12" r="10"></circle>
					<line x1="12" y1="8" x2="12" y2="12"></line>
					<line x1="12" y1="16" x2="12.01" y2="16"></line>
				</svg>
				<p><?php _e('No catalog parts found.', 'text_domain'); ?></p>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	// Render catalog parts from json_data
	?>
	<div class="ca-catalog-part">
		<div class="catalog-parts-grid">
			<?php foreach ($json_data['catalogue_part'] as $part_id => $part_data): ?>
                <?php $part_link = $base_url . $filter_string . urlencode($part_id) . $filter_sufix; ?>
				<div class="catalog-part-item">
					<?php if (!empty($part_data['image'])): ?>
						<div class="part-image">
							<img src="<?php echo esc_url($part_data['image']); ?>"
								 alt="<?php echo esc_attr($part_data['label'][$language_code] ?? ''); ?>">
						</div>
					<?php endif; ?>

					<div class="part-info">
						<?php if (!empty($part_data['label'][$language_code])): ?>
							<a href="<?php echo $part_link; ?>" class="part-title"><?php echo esc_html($part_data['label'][$language_code]); ?></a>
						<?php endif; ?>

						<?php if (!empty($part_data['pdf_link_url'])): ?>
							<a href="<?php echo esc_url($part_data['pdf_link_url']); ?>"
							   class="pdf-link"
							   target="_blank">
								<?php _e('View PDF', 'text_domain'); ?>
							</a>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php

	return ob_get_clean();
}

/**
 * AJAX handler for loading catalog data
 */
function ca_ajax_load_sale_catalog_part() {
	check_ajax_referer('ca-sale-catalog-part-nonce', 'nonce');

	$sale_post_id = isset($_POST['sale_id']) ? sanitize_text_field($_POST['sale_id']) : ca_sale_get_active_sale_nid();
	$json_data = ca_get_sale_from_server($sale_post_id);

	ob_start();

	if (empty($json_data['catalogue_part'])) {
		?>
        <div class="ca-catalog-part">
            <div class="ca-error">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                </svg>
                <p><?php _e('No catalog parts found.', 'text_domain'); ?></p>
            </div>
        </div>
		<?php
		$html = ob_get_clean();
		wp_send_json_success([
			'html' => $html,
			'total_items' => 0,
		]);
		return;
	}

	// Render catalog parts from json_data
	?>
    <div class="ca-catalog-part">
        <div class="catalog-parts-grid">
			<?php foreach ($json_data['catalogue_part'] as $part_id => $part_data): ?>
                <div class="catalog-part-item">
					<?php if (!empty($part_data['image'])): ?>
                        <div class="part-image">
                            <img src="<?php echo esc_url($part_data['image']); ?>"
                                 alt="<?php echo esc_attr($part_data['label']['en'] ?? ''); ?>">
                        </div>
					<?php endif; ?>

                    <div class="part-info">
						<?php if (!empty($part_data['label']['en'])): ?>
                            <h4 class="part-title"><?php echo esc_html($part_data['label']['en']); ?></h4>
						<?php endif; ?>

						<?php if (!empty($part_data['pdf_link_url'])): ?>
                            <a href="<?php echo esc_url($part_data['pdf_link_url']); ?>"
                               class="pdf-link"
                               target="_blank">
								<?php _e('View PDF', 'text_domain'); ?>
                            </a>
						<?php endif; ?>
                    </div>
                </div>
			<?php endforeach; ?>
        </div>
    </div>
	<?php

	$html = ob_get_clean();

	wp_send_json_success([
		'html' => $html,
		'sale_id' => $sale_post_id
	]);
}

add_action('wp_ajax_ca_load_sale_catalog_part', 'ca_ajax_load_sale_catalog_part');
add_action('wp_ajax_nopriv_ca_load_sale_catalog_part', 'ca_ajax_load_sale_catalog_part');