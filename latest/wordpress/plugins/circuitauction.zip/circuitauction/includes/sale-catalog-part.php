<?php

/**
 * Sale Catalog Part Block Class
 */
class Ca_Sale_Catalog_Part_Block extends WP_Widget {
	/**
	 * Initialize the widget
	 */
	public function __construct() {
		parent::__construct(
			'ca_sale_catalog_part', // Widget ID
			__('Circuit Auction - Sale Catalog Part', 'text_domain'), // Widget name in admin
			['description' => __('Display a specific part of the sale catalog', 'text_domain')]
		);
	}

	/**
	 * Frontend display of widget
	 */
	public function widget($args, $instance) {
		echo $args['before_widget'];

		if (!empty($instance['title'])) {
			echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
		}

		$sale_id = !empty($instance['sale_id']) ? $instance['sale_id'] : ca_sale_get_active_sale_id();
		$catalog_part = !empty($instance['catalog_part']) ? $instance['catalog_part'] : 'full';

		echo '<div id="ca-sale-catalog-part-' . esc_attr($catalog_part) . '" 
                   class="ca-sale-catalog-part" 
                   data-sale-id="' . esc_attr($sale_id) . '"
                   data-part="' . esc_attr($catalog_part) . '">';

		// Add loading state
		echo '<div class="ca-loading">Loading catalog data...</div>';
		echo '</div>';

		echo $args['after_widget'];
	}

	/**
	 * Backend widget form
	 */
	public function form($instance) {
		$title = !empty($instance['title']) ? $instance['title'] : '';
		$sale_id = !empty($instance['sale_id']) ? $instance['sale_id'] : '';
		$catalog_part = !empty($instance['catalog_part']) ? $instance['catalog_part'] : 'full';
		?>
      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
        <input class="widefat"
               id="<?php echo $this->get_field_id('title'); ?>"
               name="<?php echo $this->get_field_name('title'); ?>"
               type="text"
               value="<?php echo esc_attr($title); ?>">
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('sale_id'); ?>"><?php _e('Sale Post ID:'); ?></label>
        <input class="widefat"
               id="<?php echo $this->get_field_id('sale_id'); ?>"
               name="<?php echo $this->get_field_name('sale_id'); ?>"
               type="text"
               value="<?php echo esc_attr($sale_id); ?>"
               placeholder="Leave empty for current sale">
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('catalog_part'); ?>"><?php _e('Catalog Part:'); ?></label>
        <select class="widefat"
                id="<?php echo $this->get_field_id('catalog_part'); ?>"
                name="<?php echo $this->get_field_name('catalog_part'); ?>">
          <option value="full" <?php selected($catalog_part, 'full'); ?>><?php _e('Full Catalog'); ?></option>
          <option value="featured" <?php selected($catalog_part, 'featured'); ?>><?php _e('Featured Items'); ?></option>
          <option value="upcoming" <?php selected($catalog_part, 'upcoming'); ?>><?php _e('Upcoming Items'); ?></option>
          <option value="recent" <?php selected($catalog_part, 'recent'); ?>><?php _e('Recently Added'); ?></option>
        </select>
      </p>
		<?php
	}

	/**
	 * Sanitize widget form values as they are saved
	 */
	public function update($new_instance, $old_instance) {
		$instance = [];
		$instance['title'] = (!empty($new_instance['title']))
			? strip_tags($new_instance['title'])
			: '';
		$instance['sale_id'] = (!empty($new_instance['sale_id']))
			? strip_tags($new_instance['sale_id'])
			: '';
		$instance['catalog_part'] = (!empty($new_instance['catalog_part']))
			? strip_tags($new_instance['catalog_part'])
			: 'full';
		return $instance;
	}
}

/**
 * Register the Sale Catalog Part widget
 */
function ca_register_sale_catalog_part_block() {
	register_widget('Ca_Sale_Catalog_Part_Block');
}
add_action('widgets_init', 'ca_register_sale_catalog_part_block');

/**
 * Enqueue necessary scripts and styles for the block
 */
function ca_enqueue_sale_catalog_part_assets() {
	wp_enqueue_style(
		'ca-sale-catalog-part-style',
		plugins_url('css/sale-catalog-part.css', __FILE__),
		[],
		'1.0.0'
	);

	wp_enqueue_script(
		'ca-sale-catalog-part-script',
		plugins_url('js/sale-catalog-part.js', __FILE__),
		['jquery'],
		'1.0.0',
		true
	);

	// Add localized script data
	wp_localize_script('ca-sale-catalog-part-script', 'caSaleCatalogPart', [
		'ajaxUrl' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('ca-sale-catalog-part-nonce'),
		'backendUrl' => get_option('ca_circuit_bid_backend_url', 'https://circuit-bid.ddev.site:4443'),
		'siteShortName' => get_option('ca_site_short_name', 'hk')
	]);
}
add_action('wp_enqueue_scripts', 'ca_enqueue_sale_catalog_part_assets');

/**
 * Register block for Gutenberg editor
 */
function ca_register_sale_catalog_part_gutenberg_block() {
	if (!function_exists('register_block_type')) {
		return;
	}

	wp_register_script(
		'ca-sale-catalog-part-editor',
		plugins_url('js/sale-catalog-part-editor.js', __FILE__),
		['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
		'1.0.0'
	);

	register_block_type('circuit-auction/sale-catalog-part', [
		'editor_script' => 'ca-sale-catalog-part-editor',
		'render_callback' => 'ca_render_sale_catalog_part_block',
		'attributes' => [
			'sale_id' => [
				'type' => 'string',
				'default' => ''
			],
			'catalog_part' => [
				'type' => 'string',
				'default' => 'full'
			]
		]
	]);
}
add_action('init', 'ca_register_sale_catalog_part_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_sale_catalog_part_block($attributes) {
	$sale_id = $attributes['sale_id'];

	ob_start();
	?>
  <div class="ca-sale-catalog-part"
       data-sale-id="<?php echo esc_attr($sale_id); ?>">
    <div class="ca-loading">Loading catalog data...</div>
  </div>
	<?php
	return ob_get_clean();
}

/**
 * AJAX handler for loading catalog data
 */
/**
 * AJAX handler for loading catalog data
 */
function ca_ajax_load_sale_catalog_part() {
	check_ajax_referer('ca-sale-catalog-part-nonce', 'nonce');

	$sale_post_id = isset($_POST['sale_id']) ? sanitize_text_field($_POST['sale_id']) : ca_sale_get_active_sale_id();
	$json_data = ca_items_get_custom_meta($sale_post_id, 'json_data');

	ob_start();

	if (empty($json_data['catalogue_part'])) {
		?>
        <div class="ca-catalog-part">
            <div class="ca-error">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                </svg>
                <p><?php _e('No catalog parts found.', 'text_domain'); ?></p>
            </div>
        </div>
		<?php
		$html = ob_get_clean();
		wp_send_json_success([
			'html' => $html,
			'total_items' => 0,
		]);
		return;
	}

	// Render catalog parts from json_data
	?>
    <div class="ca-catalog-part">
        <div class="catalog-parts-grid">
			<?php foreach ($json_data['catalogue_part'] as $part_id => $part_data): ?>
                <div class="catalog-part-item">
					<?php if (!empty($part_data['image'])): ?>
                        <div class="part-image">
                            <img src="<?php echo esc_url($part_data['image']); ?>"
                                 alt="<?php echo esc_attr($part_data['label']['en'] ?? ''); ?>">
                        </div>
					<?php endif; ?>

                    <div class="part-info">
						<?php if (!empty($part_data['label']['en'])): ?>
                            <h4 class="part-title"><?php echo esc_html($part_data['label']['en']); ?></h4>
						<?php endif; ?>

						<?php if (!empty($part_data['pdf_link_url'])): ?>
                            <a href="<?php echo esc_url($part_data['pdf_link_url']); ?>"
                               class="pdf-link"
                               target="_blank">
								<?php _e('View PDF', 'text_domain'); ?>
                            </a>
						<?php endif; ?>
                    </div>
                </div>
			<?php endforeach; ?>
        </div>
    </div>
	<?php

	$html = ob_get_clean();

	wp_send_json_success([
		'html' => $html,
		'sale_id' => $sale_post_id
	]);
}

add_action('wp_ajax_ca_load_sale_catalog_part', 'ca_ajax_load_sale_catalog_part');
add_action('wp_ajax_nopriv_ca_load_sale_catalog_part', 'ca_ajax_load_sale_catalog_part');