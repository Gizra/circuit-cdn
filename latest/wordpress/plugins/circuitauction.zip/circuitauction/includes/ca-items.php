<?php

define( 'SERVER_ITEM_STATUS_SOLD', 'sold' );
define( 'SERVER_ITEM_STATUS_UNSOLD', 'unsold' );
define( 'SERVER_ITEM_STATUS_CREDITED', 'credited' );
/**
 * Indicate if an Item is up for sale (pre or post live sale).
 *
 * Originally, the status called `unknown` so we left the value as is but
 * changed the constant name and the label on the field.
 */
define( 'SERVER_ITEM_STATUS_UP_FOR_SALE', 'unknown' );


/**
 *
 */
function ca_items_register_post_type() {
	$labels = [
		'name'                  => 'Items',
		'singular_name'         => 'Item',
		'add_new'               => 'Add New',
		'add_new_item'          => 'Add New Item',
		'edit_item'             => 'Edit Item',
		'new_item'              => 'New Item',
		'view_item'             => 'View Item',
		'view_items'            => 'View Items',
		'search_items'          => 'Search Items',
		'not_found'             => 'No items found',
		'not_found_in_trash'    => 'No items found in Trash',
		'parent_item_colon'     => 'Parent Item:',
		'all_items'             => 'All Items',
		'archives'              => 'Item Archives',
		'attributes'            => 'Item Attributes',
		'menu_name'             => 'Items',
		'filter_items_list'     => 'Filter items list',
		'items_list_navigation' => 'Items list navigation',
		'items_list'            => 'Items list',
	];

	$args = [
		'label'                 => 'Item',
		'description'           => 'Item post type',
		'labels'                => $labels,
		'supports'              => [ 'title', 'editor', 'thumbnail' ],
		'hierarchical'          => FALSE,
		'public'                => TRUE,
		'show_ui'               => TRUE,
		'show_in_menu'          => TRUE,
		'menu_position'         => 5,
		'show_in_admin_bar'     => TRUE,
		'show_in_nav_menus'     => TRUE,
		'can_export'            => TRUE,
		'has_archive'           => FALSE,
		'exclude_from_search'   => FALSE,
		'publicly_queryable'    => TRUE,
		'capability_type'       => 'post',
		'show_in_rest'          => TRUE,
		'rest_base'             => 'item',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	];
	// Register the custom post type
	register_post_type( 'item', $args );
	flush_rewrite_rules();
}

add_action( 'init', 'ca_items_register_post_type', 0 );

/**
 * This function adds a new meta box to the post editor.
 */
function ca_items_add_meta_boxes() {
	add_meta_box( 'ca_items_meta_box', 'Item Meta Data', 'ca_items_meta_box_callback', 'item' );
}

add_action( 'add_meta_boxes', 'ca_items_add_meta_boxes' );

/**
 * Add form elements to the meta box.
 * This function displays the custom fields in the post editor.
 */
function ca_items_meta_box_callback( $post ) {
	$sale        = ca_items_get_custom_meta( $post->ID, 'sale', TRUE );
	$json_data   = ca_items_get_custom_meta( $post->ID, 'json_data', TRUE );
	$last_update = ca_items_get_custom_meta( $post->ID, 'last_update', TRUE );
	$uuid        = ca_items_get_custom_meta( $post->ID, 'uuid', TRUE );
	$sold_status = ca_items_get_custom_meta( $post->ID, 'sold_status', TRUE );
	$language    = ca_items_get_custom_meta( $post->ID, 'language', TRUE );

	echo '<label for="sale">Sale</label>';
	echo '<input id="sale" name="sale" type="text" value="' . esc_attr( $sale ) . '">';
	echo '<div></div><label for="last_update">Last Update</label>';
	echo '<input id="last_update" name="last_update" type="text" value="' . esc_attr( $last_update ) . '">';
	echo wp_date( 'Y-m-d H:i:s', $last_update ) . '</div>';
	echo '<label for="uuid">UUID</label>';
	echo '<input id="uuid" name="uuid" type="text" value="' . esc_attr( $uuid ) . '">';
	echo '<label for="sold_status">Sold status</label>';
	echo '<input id="sold_status" name="sold_status" type="text" value="' . esc_attr( $sold_status ) . '">';
	echo '<label for="sale">Language</label>';
	echo '<input id="language" name="language" type="text" value="' . esc_attr( $language ) . '">';
	echo '<br><br>';
	echo '<label for="json_data">JSON Data</label>';
	// Display json using.
	d( $json_data );
}

/**
 * @param $post_id
 * @param $meta_key
 *
 * @return mixed|string
 */
function ca_items_get_custom_meta( $post_id, $meta_key ) {
	global $wpdb;
	$table_name = $wpdb->prefix . 'itemmeta';

	$result = $wpdb->get_var( $wpdb->prepare(
		"SELECT meta_value FROM $table_name WHERE post_id = %d AND meta_key = %s ORDER BY meta_id DESC LIMIT 1",
		$post_id,
		$meta_key
	) );

	if ( $result !== NULL ) {
		return maybe_unserialize( $result );
	} else {
		return '';
	}
}

/**
 * @param $post_id
 * @param $meta_key
 * @param $meta_value
 */
function ca_items_create_custom_meta_field( $post_id, $meta_key, $meta_value, $type = 'insert' ) {
	global $wpdb;
	$table_name = $wpdb->prefix . 'itemmeta';

	// Serialize the value if it's an array or object
	$serialized_meta_value = maybe_serialize( $meta_value );
	// Insert or replace data.
	$wpdb->{$type}(
		$table_name,
		[
			'post_id'    => $post_id,
			'meta_key'   => $meta_key,
			'meta_value' => $serialized_meta_value,
		],
		[ '%d', '%s', '%s' ]
	);
}

/**
 * Add a last_update column to the admin view for the "item" post type.
 */
function ca_add_last_update_column( $columns ) {
	$columns['last_update'] = 'Last Update';

	return $columns;
}

add_filter( 'manage_item_posts_columns', 'ca_add_last_update_column' );

/**
 * Populate the new "last_update" column with data.
 */
function ca_populate_last_update_column( $column_name, $post_id ) {
	if ( $column_name == 'last_update' ) {
		$last_update = ca_items_get_custom_meta( $post_id, 'last_update', TRUE );
		if ( ! empty( $last_update ) ) {
			echo date( 'Y/m/d H:i:s', $last_update );
		}
	}
}

add_action( 'manage_item_posts_custom_column', 'ca_populate_last_update_column', 10, 2 );

/**
 * Make the "last_update" column sortable.
 */
function ca_make_last_update_column_sortable( $columns ) {
	$columns['last_update'] = 'last_update';

	return $columns;
}

add_filter( 'manage_edit-item_sortable_columns', 'ca_make_last_update_column_sortable' );


/**
 * This function saves the custom fields when the post is saved.
 *
 * @see ca_items_meta_box_callback();
 * @see ca_sales_meta_box_callback();
 */
function ca_items_save_meta_data( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	$post_type = get_post_type( $post_id );

	// Check if it's the 'item' or 'sale' custom post type.
	if ( 'item' !== $post_type && 'sale' !== $post_type ) {
		return;
	}

	// Check user permissions
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// Get all custom fields.
	switch ( $post_type ) {
		case 'item':
			$custom_fields = [
				// json_data is read only, so we don't process.
				'sale'        => $_POST['sale'],
				'last_update' => $_POST['last_update'],
				'uuid'        => $_POST['uuid'],
				'sold_status' => $_POST['sold_status'],
				'language'    => $_POST['language'],
			];
			break;
		case 'sale':
			$custom_fields = [
				// json_data is read only, so we don't process.
				'last_update' => $_POST['last_update'],
				'uuid'        => $_POST['uuid'],
				'language'    => $_POST['language'],
				'nid'         => $_POST['nid'],
			];
			break;
	}

	// Save all custom fields in the 'itemmeta' table
	foreach ( $custom_fields as $meta_key => $meta_value ) {
		ca_items_create_custom_meta_field( $post_id, $meta_key, $meta_value, 'replace' );
	}
}

add_action( 'save_post', 'ca_items_save_meta_data' );

/**
 * Remove the body field from the post editor.
 */
function ca_items_remove_body_field() {
	remove_post_type_support( 'item', 'editor' );
	remove_post_type_support( 'sale', 'editor' );
}

add_action( 'init', 'ca_items_remove_body_field' );

/**
 * Load js and css for Gallery.
 */
function ca_items_enqueue_load() {
	if ( ! in_array( get_post_type(), [ 'item', 'sale' ] ) ) {
		return;
	}
	// Add libraries for image gallery.
	// see https://github.com/alexanderdickson/waitForImages
	$base_path = '/wp-content/themes/ca-theme';
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'waitforimages', $base_path . '/js/jquery.waitforimages.js', [], '1.0.0', TRUE );
	wp_enqueue_script( 'jquery.zoom', $base_path . '/js/jquery.zoom.min.js', [], '1.0.0', TRUE );
	wp_enqueue_script( 'photoswipe', $base_path . '/js/photoswipe.min.js', [], '1.0.0', TRUE );
	wp_enqueue_script( 'photoswipe-default', $base_path . '/js/photoswipe-ui-default.min.js', [], '1.0.0', TRUE );
	wp_enqueue_style( 'photoswipe-css', $base_path . '/css/photoswipe.min.css' );
	wp_enqueue_style( 'default-skin-css', $base_path . '/css/default-skin.min.css' );
	wp_enqueue_script( 'circuit-gallery-zoom', $base_path . '/js/circuit-gallery-zoom.js', [], '1.0.0', TRUE );
}

add_action( 'wp_enqueue_scripts', 'ca_items_enqueue_load' );

/**
 *
 */
function ca_items_recaptcha_script() {
	echo '<script type="text/javascript" src="https://www.google.com/recaptcha/api.js?render=explicit" async defer></script>';
}

add_action( 'wp_head', 'ca_items_recaptcha_script' );


/**
 * Returns HTML for a breadcrumb for an exported item.
 *
 * @param WP_Post $post The post object for which the breadcrumb is being
 *     generated.
 *
 * @return string The HTML markup for the breadcrumb.
 */
function ca_items_breadcrumb( $post_id, $variables, $language ) {
	$breadcrumb_items = [
		'items' => [
			// 'Home' is default for all pages.
			'<a href="' . home_url( '/' ) . '">' . __( 'Home' ) . '</a>',
		],
	];

	// Add a link to the item's sale page.
	$sale_id                     = ca_items_get_custom_meta( $post_id, 'sale', TRUE );
	$sale_title                  = $variables->$language->sale_title;
	$breadcrumb_items['items'][] = '<a href="' . get_permalink( $sale_id ) . '">' . $sale_title . '</a>';

	// Add the item's type.
	if ( get_option( 'ca_sale_show_single_collection_facet', FALSE ) ) {
		$item_type_query_filter = [
			'field' => 'field_item_type',
			'value' => $variables->item_type,
		];
		ca_items_add_facet_link_to_breadcrumb( $breadcrumb_items, [ $item_type_query_filter ], $variables->item_type, $sale_id );
	}

	if ( ! empty( $variables->$language->item_taxonomy->field_category->data[0] ) ) {
		// Add the category's tree to the breadcrumb.
		// We reverse the order of the tree to display it from the root first.
		$category_tree = $variables->$language->item_taxonomy->field_category->ancestors;
		foreach ( $category_tree as $index => $category ) {
			$category_query_filters = [];

			// Filter by all category's tree so the facet will get the right
			// active links.
			$ids = [];
			for ( $i = $index; $i >= 0; $i -- ) {
				$ids[] = $category_tree[ $i ]->tid;
			}
			// Filter by all category's tree so the facet will get the right active links.
			$category_query_filters[] = [
				'field' => 'field_category',
				'value' => implode( ',', $ids ),
			];
			$category_name            = $category->name_field->{$language}[0]->value;
			ca_items_add_facet_link_to_breadcrumb( $breadcrumb_items, $category_query_filters, $category_name, $sale_id );
		}
	}

	// For items, use its title only.
	$title                       = sprintf( __( 'Lot %s' ), $variables->lot_number );
	$breadcrumb_items['items'][] = $title;

	return implode( ' &raquo; ', $breadcrumb_items['items'] );
}

/**
 * Helper function; Adding a facet link to a breadcrumb.
 *
 * This function meant to add a link that will filter a facet.
 *
 * @param array $breadcrumb
 *   The breadcrumb object.
 * @param array $query_filters
 *   All the filters that should be added to the link.
 * @param string $label
 *   The label of the link to be displayed in the facet.
 * @param int $sale_nid
 *   The sale's node ID we should link to.
 */
function ca_items_add_facet_link_to_breadcrumb( &$breadcrumb, $query_filters, $label, $sale_id ) {
	// Add a link to a sale's page with the active category in the facet.
	$base_url = get_permalink( $sale_id );
	$options  = [];
	foreach ( $query_filters as $filter ) {
		$options['filter'][ $filter['field'] ]['values']   = $filter['value'];
		$options['filter'][ $filter['field'] ]['operator'] = 'IN';
	}

	// Build the URL with query arguments
	$link = add_query_arg( $options, $base_url );

	// Wrap the URL with an anchor tag
	$link = '<a href="' . esc_url( $link ) . '">' . esc_html( $label ) . '</a>';

	// Prevent from having duplications in the breadcrumb.
	if ( in_array( $link, $breadcrumb['items'] ) ) {
		return;
	}

	$breadcrumb['items'][] = $link;
}
