<?php
/**
 * User Block (React Embed)
 *
 * Renders a div for the React user menu component
 */

/**
 * Register block for Gutenberg editor
 */
function ca_register_user_block_gutenberg_block() {
	if (!function_exists('register_block_type')) {
		return;
	}

	wp_register_script(
		'ca-user-block-editor',
		plugins_url('js/user-block-editor.js', __FILE__),
		['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
		'2.0.1'
	);

	register_block_type('circuit-auction/user-block', [
		'editor_script' => 'ca-user-block-editor',
		'render_callback' => 'ca_render_user_block',
		'attributes' => []
	]);
}
add_action('init', 'ca_register_user_block_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_user_block($attributes) {
	return '<div id="user-block"></div>';
}
