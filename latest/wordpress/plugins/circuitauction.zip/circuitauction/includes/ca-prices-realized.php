<?php
/**
 * Prices Realized Block (React Embed)
 *
 * Renders a div with data attributes for the React app to mount
 */

/**
 * Register block for Gutenberg editor
 */
function ca_register_prices_realized_gutenberg_block() {
    if (!function_exists('register_block_type')) {
        return;
    }

    wp_register_script(
        'ca-prices-realized-editor',
        plugins_url('js/prices-realized-editor.js', __FILE__),
        ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
        '2.0.1'
    );

    register_block_type('circuit-auction/prices-realized', [
        'editor_script' => 'ca-prices-realized-editor',
        'render_callback' => 'ca_render_prices_realized_block',
        'attributes' => [
            'sale_nid' => ['type' => 'string', 'default' => ''],
            'items_per_page' => ['type' => 'number', 'default' => 40],
            'columns' => ['type' => 'number', 'default' => 4],
            'show_filters' => ['type' => 'boolean', 'default' => true],
            'show_lot_filter' => ['type' => 'boolean', 'default' => true],
            'show_status_filter' => ['type' => 'boolean', 'default' => true],
            'show_items_per_page' => ['type' => 'boolean', 'default' => true],
            'show_pagination' => ['type' => 'boolean', 'default' => true],
            'title' => ['type' => 'string', 'default' => ''],
        ]
    ]);
}
add_action('init', 'ca_register_prices_realized_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_prices_realized_block($attributes) {
    $data_attrs = [];

    // Add data-sale-nid if set
    if (empty($attributes['sale_nid'])) {
	    $attributes['sale_nid'] = ca_sale_get_active_sale_nid();
    }
	$data_attrs[] = 'data-sale-nid="' . esc_attr($attributes['sale_nid']) . '"';

	// Add data-items-per-page
    if (!empty($attributes['items_per_page'])) {
        $data_attrs[] = 'data-items-per-page="' . esc_attr($attributes['items_per_page']) . '"';
    }

    // Add data-columns
    if (!empty($attributes['columns'])) {
        $data_attrs[] = 'data-columns="' . esc_attr($attributes['columns']) . '"';
    }

    // Add data-show-filters
    $data_attrs[] = 'data-show-filters="' . ($attributes['show_filters'] ? 'true' : 'false') . '"';

    // Add data-show-lot-filter
    $data_attrs[] = 'data-show-lot-filter="' . ($attributes['show_lot_filter'] ? 'true' : 'false') . '"';

    // Add data-show-status-filter
    $data_attrs[] = 'data-show-status-filter="' . ($attributes['show_status_filter'] ? 'true' : 'false') . '"';

    // Add data-show-items-per-page
    $data_attrs[] = 'data-show-items-per-page="' . ($attributes['show_items_per_page'] ? 'true' : 'false') . '"';

    // Add data-show-pagination
    $data_attrs[] = 'data-show-pagination="' . ($attributes['show_pagination'] ? 'true' : 'false') . '"';

    // Add data-title if set
    if (!empty($attributes['title'])) {
        $data_attrs[] = 'data-title="' . esc_attr($attributes['title']) . '"';
    }

    $data_attrs_string = implode(' ', $data_attrs);

    return '<div id="ca-prices-realized" ' . $data_attrs_string . '></div>';
}
?>