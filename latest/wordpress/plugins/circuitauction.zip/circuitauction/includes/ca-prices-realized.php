<?php
/**
 * Prices Realized functionality
 * 
 * Functions for fetching and displaying auction prices realized data
 */

/**
 * Enqueue prices realized CSS
 */
function ca_prices_realized_enqueue_styles() {
    wp_enqueue_style('ca-prices-realized', plugin_dir_url(__FILE__) . 'css/prices-realized.css', [], '2.0.0');
}

/**
 * Fetch prices realized data from the API
 * 
 * @param string $sale_uuid The sale UUID to fetch data for
 * @param array $filters Optional filters array
 * @return array|false API response data or false on error
 */
function ca_get_prices_realized_data($sale_uuid, $filters = []) {
	$base_url = get_option('ca_bo_base_url', 'https://backoffice.ddev.site');
	$api_url = $base_url . '/api/v1.0/items-public';
	
	$params = [
		'fields' => 'lot,opening_price,sold_price,sold_status',
		'sale_uuid' => $sale_uuid,
		'range' => isset($filters['range']) ? $filters['range'] : 40,
	];
	
	// Add pagination
	if (isset($filters['page']) && $filters['page'] > 1) {
		$params['page'] = $filters['page'];
	}
	
	// Add filters if provided
	if (isset($filters['sold_status'])) {
		$params['filter[sold_status]'] = $filters['sold_status'];
	}
	
	if (isset($filters['lot_number_value']) && isset($filters['lot_number_operator'])) {
		$params['filter[lot_number][value]'] = $filters['lot_number_value'];
		$params['filter[lot_number][operator]'] = $filters['lot_number_operator'];
	}
	
	$url = $api_url . '?' . http_build_query($params);
	
	if (get_option('ca_log_api_requests', false)) {
		error_log('Prices Realized API Request: ' . $url);
	}
	
	$response = wp_remote_get($url, [
		'timeout' => 30,
		'headers' => [
			'Accept' => 'application/json',
		]
	]);
	
	if (is_wp_error($response)) {
		error_log('Prices Realized API Error: ' . $response->get_error_message());
		return false;
	}
	
	$body = wp_remote_retrieve_body($response);
	$data = json_decode($body, true);
	
	if (json_last_error() !== JSON_ERROR_NONE) {
		error_log('Prices Realized JSON Error: ' . json_last_error_msg());
		return false;
	}
	
	return $data;
}

/**
 * Helper function to get status display class
 * 
 * @param string $status The sold status
 * @return string CSS class name
 */
function ca_get_status_class($status) {
	switch (strtolower($status)) {
		case 'sold':
			return 'sold';
		case 'unsold':
			return 'unsold';
		case 'withdrawn':
			return 'withdrawn';
		default:
			return 'unknown';
	}
}

/**
 * Helper function to get status display text
 * 
 * @param string $status The sold status
 * @param mixed $sold_price The sold price (can be object with raw/formatted or simple number)
 * @return string Display text for status
 */
function ca_get_status_display($status, $sold_price = null) {
	switch (strtolower($status)) {
		case 'sold':
			if (!empty($sold_price)) {
				// Handle API response format - use formatted price directly
				if (is_array($sold_price) && isset($sold_price['formatted'])) {
					return $sold_price['formatted'];
				}
			}
			return 'Sold';
		case 'unsold':
			return 'Unsold';
		case 'withdrawn':
			return 'Withdrawn';
		default:
			return 'Unknown';
	}
}


/**
 * Render the prices realized page/widget
 * 
 * @param array $config Configuration options
 */
function ca_prices_realized_render($config = []) {
    $defaults = [
        'items_per_page' => 40,
        'show_filters' => true,
        'show_lot_filter' => true,
        'show_status_filter' => true,
        'show_items_per_page' => true,
        'show_pagination' => true,
        'columns' => 4,
        'sale_uuid' => '',
        'title' => 'Prices Realized',
    ];
    
    $config = array_merge($defaults, $config);
    
    
    // Get sale UUID from config, URL parameter, or GET parameter
    $sale_uuid = $config['sale_uuid'];
    if (empty($sale_uuid)) {
        $sale_uuid = get_query_var('sale_uuid');
        if (empty($sale_uuid)) {
            $sale_uuid = isset($_GET['sale_uuid']) ? sanitize_text_field($_GET['sale_uuid']) : '';
        }
    }
    
    // Get filter parameters
    $filters = [];
    if (isset($_GET['lot_start']) && !empty($_GET['lot_start'])) {
        $filters['lot_number_value'] = sanitize_text_field($_GET['lot_start']);
        $filters['lot_number_operator'] = '>=';
    }
    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $filters['sold_status'] = sanitize_text_field($_GET['status']);
    }
    if (isset($_GET['items_per_page'])) {
        $filters['range'] = min(100, max(10, intval($_GET['items_per_page'])));
    } else {
        $filters['range'] = $config['items_per_page'];
    }

    // Get current page - USING 'pager' parameter
    $current_page = isset($_GET['pager']) ? max(1, intval($_GET['pager'])) : 1;
    $filters['page'] = $current_page;

    // Get data from API
    $api_data = false;
    if (!empty($sale_uuid)) {
        $api_data = ca_get_prices_realized_data($sale_uuid, $filters);
    }
    
    /**
     * Helper function to parse pagination info from API response
     */
    function parse_pagination_info($api_data, $items_per_page = 40) {
        if (!$api_data || !isset($api_data['count'])) {
            return ['current_page' => 1, 'total_pages' => 1, 'total_items' => 0];
        }
        
        $total_items = intval($api_data['count']);
        $total_pages = max(1, ceil($total_items / $items_per_page));
        
        $current_page = 1;
        if (isset($api_data['next']['href'])) {
            $url_parts = parse_url($api_data['next']['href']);
            if (isset($url_parts['query'])) {
                parse_str($url_parts['query'], $query_params);
                if (isset($query_params['page'])) {
                    $current_page = max(1, intval($query_params['page']) - 1);
                }
            }
        }
        
        if ($current_page === 1 && isset($_GET['pager'])) {
            $current_page = max(1, intval($_GET['pager']));
        }
        
        return [
            'current_page' => $current_page,
            'total_pages' => $total_pages,
            'total_items' => $total_items
        ];
    }

    /**
     * Generate pagination links - USING 'pager' parameter
     */
    function generate_pagination_links($current_page, $total_pages, $base_url_params = []) {
        if ($total_pages <= 1) return '';
        
        $links = [];
        $range = 2;
        
        if ($current_page > 1) {
            $prev_params = array_merge($base_url_params, ['pager' => $current_page - 1]);
            $links[] = '<a href="?' . http_build_query($prev_params) . '">&laquo; prev</a>';
        }
        
        if ($current_page > $range + 1) {
            $first_params = array_merge($base_url_params, ['pager' => 1]);
            $links[] = '<a href="?' . http_build_query($first_params) . '">1</a>';
            if ($current_page > $range + 2) {
                $links[] = '<span class="dots">...</span>';
            }
        }
        
        for ($i = max(1, $current_page - $range); $i <= min($total_pages, $current_page + $range); $i++) {
            if ($i == $current_page) {
                $links[] = '<span class="current">' . $i . '</span>';
            } else {
                $page_params = array_merge($base_url_params, ['pager' => $i]);
                $links[] = '<a href="?' . http_build_query($page_params) . '">' . $i . '</a>';
            }
        }
        
        if ($current_page < $total_pages - $range) {
            if ($current_page < $total_pages - $range - 1) {
                $links[] = '<span class="dots">...</span>';
            }
            $last_params = array_merge($base_url_params, ['pager' => $total_pages]);
            $links[] = '<a href="?' . http_build_query($last_params) . '">' . $total_pages . '</a>';
        }
        
        if ($current_page < $total_pages) {
            $next_params = array_merge($base_url_params, ['pager' => $current_page + 1]);
            $links[] = '<a href="?' . http_build_query($next_params) . '">next &raquo;</a>';
            
            $last_params = array_merge($base_url_params, ['pager' => $total_pages]);
            $links[] = '<a href="?' . http_build_query($last_params) . '">last &raquo;</a>';
        }
        
        return implode('', $links);
    }
    
    ?>
    <div class="prices-realized-container">
        <div class="content-wrapper">
            <?php if (!empty($config['title'])): ?>
                <h1 class="page-title"><?php echo esc_html($config['title']); ?></h1>
            <?php endif; ?>
            
            <?php if (empty($sale_uuid)): ?>
                <div class="notice notice-warning">
                    <p>Please provide a sale UUID to view prices realized.</p>
                    <p>URL format: <code>/prices-realized/your-sale-uuid</code></p>
                </div>
            <?php elseif ($api_data === false): ?>
                <div class="notice notice-error">
                    <p>Unable to load prices realized data. Please try again later.</p>
                </div>
            <?php else: ?>
                
                <?php if ($config['show_filters']): ?>
                <!-- Filters Section -->
                <div class="filters-section">
                    <form method="GET" action="" class="filters-form">
                        <?php if (!empty($sale_uuid)): ?>
                            <input type="hidden" name="sale_uuid" value="<?php echo esc_attr($sale_uuid); ?>">
                        <?php endif; ?>
                        
                        <?php if ($config['show_lot_filter']): ?>
                        <div class="filter-group">
                            <label for="lot_start">Start at Lot no</label>
                            <input type="number" 
                                   id="lot_start" 
                                   name="lot_start" 
                                   value="<?php echo esc_attr(isset($_GET['lot_start']) ? $_GET['lot_start'] : ''); ?>" 
                                   placeholder="Enter lot number">
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($config['show_status_filter']): ?>
                        <div class="filter-group">
                            <label for="status">Status</label>
                            <select id="status" name="status">
                                <option value="">- Any -</option>
                                <option value="sold" <?php selected(isset($_GET['status']) ? $_GET['status'] : '', 'sold'); ?>>Sold</option>
                                <option value="unsold" <?php selected(isset($_GET['status']) ? $_GET['status'] : '', 'unsold'); ?>>Unsold</option>
                            </select>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($config['show_items_per_page']): ?>
                        <div class="filter-group">
                            <label for="items_per_page">Items per page</label>
                            <select id="items_per_page" name="items_per_page">
                                <option value="40" <?php selected(isset($_GET['items_per_page']) ? $_GET['items_per_page'] : '40', '40'); ?>>40</option>
                                <option value="80" <?php selected(isset($_GET['items_per_page']) ? $_GET['items_per_page'] : '40', '80'); ?>>80</option>
                                <option value="100" <?php selected(isset($_GET['items_per_page']) ? $_GET['items_per_page'] : '40', '100'); ?>>100</option>
                            </select>
                        </div>
                        <?php endif; ?>
                        
                        <button type="submit" class="apply-filters-btn">Apply</button>
                        <button type="button" class="reset-filters-btn" onclick="resetFilters()">Reset</button>
                    </form>
                </div>
                <?php endif; ?>

                <!-- Results Grid/List -->
                <?php if (isset($api_data['data']) && !empty($api_data['data'])): ?>
                    <?php
                    $items = $api_data['data'];
                    $items_per_page = isset($_GET['items_per_page']) ? intval($_GET['items_per_page']) : $config['items_per_page'];
                    $pagination_info = parse_pagination_info($api_data, $items_per_page);
                    
                    // Split items into columns based on config
                    $total_items = count($items);
                    $items_per_column = ceil($total_items / $config['columns']);
                    $columns = array_chunk($items, $items_per_column);
                    
                    // Ensure we have exactly the right number of columns
                    while (count($columns) < $config['columns']) {
                        $columns[] = [];
                    }
                    ?>
                    
                    <div class="prices-grid" style="grid-template-columns: repeat(<?php echo $config['columns']; ?>, 1fr);">
                        <?php for ($col = 0; $col < $config['columns']; $col++): ?>
                            <div class="column">
                                <div class="column-header">
                                    <span class="lot-header">Lot no.</span>
                                    <span class="opening-header">Opening</span>
                                    <span class="sold-header">Sold for</span>
                                </div>
                                
                                <?php if (isset($columns[$col]) && !empty($columns[$col])): ?>
                                    <?php foreach ($columns[$col] as $item): ?>
                                        <div class="price-item">
                                            <span class="lot-number"><?php echo esc_html($item['lot'] ?? 'N/A'); ?></span>
                                            <span class="opening-price">
                                                <?php 
                                                $opening_price = $item['opening_price'] ?? null;
                                                if (is_array($opening_price) && isset($opening_price['formatted'])) {
                                                    echo esc_html($opening_price['formatted']);
                                                } else {
                                                    echo 'N/A';
                                                }
                                                ?>
                                            </span>
                                            <span class="sold-price <?php echo esc_attr(ca_get_status_class($item['sold_status'] ?? 'unknown')); ?>">
                                                <?php 
                                                $status = $item['sold_status'] ?? 'unknown';
                                                $sold_price = $item['sold_price'] ?? null;
                                                echo esc_html(ca_get_status_display($status, $sold_price));
                                                ?>
                                            </span>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        <?php endfor; ?>
                    </div>

                    <?php if ($config['show_pagination']): ?>
                    <!-- Pagination -->
                    <?php 
                    $base_params = [];
                    if (!empty($sale_uuid)) $base_params['sale_uuid'] = $sale_uuid;
                    if (isset($_GET['lot_start']) && !empty($_GET['lot_start'])) $base_params['lot_start'] = $_GET['lot_start'];
                    if (isset($_GET['status']) && !empty($_GET['status'])) $base_params['status'] = $_GET['status'];
                    if (isset($_GET['items_per_page'])) $base_params['items_per_page'] = $_GET['items_per_page'];
                    
                    $pagination_links = generate_pagination_links(
                        $pagination_info['current_page'], 
                        $pagination_info['total_pages'], 
                        $base_params
                    );
                    ?>
                    
                    <?php if (!empty($pagination_links)): ?>
                        <div class="pagination">
                            <?php echo $pagination_links; ?>
                        </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <div class="no-results">
                        <p>No items found matching your criteria.</p>
                    </div>
                <?php endif; ?>
                
            <?php endif; ?>
        </div>
    </div>

    <?php if ($config['show_filters']): ?>
    <script>
    function resetFilters() {
        document.getElementById('lot_start').value = '';
        document.getElementById('status').value = '';
        if (document.getElementById('items_per_page')) {
            document.getElementById('items_per_page').value = '40';
        }
        document.querySelector('.filters-form').submit();
    }
    </script>
    <?php endif; ?>
    <?php
}

/**
 * Prices Realized Widget Class
 */
class Ca_Prices_Realized_Widget extends WP_Widget {
    
    function __construct() {
        parent::__construct(
            'ca_prices_realized_widget',
            __('Circuit Auction - Prices Realized', 'text_domain'),
            ['description' => __('Display prices realized for a sale', 'text_domain')]
        );
    }
    
    public function widget($args, $instance) {

        
        $config = [
            'sale_uuid' => $instance['sale_uuid'] ?? '',
            'items_per_page' => $instance['items_per_page'] ?? 40,
            'columns' => $instance['columns'] ?? 2, // Smaller for widgets
            'show_filters' => $instance['show_filters'] ?? true,
            'show_lot_filter' => $instance['show_lot_filter'] ?? true,
            'show_status_filter' => $instance['show_status_filter'] ?? true,
            'show_items_per_page' => $instance['show_items_per_page'] ?? true,
            'show_pagination' => $instance['show_pagination'] ?? true,
            'title' => $instance['title'] ?? 'Prices Realized',
        ];

        echo $args['before_widget'];
        if (!empty($instance['title'])) {
            echo $args['before_title'] . $instance['title'] . $args['after_title'];
        }
        
        ca_prices_realized_render($config);
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : 'Prices Realized';
        $sale_uuid = !empty($instance['sale_uuid']) ? $instance['sale_uuid'] : '';
        $items_per_page = !empty($instance['items_per_page']) ? $instance['items_per_page'] : 40;
        $columns = !empty($instance['columns']) ? $instance['columns'] : 2;
        $show_filters = isset($instance['show_filters']) ? (bool) $instance['show_filters'] : true;
        $show_lot_filter = isset($instance['show_lot_filter']) ? (bool) $instance['show_lot_filter'] : true;
        $show_status_filter = isset($instance['show_status_filter']) ? (bool) $instance['show_status_filter'] : true;
        $show_items_per_page = isset($instance['show_items_per_page']) ? (bool) $instance['show_items_per_page'] : true;
        $show_pagination = isset($instance['show_pagination']) ? (bool) $instance['show_pagination'] : true;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('sale_uuid'); ?>"><?php _e('Sale UUID:'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('sale_uuid'); ?>" name="<?php echo $this->get_field_name('sale_uuid'); ?>" type="text" value="<?php echo esc_attr($sale_uuid); ?>" placeholder="Leave empty for current sale">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('items_per_page'); ?>"><?php _e('Items per page:'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('items_per_page'); ?>" name="<?php echo $this->get_field_name('items_per_page'); ?>">
                <option value="20" <?php selected($items_per_page, 20); ?>>20</option>
                <option value="40" <?php selected($items_per_page, 40); ?>>40</option>
                <option value="80" <?php selected($items_per_page, 80); ?>>80</option>
                <option value="100" <?php selected($items_per_page, 100); ?>>100</option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('columns'); ?>"><?php _e('Number of columns:'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('columns'); ?>" name="<?php echo $this->get_field_name('columns'); ?>">
                <option value="1" <?php selected($columns, 1); ?>>1</option>
                <option value="2" <?php selected($columns, 2); ?>>2</option>
                <option value="3" <?php selected($columns, 3); ?>>3</option>
                <option value="4" <?php selected($columns, 4); ?>>4</option>
            </select>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_filters); ?> id="<?php echo $this->get_field_id('show_filters'); ?>" name="<?php echo $this->get_field_name('show_filters'); ?>" />
            <label for="<?php echo $this->get_field_id('show_filters'); ?>"><?php _e('Show filters section'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_lot_filter); ?> id="<?php echo $this->get_field_id('show_lot_filter'); ?>" name="<?php echo $this->get_field_name('show_lot_filter'); ?>" />
            <label for="<?php echo $this->get_field_id('show_lot_filter'); ?>"><?php _e('Show lot number filter'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_status_filter); ?> id="<?php echo $this->get_field_id('show_status_filter'); ?>" name="<?php echo $this->get_field_name('show_status_filter'); ?>" />
            <label for="<?php echo $this->get_field_id('show_status_filter'); ?>"><?php _e('Show status filter'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_items_per_page); ?> id="<?php echo $this->get_field_id('show_items_per_page'); ?>" name="<?php echo $this->get_field_name('show_items_per_page'); ?>" />
            <label for="<?php echo $this->get_field_id('show_items_per_page'); ?>"><?php _e('Show items per page selector'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_pagination); ?> id="<?php echo $this->get_field_id('show_pagination'); ?>" name="<?php echo $this->get_field_name('show_pagination'); ?>" />
            <label for="<?php echo $this->get_field_id('show_pagination'); ?>"><?php _e('Show pagination'); ?></label>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = [];
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['sale_uuid'] = (!empty($new_instance['sale_uuid'])) ? strip_tags($new_instance['sale_uuid']) : '';
        $instance['items_per_page'] = (!empty($new_instance['items_per_page'])) ? intval($new_instance['items_per_page']) : 40;
        $instance['columns'] = (!empty($new_instance['columns'])) ? intval($new_instance['columns']) : 2;
        $instance['show_filters'] = !empty($new_instance['show_filters']);
        $instance['show_lot_filter'] = !empty($new_instance['show_lot_filter']);
        $instance['show_status_filter'] = !empty($new_instance['show_status_filter']);
        $instance['show_items_per_page'] = !empty($new_instance['show_items_per_page']);
        $instance['show_pagination'] = !empty($new_instance['show_pagination']);
        return $instance;
    }
}

/**
 * Register block for Gutenberg editor
 */
function ca_register_prices_realized_gutenberg_block() {
    if (!function_exists('register_block_type')) {
        return;
    }

    wp_register_script(
        'ca-prices-realized-editor',
        plugins_url('js/prices-realized-editor.js', __FILE__),
        ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
        '1.0.0'
    );

    register_block_type('circuit-auction/prices-realized', [
        'editor_script' => 'ca-prices-realized-editor',
        'render_callback' => 'ca_render_prices_realized_block',
        'attributes' => [
            'title' => ['type' => 'string', 'default' => 'Prices Realized'],
            'sale_uuid' => ['type' => 'string', 'default' => ''],
            'items_per_page' => ['type' => 'number', 'default' => 40],
            'columns' => ['type' => 'number', 'default' => 4],
            'show_filters' => ['type' => 'boolean', 'default' => true],
            'show_lot_filter' => ['type' => 'boolean', 'default' => true],
            'show_status_filter' => ['type' => 'boolean', 'default' => true],
            'show_items_per_page' => ['type' => 'boolean', 'default' => true],
            'show_pagination' => ['type' => 'boolean', 'default' => true],
        ]
    ]);
}
add_action('init', 'ca_register_prices_realized_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_prices_realized_block($attributes) {
    ob_start();
    ca_prices_realized_render($attributes);
    return ob_get_clean();
}
?>