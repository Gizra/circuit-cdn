<?php

/**
 * Featured Items Block Class
 */
class Ca_Featured_Items_Block extends WP_Widget {
	/**
	 * Initialize the widget
	 */
	public function __construct() {
		parent::__construct(
			'ca_featured_items', // Widget ID
			__('Circuit Auction - Featured Items', 'text_domain'), // Widget name in admin
			['description' => __('Display featured items carousel', 'text_domain')]
		);
	}

	/**
	 * Frontend display of widget
	 */
	public function widget($args, $instance) {
		$sale_id = $instance['sale_id'] ?? ca_sale_get_active_sale_id();

		echo $args['before_widget'];
		echo $args['before_title'] . 'Featured Items' . $args['after_title'];

		// AJAX container - content will be loaded via JavaScript
		echo '<div class="ca-featured-items" data-sale-id="' . esc_attr($sale_id) . '">';
		echo '<div class="ca-loading">Loading featured items...</div>';
		echo '</div>';

		echo $args['after_widget'];
	}

	/**
	 * Render individual featured item
	 */
	private function render_featured_item($item, $language, $post_id, $index) {
		$lang_data = $item->$language ?? $item->en ?? null;
		if (!$lang_data) return;

		$item_url = get_permalink($post_id);
		$lot_number = $item->lot_number ?? '';
		$title = $lang_data->title ?? '';
		$subtitle = $lang_data->subtitle ?? '';
		$body = $lang_data->body ?? '';
		
		// Clean up body text (remove HTML tags for carousel display)
		$body_clean = wp_strip_all_tags($body);
		$body_excerpt = strlen($body_clean) > 150 ? substr($body_clean, 0, 150) . '...' : $body_clean;

		echo '<div class="featured-item" data-index="' . $index . '">';
		
		// Left side - Images with inner carousel
		echo '<div class="item-images">';
		$this->render_item_images($item, $item_url);
		echo '</div>';

		// Middle - Content
		echo '<div class="item-content">';
		echo '<div class="lot-number">Lot #' . esc_html($lot_number) . '</div>';
		if ($title) {
			echo '<h3 class="item-title"><a href="' . esc_url($item_url) . '">' . esc_html($title) . '</a></h3>';
		}
		if ($subtitle) {
			echo '<div class="item-subtitle">' . esc_html($subtitle) . '</div>';
		}
		if ($body_excerpt) {
			echo '<div class="item-description">' . esc_html($body_excerpt) . '</div>';
		}
		echo '</div>';

		// Right side - Prices and metadata
		echo '<div class="item-metadata">';
		$this->render_item_prices($item);
		$this->render_item_details($item, $lang_data);
		echo '</div>';

		echo '</div>'; // .featured-item
	}

	/**
	 * Render item images with inner carousel
	 */
	private function render_item_images($item, $item_url) {
		if (empty($item->image_gallery->images_path)) {
			echo '<div class="no-image">No Image</div>';
			return;
		}

		$images = $item->image_gallery->images_path;
		$has_multiple = count($images) > 1;
		
		echo '<div class="image-carousel' . ($has_multiple ? ' has-multiple' : '') . '">';
		echo '<div class="image-container">';
		
		foreach($images as $img_index => $image) {
			$active_class = $img_index === 0 ? ' active' : '';
			echo '<div class="image-slide' . $active_class . '">';
			echo '<a href="' . esc_url($item_url) . '">';
			echo '<img src="' . esc_url($image->small) . '" alt="Item image" loading="lazy">';
			echo '</a>';
			echo '</div>';
		}
		
		echo '</div>'; // .image-container

		// Add dots indicator if multiple images
		if ($has_multiple) {
			echo '<div class="image-dots">';
			foreach($images as $dot_index => $image) {
				$active_class = $dot_index === 0 ? ' active' : '';
				echo '<span class="dot' . $active_class . '" data-slide="' . $dot_index . '"></span>';
			}
			echo '</div>';
		}

		echo '</div>'; // .image-carousel
	}

	/**
	 * Render item prices
	 */
	private function render_item_prices($item) {
		echo '<div class="item-prices">';
		
		if (!empty($item->opening_price)) {
			echo '<div class="price opening-price">';
			echo '<span class="label">Opening:</span> ';
			echo '<span class="value">' . esc_html($item->opening_price) . '</span>';
			echo '</div>';
		}

		if (!empty($item->estimation)) {
			echo '<div class="price estimate">';
			echo '<span class="label">Estimate:</span> ';
			echo '<span class="value">' . esc_html($item->estimation) . '</span>';
			echo '</div>';
		}

		if (!empty($item->soldfor) && $item->soldfor !== 'Unsold') {
			echo '<div class="price sold-price">';
			echo '<span class="label">Sold for:</span> ';
			echo '<span class="value">' . esc_html($item->soldfor) . '</span>';
			echo '</div>';
		} elseif (!empty($item->unsold)) {
			echo '<div class="price unsold">Unsold</div>';
		}

		echo '</div>'; // .item-prices
	}

	/**
	 * Render additional item details
	 */
	private function render_item_details($item, $lang_data) {
		echo '<div class="item-details">';

		// Symbols
		if (!empty($item->rendered_symbols)) {
			echo '<div class="detail-item symbols">';
			echo '<span class="label">Symbols:</span> ';
			echo $item->rendered_symbols;
			echo '</div>';
		}

		// Provenance
		if (!empty($item->provenance)) {
			echo '<div class="detail-item provenance">';
			echo '<span class="label">Provenance:</span> ';
			echo esc_html($item->provenance);
			echo '</div>';
		}

		// Catalog info
		if (!empty($lang_data->item_taxonomy->catalogue_name_and_number->rendered)) {
			echo '<div class="detail-item catalog">';
			echo $lang_data->item_taxonomy->catalogue_name_and_number->rendered;
			echo '</div>';
		}

		// Categories
		if (!empty($lang_data->item_taxonomy->field_category->rendered)) {
			echo '<div class="detail-item category">';
			echo '<span class="label">Category:</span> ';
			echo esc_html($lang_data->item_taxonomy->field_category->rendered);
			echo '</div>';
		}

		echo '</div>'; // .item-details
	}

	/**
	 * Backend widget form
	 */
	public function form($instance) {
		$title = !empty($instance['title']) ? $instance['title'] : 'Featured Items';
		$sale_id = !empty($instance['sale_id']) ? $instance['sale_id'] : '';
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
			<input class="widefat"
				   id="<?php echo $this->get_field_id('title'); ?>"
				   name="<?php echo $this->get_field_name('title'); ?>"
				   type="text"
				   value="<?php echo esc_attr($title); ?>">
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('sale_id'); ?>"><?php _e('Sale ID:'); ?></label>
			<input class="widefat"
				   id="<?php echo $this->get_field_id('sale_id'); ?>"
				   name="<?php echo $this->get_field_name('sale_id'); ?>"
				   type="text"
				   value="<?php echo esc_attr($sale_id); ?>"
				   placeholder="Leave empty for current sale">
		</p>
		<p>
			<em>Featured items will be loaded dynamically based on the sale.</em>
		</p>
		<?php
	}

	/**
	 * Sanitize widget form values as they are saved
	 */
	public function update($new_instance, $old_instance) {
		$instance = [];
		$instance['title'] = (!empty($new_instance['title']))
			? strip_tags($new_instance['title'])
			: 'Featured Items';
		$instance['sale_id'] = (!empty($new_instance['sale_id']))
			? strip_tags($new_instance['sale_id'])
			: '';
		return $instance;
	}
}


/**
 * Register the Featured Items widget
 */
function ca_register_featured_items_block() {
	register_widget('Ca_Featured_Items_Block');
}
add_action('widgets_init', 'ca_register_featured_items_block');

/**
 * Enqueue necessary scripts and styles for the block
 */
function ca_enqueue_featured_items_assets() {
	wp_enqueue_style(
		'ca-featured-items-style',
		plugins_url('css/featured-items.css', __FILE__),
		[],
		'1.0.0'
	);

	wp_enqueue_script(
		'ca-featured-items-script',
		plugins_url('js/featured-items.js', __FILE__),
		['jquery'],
		'1.0.0',
		true
	);

	// Add localized script data for AJAX
	wp_localize_script('ca-featured-items-script', 'caFeaturedItems', [
		'ajaxUrl' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('ca-featured-items-nonce')
	]);
}
add_action('wp_enqueue_scripts', 'ca_enqueue_featured_items_assets');

/**
 * Get featured items UUIDs from API
 */
function ca_featured_items_get_featured_items( $post_id, $sale_nid = FALSE ) {
	if ( empty( $sale_nid ) ) {
		$sale_nid = ca_items_get_custom_meta( $post_id, 'nid' );
	}

	// Base url for the API with proper endpoint and parameters
	$base_url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' );
	$url = $base_url . '/api/items-public?fields=lot,uuid&filter[tags]=Featured+item&sale_id=' . $sale_nid . '&sort=lot_number';

	// DEBUG: Log the actual URL being called
	error_log("API URL being called: " . $url);
	error_log("Sale NID used: " . $sale_nid);

	// Use WordPress's built-in HTTP API to fetch the JSON data
	$response = wp_remote_get( $url );

	// Check for an error in the response
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'server-error', __( 'Unable to retrieve featured items.', 'text-domain' ) );
	}

	// DEBUG: Log the raw response
	error_log("Raw API response code: " . wp_remote_retrieve_response_code($response));
	error_log("Raw API response body: " . wp_remote_retrieve_body($response));

	// Parse the JSON response body
	$data = json_decode( wp_remote_retrieve_body( $response ), TRUE );

	// Check for JSON decoding error or empty data
	if ( NULL === $data || empty( $data ) ) {
		return new WP_Error( 'json-error', __( 'Invalid or empty JSON response.', 'text-domain' ) );
	}

	// Extract UUIDs from the response - based on the actual API structure
	$uuids = [];
	if (isset($data['data']) && is_array($data['data'])) {
		foreach ($data['data'] as $item) {
			if (!empty($item['uuid'])) {
				$uuids[] = $item['uuid'];
			}
		}
	}

	return $uuids;
}

/**
 * AJAX handler for loading featured items
 */
function ca_ajax_load_featured_items() {
    check_ajax_referer('ca-featured-items-nonce', 'nonce');

    $sale_id = isset($_POST['sale_id']) ? sanitize_text_field($_POST['sale_id']) : '';
    
    if (empty($sale_id)) {
        $sale_id = ca_sale_get_active_sale_id();
    }

    // DEBUG: Log what we're working with
    error_log("Featured Items Debug - Sale ID: " . $sale_id);

		$test_nid = ca_items_get_custom_meta($sale_id, 'nid');
    error_log("DEBUG: Post ID " . $sale_id . " NID = " . $test_nid);

    // Get the post ID for this sale
		$post_id = intval($sale_id);
    
    // DEBUG: Check if post found
    error_log("Featured Items Debug - Post ID: " . ($post_id ? $post_id : 'NOT FOUND'));
    
    if (!$post_id) {
        wp_send_json_error(['message' => 'Sale not found', 'debug' => 'Post ID lookup failed for sale_id: ' . $sale_id]);
        return;
    }

    // Get featured item UUIDs dynamically from API
    $featured_uuids = ca_featured_items_get_featured_items($post_id);
    
    // DEBUG: Check UUIDs
    error_log("Featured Items Debug - UUIDs: " . print_r($featured_uuids, true));

		// Add this detailed debugging:
		if (is_wp_error($featured_uuids)) {
				error_log("API ERROR: " . $featured_uuids->get_error_message());
		} else {
				error_log("API SUCCESS: Found " . count($featured_uuids) . " UUIDs");
				error_log("UUIDs: " . json_encode($featured_uuids));
		}
    
    if (is_wp_error($featured_uuids)) {
        wp_send_json_error(['message' => $featured_uuids->get_error_message(), 'debug' => 'API call failed']);
        return;
    }

    ob_start();

    if (empty($featured_uuids)) {
        ?>
        <div class="ca-featured-items">
            <div class="ca-error">No featured items found for this sale.</div>
        </div>
        <?php
        $html = ob_get_clean();
        wp_send_json_success([
            'html' => $html,
            'total_items' => 0,
        ]);
        return;
    }

    ?>
    <div class="featured-items-carousel">
        <div class="carousel-track">
            <?php
            $valid_items = 0;
            foreach($featured_uuids as $index => $uuid) {
                // DEBUG: Log each UUID processing
                error_log("Featured Items Debug - Processing UUID: " . $uuid);
                
                // Get WordPress post ID from UUID
                $item_post_id = ca_get_post_id_by_uuid($uuid, 'item');
                
                // DEBUG: Check item post ID
                error_log("Featured Items Debug - Item Post ID for $uuid: " . ($item_post_id ? $item_post_id : 'NOT FOUND'));
                
                if (!$item_post_id) {
                    continue; // Skip if item not found
                }

                // Get item JSON data
                $item_data = ca_items_get_custom_meta($item_post_id, 'json_data');
                $language = ca_items_get_custom_meta($item_post_id, 'language') ?: 'en';
                
                // DEBUG: Check item data
                error_log("Featured Items Debug - Item data exists: " . ($item_data ? 'YES' : 'NO'));
                
                if (!$item_data) {
                    continue; // Skip if no data
                }

                ca_render_featured_item($item_data, $language, $item_post_id, $valid_items);
                $valid_items++;
            }
            
            // DEBUG: Final count
            error_log("Featured Items Debug - Valid items rendered: " . $valid_items);
            ?>
        </div>
        
        <!-- Item navigation dots -->
        <div class="item-navigation">
            <?php for ($i = 0; $i < $valid_items; $i++): ?>
                <span class="item-nav-dot<?php echo $i === 0 ? ' active' : ''; ?>" data-item="<?php echo $i; ?>"></span>
            <?php endfor; ?>
        </div>
        
        <!-- Progress indicator -->
        <div class="carousel-progress">
            <span class="current-item">1</span>/<span class="total-items"><?php echo $valid_items; ?></span>
        </div>
    </div>
    <?php

    $html = ob_get_clean();

    wp_send_json_success([
        'html' => $html,
        'total_items' => $valid_items,
        'debug' => [
            'sale_id' => $sale_id,
            'post_id' => $post_id,
            'featured_uuids' => $featured_uuids,
            'valid_items' => $valid_items
        ]
    ]);
}

add_action('wp_ajax_ca_load_featured_items', 'ca_ajax_load_featured_items');
add_action('wp_ajax_nopriv_ca_load_featured_items', 'ca_ajax_load_featured_items');

/**
 * Register block for Gutenberg editor
 */
function ca_register_featured_items_gutenberg_block() {
	if (!function_exists('register_block_type')) {
		return;
	}

	wp_register_script(
		'ca-featured-items-editor',
		plugins_url('js/featured-items-editor.js', __FILE__),
		['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
		'1.0.0'
	);

	register_block_type('circuit-auction/featured-items', [
		'editor_script' => 'ca-featured-items-editor',
		'render_callback' => 'ca_render_featured_items_block',
		'attributes' => [
			'sale_uuid' => [
				'type' => 'string',
				'default' => ''
			],
			'title' => [
				'type' => 'string',
				'default' => 'Featured Items'
			]
		]
	]);
}
add_action('init', 'ca_register_featured_items_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_featured_items_block($attributes) {
	$sale_id = $attributes['sale_uuid'] ?: ca_sale_get_active_sale_id();

	ob_start();
	?>
	<div class="ca-featured-items"
		 data-sale-id="<?php echo esc_attr($sale_id); ?>">
		<div class="ca-loading">Loading featured items...</div>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Render individual featured item (moved outside of class for AJAX use)
 */
function ca_render_featured_item($item, $language, $post_id, $index) {
	$lang_data = $item->$language ?? $item->en ?? null;
	if (!$lang_data) return;

	$item_url = get_permalink($post_id);
	$lot_number = $item->lot_number ?? '';
	$title = $lang_data->title ?? '';
	$subtitle = $lang_data->subtitle ?? '';
	$body = $lang_data->body ?? '';
	
	// Clean up body text (remove HTML tags for carousel display)
	$body_clean = wp_strip_all_tags($body);
	$body_excerpt = strlen($body_clean) > 150 ? substr($body_clean, 0, 150) . '...' : $body_clean;

	echo '<div class="featured-item" data-index="' . $index . '">';
	
	// Left side - Images with inner carousel
	echo '<div class="item-images">';
	ca_render_featured_item_images($item, $item_url);
	echo '</div>';

	// Middle - Content
	echo '<div class="item-content">';
	echo '<div class="lot-number">Lot #' . esc_html($lot_number) . '</div>';
	if ($title) {
		echo '<h3 class="item-title"><a href="' . esc_url($item_url) . '">' . esc_html($title) . '</a></h3>';
	}
	if ($subtitle) {
		echo '<div class="item-subtitle">' . esc_html($subtitle) . '</div>';
	}
	if ($body_excerpt) {
		echo '<div class="item-description">' . esc_html($body_excerpt) . '</div>';
	}
	// Provenance
	if (!empty($item->provenance)) {
		echo '<div class="item-description">' . wp_kses_post($item->provenance) . '</div>';
	}
	echo '</div>';

	// Right side - Prices and metadata
	echo '<div class="item-metadata">';
	ca_render_featured_item_prices($item);
	ca_render_featured_item_details($item, $lang_data);
	echo '</div>';

	echo '</div>'; // .featured-item
}

/**
 * Render item images with inner carousel
 */
function ca_render_featured_item_images($item, $item_url) {
	if (empty($item->image_gallery->images_path)) {
		echo '<div class="no-image">No Image</div>';
		return;
	}

	$images = $item->image_gallery->images_path;
	$has_multiple = count($images) > 1;
	
	echo '<div class="image-carousel' . ($has_multiple ? ' has-multiple' : '') . '">';
	echo '<div class="image-container">';
	
	foreach($images as $img_index => $image) {
		$active_class = $img_index === 0 ? ' active' : '';
		echo '<div class="image-slide' . $active_class . '">';
		echo '<a href="' . esc_url($item_url) . '">';
		echo '<img src="' . esc_url($image->big) . '" alt="Item image" loading="lazy">';
		echo '</a>';
		echo '</div>';
	}
	
	echo '</div>'; // .image-container

	// Add dots indicator if multiple images
	if ($has_multiple) {
		echo '<div class="image-dots">';
		foreach($images as $dot_index => $image) {
			$active_class = $dot_index === 0 ? ' active' : '';
			echo '<span class="dot' . $active_class . '" data-slide="' . $dot_index . '"></span>';
		}
		echo '</div>';
	}

	echo '</div>'; // .image-carousel
}

/**
 * Render item prices
 */
function ca_render_featured_item_prices($item) {
	echo '<div class="item-prices">';
	
	if (!empty($item->opening_price)) {
		echo '<div class="price opening-price">';
		echo '<span class="label">Opening:</span> ';
		echo '<span class="value">' . esc_html($item->opening_price) . '</span>';
		echo '</div>';
	}

	if (!empty($item->estimation)) {
		echo '<div class="price estimate">';
		echo '<span class="label">Estimate:</span> ';
		echo '<span class="value">' . esc_html($item->estimation) . '</span>';
		echo '</div>';
	}

	if (!empty($item->soldfor) && $item->soldfor !== 'Unsold') {
		echo '<div class="price sold-price">';
		echo '<span class="label">Sold for:</span> ';
		echo '<span class="value">' . esc_html($item->soldfor) . '</span>';
		echo '</div>';
	} elseif (!empty($item->unsold)) {
		echo '<div class="price unsold">Unsold</div>';
	}

	echo '</div>'; // .item-prices
}

/**
 * Render additional item details
 */
function ca_render_featured_item_details($item, $lang_data) {
	echo '<div class="item-details">';

	// Symbols
	if (!empty($item->rendered_symbols)) {
		echo '<div class="detail-item symbols">';
		echo '<span class="label">Symbols:</span> ';
		echo $item->rendered_symbols;
		echo '</div>';
	}
	
	// Catalog info
	if (!empty($lang_data->item_taxonomy->catalogue_name_and_number->rendered)) {
		echo '<div class="detail-item catalog">';
		echo $lang_data->item_taxonomy->catalogue_name_and_number->rendered;
		echo '</div>';
	}

	// Categories
	if (!empty($lang_data->item_taxonomy->field_category->rendered)) {
		echo '<div class="detail-item category">';
		echo '<span class="label">Category:</span> ';
		echo esc_html($lang_data->item_taxonomy->field_category->rendered);
		echo '</div>';
	}

	echo '</div>'; // .item-details
}
?>