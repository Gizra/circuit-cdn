<?php

/**
 * Sale Sessions Block Class
 */
class Ca_Sale_Sessions_Block extends WP_Widget {
	/**
	 * Initialize the widget
	 */
	public function __construct() {
		parent::__construct(
			'ca_sale_sessions', // Widget ID
			__('Circuit Auction - Sale Sessions', 'text_domain'), // Widget name in admin
			['description' => __('Display sale sessions hierarchy', 'text_domain')]
		);
	}

	/**
	 * Frontend display of widget
	 */
	public function widget($args, $instance) {
    $active_sale_id = ca_sale_get_active_sale_id();
    $json_data = ca_items_get_custom_meta($active_sale_id, 'json_data');

    echo $args['before_widget'];
    echo $args['before_title'] . 'Session Details' . $args['after_title'];

    if(isset($json_data['sessions']) && is_array($json_data['sessions'])) {
        // Organize sessions into parent and child structure
        $organized_sessions = [];
        $parent_sessions = [];
        $child_sessions = [];

        // First pass: separate parents and children
        foreach($json_data['sessions'] as $session) {
            if(empty($session['parent'])) {
                $parent_sessions[] = $session;
            } else {
                $child_sessions[] = $session;
            }
        }

        // Sort parent sessions by from_lot
        usort($parent_sessions, function($a, $b) {
            return intval($a['from_lot']) - intval($b['from_lot']);
        });

        // Sort child sessions by from_lot
        usort($child_sessions, function($a, $b) {
            return intval($a['from_lot']) - intval($b['from_lot']);
        });

        // Group children under their parents
        foreach($parent_sessions as &$parent) {
            $parent['subsessions'] = [];
            foreach($child_sessions as $child) {
                if($child['parent'] === $parent['id']) {
                    $parent['subsessions'][] = $child;
                }
            }
        }

        echo '<div class="session-list">';

        // Display organized sessions
        foreach($parent_sessions as $session) {
          $name = $session['name'];
          $from_lot = $session['from_lot'];
          $to_lot = $session['to_lot'];

          // Convert the date from Unix timestamp to desired format
          $date = date("D, F j Y g a T", $session['date_value']);

          if (!empty($session['date_override'])) {
            $date = $session['date_override'];
          }

          echo '<div class="session"><h3><a href="' . get_permalink($active_sale_id) . '?filter[field_lot_number][min]=' .
            $from_lot . '&filter[field_lot_number][max]=' . $to_lot . '">' . $name . ' | Lot ' .
            $from_lot . ' to ' . $to_lot .'</a></h3><div class="session-date">' . $date . '</div></div>';

          // Display subsessions if they exist
          // Display subsessions if they exist
					if(!empty($session['subsessions'])) {
						echo '<table class="sub-session">';
						foreach($session['subsessions'] as $subsession) {
								$sub_name = $subsession['name'];
								$sub_from_lot = $subsession['from_lot'];
								$sub_to_lot = $subsession['to_lot'];
								
								// Determine if it's a single lot or a range
								$lot_display = ($sub_from_lot === $sub_to_lot) 
										? "Lot " . $sub_from_lot 
										: "Lot " . $sub_from_lot . "-" . $sub_to_lot;

								echo '<tr><td class="lots" style="min-width: 200px;"><a href="' . get_permalink($active_sale_id) . '?filter[field_lot_number][min]=' .
										$sub_from_lot . '&filter[field_lot_number][max]=' . $sub_to_lot . '">' . $lot_display . '</a></td>
										<td class="subsession-name"><a href="' . get_permalink($active_sale_id) . '?filter[field_lot_number][min]=' .
										$sub_from_lot . '&filter[field_lot_number][max]=' . $sub_to_lot . '">' . $sub_name . '</a></td>
										</tr>';
						}
						echo '</table>';
					}
        }
      echo '</div>';
    }

    echo $args['after_widget'];
	}


	/**
	 * Backend widget form
	 */
	public function form($instance) {
		$title = !empty($instance['title']) ? $instance['title'] : '';
		$sale_uuid = !empty($instance['sale_uuid']) ? $instance['sale_uuid'] : '';
		$sessions = !empty($instance['sessions']) ? $instance['sessions'] : 'full';
		?>
      <p>
        <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
        <input class="widefat"
               id="<?php echo $this->get_field_id('title'); ?>"
               name="<?php echo $this->get_field_name('title'); ?>"
               type="text"
               value="<?php echo esc_attr($title); ?>">
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('sale_uuid'); ?>"><?php _e('Sale UUID:'); ?></label>
        <input class="widefat"
               id="<?php echo $this->get_field_id('sale_uuid'); ?>"
               name="<?php echo $this->get_field_name('sale_uuid'); ?>"
               type="text"
               value="<?php echo esc_attr($sale_uuid); ?>"
               placeholder="Leave empty for current sale">
      </p>
      <p>
        <label for="<?php echo $this->get_field_id('sessions'); ?>"><?php _e('Sessions:'); ?></label>
        <select class="widefat"
                id="<?php echo $this->get_field_id('sessions'); ?>"
                name="<?php echo $this->get_field_name('sessions'); ?>">
          <option value="full" <?php selected($sessions, 'full'); ?>><?php _e('Full Catalog'); ?></option>
          <option value="featured" <?php selected($sessions, 'featured'); ?>><?php _e('Featured Items'); ?></option>
          <option value="upcoming" <?php selected($sessions, 'upcoming'); ?>><?php _e('Upcoming Items'); ?></option>
          <option value="recent" <?php selected($sessions, 'recent'); ?>><?php _e('Recently Added'); ?></option>
        </select>
      </p>
		<?php
	}

	/**
	 * Sanitize widget form values as they are saved
	 */
	public function update($new_instance, $old_instance) {
		$instance = [];
		$instance['title'] = (!empty($new_instance['title']))
			? strip_tags($new_instance['title'])
			: '';
		$instance['sale_uuid'] = (!empty($new_instance['sale_uuid']))
			? strip_tags($new_instance['sale_uuid'])
			: '';
		$instance['sessions'] = (!empty($new_instance['sessions']))
			? strip_tags($new_instance['sessions'])
			: 'full';
		return $instance;
	}
}

/**
 * Register the Sale Sessions widget
 */
function ca_register_sale_sessions_block() {
	register_widget('Ca_Sale_Sessions_Block');
}
add_action('widgets_init', 'ca_register_sale_sessions_block');

/**
 * Enqueue necessary scripts and styles for the block
 */
function ca_enqueue_sale_sessions_assets() {
	wp_enqueue_style(
		'ca-sale-sessions-style',
		plugins_url('css/sale-sessions.css', __FILE__),
		[],
		'1.0.0'
	);

	wp_enqueue_script(
		'ca-sale-sessions-script',
		plugins_url('js/sale-sessions.js', __FILE__),
		['jquery'],
		'1.0.0',
		true
	);

	// Add localized script data
	wp_localize_script('ca-sale-sessions-script', 'caSaleSessions', [
		'ajaxUrl' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('ca-sale-sessions-nonce'),
		'backendUrl' => get_option('ca_circuit_bid_backend_url', 'https://circuit-bid.ddev.site:4443'),
		'siteShortName' => get_option('ca_site_short_name', 'hk')
	]);
}
add_action('wp_enqueue_scripts', 'ca_enqueue_sale_sessions_assets');

/**
 * Register block for Gutenberg editor
 */
function ca_register_sale_sessions_gutenberg_block() {
	if (!function_exists('register_block_type')) {
		return;
	}

	wp_register_script(
		'ca-sale-sessions-editor',
		plugins_url('js/sale-sessions-editor.js', __FILE__),
		['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
		'1.0.0'
	);

	register_block_type('circuit-auction/sale-sessions', [
		'editor_script' => 'ca-sale-sessions-editor',
		'render_callback' => 'ca_render_sale_sessions_block',
		'attributes' => [
			'sale_uuid' => [
				'type' => 'string',
				'default' => ''
			],
			'sessions' => [
				'type' => 'string',
				'default' => 'full'
			]
		]
	]);
}
add_action('init', 'ca_register_sale_sessions_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_sale_sessions_block($attributes) {
	$sale_id = $attributes['sale_id'];

	ob_start();
	?>
  <div class="ca-sale-sessions"
       data-sale-id="<?php echo esc_attr($sale_id); ?>">
    <div class="ca-loading">Loading catalog data...</div>
  </div>
	<?php
	return ob_get_clean();
}

/**
 * AJAX handler for loading catalog data
 */
function ca_ajax_load_sale_sessions() {
	check_ajax_referer('ca-sale-sessions-nonce', 'nonce');

	$sale_id = isset($_POST['sale_id']) ? sanitize_text_field($_POST['sale_id']) : '';
	$sale_nid = ca_items_get_custom_meta($sale_id, 'nid');

	// Default to the first page of results
	$_GET += [
		'sort'  => 'field_lot_number',
    // we just need facets so one result is enough.
		'range' => 1,
	];

	$_GET['filter'] = [];
	// Merge filters with defaults
	$_GET['filter'] += [
		'field_sale' => [
			'value' => $sale_nid,
		],
		'language'   => [
			'value' => 'en',
		],
	];

	$results = ca_sale_search();
	$self_url = get_permalink($sale_id);

	ob_start();

  // debug info of $results
  // Debug search parameters
//  ca_debug([
//    'sale_id' => $sale_id,
//    'sale_nid' => $sale_nid,
//    'filters' => $_GET['filter'],
//    'sort' => $_GET['sort'],
//    'range' => $_GET['range']
//  ], 'Search Parameters');
	// No results handling
	if (empty($results['facets']) && empty($results['items'])) {
		?>
      <div class="ca-sessions">
        <div class="ca-error">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
          <p><?php _e('No catalog items found for this selection.', 'text_domain'); ?></p>
        </div>
      </div>
		<?php
		$html = ob_get_clean();
		wp_send_json_success([
			'html' => $html,
			'total_items' => 0,
		]);
		return;
	}

	// Render Sessionss
	$field_name = 'field_catalogue_part';
	if (!empty($results['facets'][$field_name])) {
		$field_display_name = $results['facets_titles'][$field_name]['title'] ?? __('Catalog Sections', 'text_domain');
		?>
      <div class="ca-sessions">
        <h3>
			<?php echo esc_html($field_display_name); ?>
          <span class="total-items"><?php printf(_n('(%d item)', '(%d items)', $results['total'], 'text_domain'), $results['total']); ?></span>
        </h3>
        <ul class="horizontal-list <?php echo esc_attr($field_name); ?>">
              <li>
                <a href="<?php echo esc_url(remove_query_arg('sessions', $self_url)); ?>"
                   class="view-all"
                   rel="nofollow">
					<?php _e('View All', 'text_domain'); ?>
                  <span class="count">(<?php echo esc_html($results['total']); ?>)</span>
                </a>
              </li>

			<?php foreach ($results['facets'][$field_name] as $term): ?>
              <li>
                <a href="<?php echo esc_url(ca_sale_get_facet_url($term['tid'], $field_name, $self_url)); ?>"
                   class="<?php echo $term['tid'] === $sessions ? 'active' : ''; ?>"
                   rel="nofollow">
					<?php echo esc_html($term['label']); ?>
                  <span class="count">(<?php echo esc_html($term['count']); ?>)</span>
                </a>
              </li>
			<?php endforeach; ?>
        </ul>
      </div>
		<?php
	}

	$html = ob_get_clean();

	wp_send_json_success([
		'html' => $html,
		'sale_id' => $sale_id,
		'total_items' => $results['total'] ?? 0,
	]);
}

add_action('wp_ajax_ca_load_sale_sessions', 'ca_ajax_load_sale_sessions');
add_action('wp_ajax_nopriv_ca_load_sale_sessions', 'ca_ajax_load_sale_sessions');