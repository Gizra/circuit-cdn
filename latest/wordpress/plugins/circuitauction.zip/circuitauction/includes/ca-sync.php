<?php

function ca_sync_register_custom_rest_route() {
	register_rest_route( 'ca/v1', '/item', [
		'methods'             => 'POST',
		/**
		 * @see ca_sync_create_update_item_from_json()
		 */
		'callback'            => 'ca_sync_create_update_item_from_json',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
	] );

}

add_action( 'rest_api_init', 'ca_sync_register_custom_rest_route' );

/**
 * Menu callback
 */
function ca_sync_create_update_item_from_json( WP_REST_Request $request ) {
	// Access request data (e.g., $_POST).
	$item_data              = [];
	$item_data['uuid']      = $request->get_param( 'uuid' );
	$item_data['json_data'] = json_decode( $request->get_param( 'json_data' ) );
	$item_data['language']  = $request->get_param( 'language' );
	// TODO: replace with default language.
	// Title for admin pages.
	$title                    = $item_data['json_data']->{$item_data['language']}->sale_title;
	$item_data['last_update'] = $request->get_param( 'last_update' );
	$item_data['sold_status'] = $request->get_param( 'sold_status' );

	$sale_uuid = $request->get_param( 'sale_uuid' );
	$sale_id   = ca_get_post_id_by_uuid( $sale_uuid, 'sale' );
	// Create sale if it doesn't exist.
	if ( empty( $sale_id ) ) {
		// Prevent from multiple AQ to create more then one of the same sale.
		// Define the name of the lock file.
		$lock_file = __FILE__ . '-' . __FUNCTION__ . '-' . $sale_uuid . '.lock';

		// Check if the lock file already exists. If it does, wait till it's
		// removed, and get the post id again.
		if ( file_exists( $lock_file ) ) {
			while ( file_exists( $lock_file ) ) {
				sleep( 1 );
			}
			$sale_id = ca_get_post_id_by_uuid( $sale_uuid, 'sale' );
			if ( empty( $sale_id ) ) {
				return new WP_Error( 'ca_sync_create_update_item_from_json', 'Sale creation error with locking.' );
			}
		} else {
			// Create the lock file.
			touch( $lock_file );
			$sale_id = ca_sync_create_sale( $sale_uuid, $request );
			// Remove the lock file.
			unlink( $lock_file );
		}
	}

  // Just update sale.
  $sale_update = $request->get_param( 'sale_update' ) ?? FALSE;
  if ( $sale_update ) {
    return ca_sync_update_sale_from_server( $sale_id, $sale_update );
  }

	$item_data['sale'] = $sale_id;

	// check if item already exists.
	$item_id = ca_get_post_id_by_uuid( $item_data['uuid'] );
	$type    = 'replace';
	// Prevent save hook to run again.
	define( 'DOING_AUTOSAVE', TRUE );
	// if post exists, update it, otherwise create a new post.
	if ( empty( $item_id ) ) {
		// Perform an insert.
		$type = 'insert';
		// create a new post
		$item_id = wp_insert_post( [
			'post_title'  => $title,
			'post_status' => 'publish',
			'post_type'   => 'item',
		], TRUE );
	} else {
		// update the post
		$item_id = wp_update_post( [
			'ID'          => $item_id,
			'post_title'  => $title,
			'post_status' => 'publish',
			'post_type'   => 'item',
		], TRUE );
	}

	// If post was created or updated successfully, set its metadata and
	// custom field.
	if ( ! is_wp_error( $item_id ) ) {
		// loop through each piece of metadata and add it to the post
		foreach ( $item_data as $meta_key => $meta_value ) {
			ca_items_create_custom_meta_field( $item_id, $meta_key, $meta_value, $type );
		}
	}
	$message = "Item {$item_id} was created/updated successfully.";
	error_log( $message );

	return new WP_REST_Response( [
		'status'  => 'success',
		'item_id' => $item_id,
	], 200 );
}

/**
 * Update sale meta data from BO.
 */
function ca_sync_update_sale_from_server( $post_id, $sale_nid = FALSE ) {
	if ( empty( $sale_nid ) ) {
		$sale_nid = ca_items_get_custom_meta( $post_id, 'nid' );
	}
	// Base url for the API.
	$url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/get-sale-info/' . $sale_nid;

	// Use WordPress's built-in HTTP API to fetch the JSON data
	$response = wp_remote_get( $url );

	// Check for an error in the response
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'server-error', __( 'Unable to retrieve sale data.', 'text-domain' ) );
	}

	// Parse the JSON response body
	$data = json_decode( wp_remote_retrieve_body( $response ), TRUE );

	// Check for JSON decoding error or empty data
	if ( NULL === $data || empty( $data ) ) {
		return new WP_Error( 'json-error', __( 'Invalid or empty JSON response.', 'text-domain' ) );
	}
	ca_items_create_custom_meta_field( $post_id, 'json_data', $data, 'replace' );

	return TRUE;
}


/**
 *  Sync process:
 *
 * 1. Drupal AQ pushes Item to WP one by one.
 * 2. look for item UUID.
 * 3. Create/update/item sale post
 */
function ca_sync_create_sale( $sale_uuid, WP_REST_Request $request ) {
	$sale_data                = [];
	$title                    = $request->get_param( 'sale_title' );
	$sale_data['language']    = $request->get_param( 'language' );
	$sale_data['last_update'] = $request->get_param( 'last_update' );
	$sale_data['uuid']        = $sale_uuid;
	$sale_data['sale_status'] = $request->get_param( 'sale_status' );
	$sale_data['nid']         = $request->get_param( 'sale_nid' );

	// Prevent from hook save (ca_items_save_meta_data()) to save the item's
	// data again.
	define( 'DOING_AUTOSAVE', TRUE );

	// create a new post
	$sale_id = wp_insert_post( [
		'post_title'  => $title,
		'post_status' => 'publish',
		'post_type'   => 'sale',
	], TRUE );

	// If post was created or updated successfully, set its metadata and
	// custom field.
	if ( ! is_wp_error( $sale_id ) ) {
		// loop through each piece of metadata and add it to the post
		foreach ( $sale_data as $meta_key => $meta_value ) {
			ca_items_create_custom_meta_field( $sale_id, $meta_key, $meta_value );
		}
	}

	$message = "Sale {$sale_id} was created/updated successfully.";
	error_log( $message );

	// Get sale info from BO.
	ca_sync_update_sale_from_server( $sale_id, $sale_data['nid'] );

	return $sale_id;
}

/**
 * Authentication handler for the JSON API, used for development and debugging
 * purposes
 */
function ca_sync_json_basic_auth_handler( $user ) {
	global $wp_json_basic_auth_error;

	$wp_json_basic_auth_error = NULL;

	// Don't authenticate twice
	if ( ! empty( $user ) ) {
		return $user;
	}

	// Check that we're trying to authenticate
	if ( ! isset( $_SERVER['PHP_AUTH_USER'] ) ) {
		return $user;
	}

	$username = $_SERVER['PHP_AUTH_USER'];
	$password = $_SERVER['PHP_AUTH_PW'];

	/**
	 * In multi-site, wp_authenticate_spam_check filter is run on authentication. This filter calls
	 * get_currentuserinfo which in turn calls the determine_current_user filter. This leads to infinite
	 * recursion and a stack overflow unless the current function is removed from the determine_current_user
	 * filter during authentication.
	 */
	remove_filter( 'determine_current_user', 'json_basic_auth_handler', 20 );

	$user = wp_authenticate( $username, $password );

	add_filter( 'determine_current_user', 'ca_sync_json_basic_auth_handler', 20 );

	if ( is_wp_error( $user ) ) {
		$wp_json_basic_auth_error = $user;

		return NULL;
	}

	$wp_json_basic_auth_error = TRUE;

	return $user->ID;
}

add_filter( 'determine_current_user', 'ca_sync_json_basic_auth_handler', 20 );


/**
 * @param $error
 *
 * @return mixed
 */
function ca_sync_json_basic_auth_error( $error ) {
	// Passthrough other errors
	if ( ! empty( $error ) ) {
		return $error;
	}

	global $wp_json_basic_auth_error;

	return $wp_json_basic_auth_error;
}

add_filter( 'rest_authentication_errors', 'ca_sync_json_basic_auth_error' );

