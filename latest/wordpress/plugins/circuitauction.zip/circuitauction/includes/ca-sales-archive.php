<?php

/**
 * Sales Archive functionality for CircuitAuction plugin
 * UPDATED: Fixed pagination to use 'pager' parameter and range configuration
 */

/**
 * Get departments from the API for the filter dropdown
 */
function ca_sales_archive_get_departments() {
    $base_url = get_option('ca_bo_base_url', 'https://backoffice.ddev.site');
    $url = $base_url . '/api/v1.0/departments';
    
    $response = wp_remote_get($url, [
        'timeout' => 30,
        'headers' => [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        ]
    ]);
    
    if (is_wp_error($response)) {
        error_log('Departments API Error: ' . $response->get_error_message());
        return [];
    }
    
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('Departments JSON Error: ' . json_last_error_msg());
        return [];
    }
    
    return isset($data['data']) ? $data['data'] : [];
}

/**
 * Get years from sales data for the year filter dropdown
 */
function ca_sales_archive_get_years() {
    // Get all sales to extract years
    $args = [
        'range' => 1000, // Get a large number to capture all years
        'sort' => 'id',
        'order' => 'desc'
    ];
    
    $sales_data = ca_sales_archive_fetch_sales($args);
    $years = [];
    
    if ($sales_data['success'] && !empty($sales_data['data'])) {
        foreach ($sales_data['data'] as $sale) {
            if (isset($sale['live_sale_date_from']) && $sale['live_sale_date_from']) {
                $year = date('Y', $sale['live_sale_date_from'] / 1000);
                $years[$year] = $year;
            }
        }
    }
    
    // Sort years in descending order
    krsort($years);
    return $years;
}

/**
 * Fetch sales from the backoffice API
 *
 * @param array $args Optional arguments for the API call
 * @param array $config Configuration options
 * @return array API response
 */
function ca_sales_archive_fetch_sales($args = [], $config = []) {
    $default_args = [
        'page' => 1,
        'range' => 20,
        'sort' => 'id',
        'order' => 'desc'
    ];
    
    $default_config = [
        'status_filter' => 'both',
    ];
    
    $args = array_merge($default_args, $args);
    $config = array_merge($default_config, $config);
    
    // Build the API URL
    $base_url = get_option('ca_bo_base_url', 'https://backoffice.ddev.site');
    $url = $base_url . '/api/v1.0/sales-public';
    
    // Build query parameters
    $query_params = [];
    
    // Add pagination
    if (isset($args['page']) && $args['page'] > 1) {
        $query_params['page'] = $args['page'];
    }
    
    if (isset($args['range'])) {
        $query_params['range'] = $args['range'];
    }
    
    // Add sorting - be more specific to avoid SQL errors
    if (isset($args['sort'])) {
        $query_params['sort'] = $args['sort'];
        // Always provide order when sort is provided
        $query_params['order'] = isset($args['order']) ? $args['order'] : 'desc';
    }
    
    // Add fields we need
    $query_params['fields'] = 'uuid,id,label,subtitle,description,status,logo,live_sale_date_from,live_sale_date_to,departments';
    
    // Handle status filtering based on config
    if ($config['status_filter'] === 'published') {
        $query_params['filter[status][conjunction]'] = 'AND';
        $query_params['filter[status][operator]'] = '=';
        $query_params['filter[status][value]'] = 'published_on_site';
    } elseif ($config['status_filter'] === 'finished') {
        $query_params['filter[status][conjunction]'] = 'AND';
        $query_params['filter[status][operator]'] = '=';
        $query_params['filter[status][value]'] = 'finished';
    } else {
        // Default: both finished and published_on_site - use IN operator
        $query_params['filter[status][conjunction]'] = 'AND';
        $query_params['filter[status][operator]'] = 'IN';
        $query_params['filter[status][value]'] = ['finished', 'published_on_site'];
    }
    
    // Add additional filters
    if (isset($args['filters']) && is_array($args['filters'])) {
        foreach ($args['filters'] as $key => $value) {
            if ($key === 'departments' && !empty($value)) {
                $query_params['filter[departments]'] = $value;
            } elseif ($key === 'year' && !empty($value)) {
                // Simple year filter - now supported by the API
                $query_params['filter[year]'] = $value;
                error_log('Year filter debug - Using simple year: ' . $value);
            } elseif ($key === 'search' && !empty($value)) {
                // Add text search filter for title using the exact format from the working URL
                $query_params['filter[label][conjunction]'] = 'AND';
                $query_params['filter[label][operator]'] = 'CONTAINS';
                $query_params['filter[label][value]'] = $value;
                error_log('Text search filter - Searching for: ' . $value);
            } elseif ($key === 'status' && !empty($value) && $config['status_filter'] === 'both') {
                // Override default status filter if user selected specific status
                $query_params['filter[status][conjunction]'] = 'AND';
                $query_params['filter[status][operator]'] = '=';
                $query_params['filter[status][value]'] = $value;
                error_log('Status filter debug - Using status: ' . $value);
            } else {
                $query_params['filter[' . $key . ']'] = $value;
            }
        }
    }
    
    // Build final URL
    if (!empty($query_params)) {
        $url .= '?' . http_build_query($query_params);
    }
    
    // Log the request URL for debugging
    error_log('Sales Archive API URL: ' . $url);
    
    // Make the API request
    $request_args = [
        'timeout' => 30,
        'headers' => [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
        ]
    ];
    
    $response = wp_remote_get($url, $request_args);
    
    if (is_wp_error($response)) {
        error_log('Sales Archive API Error: ' . $response->get_error_message());
        if (get_option('ca_log_api_requests', false)) {
            ca_set_custom_message('Sales Archive API Error: ' . $response->get_error_message(), 'error');
        }
        return [
            'success' => false,
            'error' => $response->get_error_message(),
            'data' => []
        ];
    }
    
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('Sales Archive JSON Error: ' . json_last_error_msg());
        return [
            'success' => false,
            'error' => 'Invalid JSON response',
            'data' => [],
            'count' => 0
        ];
    }
    
    // Extract the data array from the API response
    $sales_data = isset($data['data']) ? $data['data'] : [];
    $count = isset($data['count']) ? $data['count'] : 0;
    
    return [
        'success' => true,
        'data' => $sales_data,
        'count' => $count,
        'raw_response' => $data
    ];
}

/**
 * Get sales archive data for display
 * UPDATED: Changed to use 'pager' parameter instead of 'page'
 *
 * @param array $config Configuration options
 * @return array Formatted sales data
 */
function ca_sales_archive_get_data($config = []) {

    $page = isset($_GET['pager']) ? max(1, intval($_GET['pager'])) : 1;
    
    $range = isset($_GET['limit']) ? max(1, min(100, intval($_GET['limit']))) : (isset($config['range']) ? $config['range'] : 20);    
    
    $sort = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'id';
    $order = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : 'desc';
    
    $args = [
        'page' => $page,
        'range' => $range,
        'sort' => $sort,
        'order' => $order
    ];
    
    // Add filters if they exist and are allowed by config
    if (isset($_GET['filter']) && is_array($_GET['filter'])) {
        $filters = [];
        foreach ($_GET['filter'] as $key => $value) {
            if (!empty($value)) {
                $filters[sanitize_text_field($key)] = sanitize_text_field($value);
            }
        }
        if (!empty($filters)) {
            $args['filters'] = $filters;
        }
    }
    
    // Add search parameter if allowed by config
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        if (!isset($args['filters'])) {
            $args['filters'] = [];
        }
        $args['filters']['search'] = sanitize_text_field($_GET['search']);
    }
    
    // Add display mode parameter
    if (isset($_GET['display_mode']) && !empty($_GET['display_mode'])) {
        $config['display_mode'] = sanitize_text_field($_GET['display_mode']);
    }
    if (isset($_GET['limit'])) {
        $base_params['limit'] = $_GET['limit'];
    }
    
    // Debug the configuration being used
    error_log('Sales Archive Config - range: ' . $range . ', Page: ' . $page);
    
    return ca_sales_archive_fetch_sales($args, $config);
}

/**
 * Format date for display
 */
function ca_sales_archive_format_date($timestamp) {
    if (!$timestamp) {
        return '';
    }
    
    // Convert from milliseconds to seconds
    $timestamp = $timestamp / 1000;
    
    // Format as "Jan. 12, 2025 7pm"
    return date('M. j, Y g\p\m', $timestamp);
}

/**
 * Render the sales archive page
 *
 * @param array $args Configuration arguments
 */
function ca_sales_archive_render($args = []) {
    $defaults = [
        'status_filter' => 'both',        // 'published', 'finished', 'both'
        'display_mode' => 'full',         // 'full', 'minimal'
        'range' => 20,
        'show_pagination' => true,
        
        // Granular filter control
        'filters' => [
            'search' => true,             // show/hide search input
            'year' => true,               // show/hide year dropdown  
            'department' => true,         // show/hide department dropdown
            'status' => true,             // show/hide status dropdown
            'per_page' => true,           // show/hide sales per page dropdown
        ],
        
        'show_filter_actions' => true,    // show/hide Apply/Clear buttons
        'show_results_count' => true,     // show/hide "Showing X of Y" text
    ];
    
    $config = array_merge($defaults, $args);
    
    // Debug the final configuration
    error_log('Sales Archive Render Config: ' . print_r($config, true));
    
    wp_enqueue_style('ca-sales-archive', plugin_dir_url(__FILE__) . 'css/ca-sales-archive.css', [], '1.0.0');
    wp_enqueue_script('ca-sales-archive', plugin_dir_url(__FILE__) . 'js/sales-archive.js', ['jquery'], '1.0.0', true);
    
    $data = ca_sales_archive_get_data($config);
    
    // Only get departments and years if their filters are shown
    $departments = $config['filters']['department'] ? ca_sales_archive_get_departments() : [];
    $years = $config['filters']['year'] ? ca_sales_archive_get_years() : [];
    
    // Get current filter values
    $current_department = isset($_GET['filter']['departments']) ? sanitize_text_field($_GET['filter']['departments']) : '';
    $current_year = isset($_GET['filter']['year']) ? sanitize_text_field($_GET['filter']['year']) : '';
    $current_search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
    $current_status = isset($_GET['filter']['status']) ? sanitize_text_field($_GET['filter']['status']) : $config['status_filter'];
    $current_display_mode = isset($_GET['display_mode']) ? sanitize_text_field($_GET['display_mode']) : $config['display_mode'];
    
    if (!$data['success']) {
        echo '<div class="ca-sales-archive-error">';
        echo '<h3>Error loading sales archive</h3>';
        echo '<p>' . esc_html($data['error']) . '</p>';
        echo '</div>';
        return;
    }
    
    $sales = $data['data'];
    $count = $data['count'];
    
    // Check if any filters should be shown
    $show_any_filters = array_filter($config['filters']) || $config['show_filter_actions'];
    
    ?>
    <div class="ca-sales-archive">
        <div class="ca-sales-archive-header">
            <h1>Sales Archive</h1>
            
            <?php if ($config['show_results_count']): ?>
                <div class="ca-sales-archive-count">
                    <p>Showing <?php echo count($sales); ?> of <?php echo $count; ?> Sales</p>
                </div>
            <?php endif; ?>
            
            <?php if ($show_any_filters): ?>
                <div class="ca-sales-archive-filters">
                    <form method="GET" action="">
                        <div class="filter-row">                            
                            <?php if ($config['filters']['search']): ?>
                                <div class="filter-group search-group">
                                    <label for="search">Search by title:</label>
                                    <input type="text" 
                                           name="search" 
                                           id="search" 
                                           value="<?php echo esc_attr($current_search); ?>" 
                                           placeholder="Enter sale title..."
                                           class="search-input">
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($config['filters']['year'] && !empty($years)): ?>
                                <div class="filter-group">
                                    <label for="filter_year">Year:</label>
                                    <select name="filter[year]" id="filter_year">
                                        <option value="">All Years</option>
                                        <?php foreach ($years as $year): ?>
                                            <option value="<?php echo esc_attr($year); ?>" <?php selected($current_year, $year); ?>>
                                                <?php echo esc_html($year); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($config['filters']['department'] && !empty($departments)): ?>
                                <div class="filter-group">
                                    <label for="filter_department">Department:</label>
                                    <select name="filter[departments]" id="filter_department">
                                        <option value="">All Departments</option>
                                        <?php foreach ($departments as $department): ?>
                                            <?php 
                                            $dept_name = isset($department['label']) ? $department['label'] : '';
                                            $dept_id = isset($department['id']) ? $department['id'] : '';
                                            ?>
                                            <option value="<?php echo esc_attr($dept_id); ?>" <?php selected($current_department, $dept_id); ?>>
                                                <?php echo esc_html($dept_name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($config['filters']['status'] && $config['status_filter'] === 'both'): ?>
                                <div class="filter-group">
                                    <label for="filter_status">Status:</label>
                                    <select name="filter[status]" id="filter_status">
                                        <option value="">All Statuses</option>
                                        <option value="published_on_site" <?php selected($current_status, 'published_on_site'); ?>>Published on Site</option>
                                        <option value="finished" <?php selected($current_status, 'finished'); ?>>Finished</option>
                                    </select>
                                </div>
                            <?php endif; ?>

                            <?php if ($config['filters']['per_page']): ?>
                                <div class="filter-group">
                                    <label for="items_per_page">Sales per page:</label>
                                    <select name="limit" id="items_per_page">
                                        <?php $current_limit = isset($_GET['limit']) ? max(1, min(100, intval($_GET['limit']))) : $config['range']; ?>
                                        <option value="2" <?php selected($current_limit, 2); ?>>2</option>
                                        <option value="10" <?php selected($current_limit, 10); ?>>10</option>
                                        <option value="20" <?php selected($current_limit, 20); ?>>20</option>
                                        <option value="30" <?php selected($current_limit, 30); ?>>30</option>
                                        <option value="50" <?php selected($current_limit, 50); ?>>50</option>
                                    </select>
                                </div>
                            <?php endif; ?>

                            
                            
                            <div class="filter-group">
                                <label for="display_mode">View:</label>
                                <select name="display_mode" id="display_mode">
                                    <option value="full" <?php selected($current_display_mode, 'full'); ?>>Full View</option>
                                    <option value="minimal" <?php selected($current_display_mode, 'minimal'); ?>>Minimal View</option>
                                </select>
                            </div>

                        </div>
                        
                        <?php if ($config['show_filter_actions']): ?>
                            <div class="filter-actions">
                                <button type="submit" class="filter-apply">Search & Filter</button>
                                <button type="button" class="filter-clear" onclick="window.location.href = window.location.pathname;">Clear All</button>

                                <?php if ($config['show_view_toggle'] ?? true): ?>
                                    <div class="view-toggle">
                                        <button type="button" class="view-btn view-btn-row active" data-view="row">
                                            <i class="fa fa-th-list"></i>
                                        </button>
                                        <button type="button" class="view-btn view-btn-grid" data-view="grid">
                                            <i class="fa fa-th"></i>
                                        </button>
                                    </div>
                                <?php endif; ?>


                            </div>
                        <?php endif; ?>
                        
                        <!-- Hidden fields to preserve config when status_filter is forced -->
                        <?php if ($config['status_filter'] !== 'both'): ?>
                            <input type="hidden" name="status_filter" value="<?php echo esc_attr($config['status_filter']); ?>">
                        <?php endif; ?>
                    </form>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="ca-sales-archive-content">
            <?php if (empty($sales)) : ?>
                <div class="ca-sales-archive-empty">
                    <?php if (!empty($current_search)): ?>
                        <p>No sales found matching your search criteria.</p>
                    <?php else: ?>
                        <p>No public sales found.</p>
                    <?php endif; ?>
                </div>
            <?php else : ?>
                <?php if (!empty($current_search)): ?>
                    <div class="ca-sales-archive-search-info">
                        <p>Search results for: <strong><?php echo esc_html($current_search); ?></strong></p>
                    </div>
                <?php endif; ?>
                
                <div class="ca-sales-archive-list ca-sales-archive-<?php echo esc_attr($current_display_mode); ?>">
                    <?php foreach ($sales as $sale) : ?>
                        <?php if ($current_display_mode === 'minimal'): ?>
                            <?php ca_sales_archive_render_minimal_item($sale); ?>
                        <?php else: ?>
                            <?php ca_sales_archive_render_full_item($sale); ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <?php 
        // Use the actual range from URL or config
        $actual_range = isset($_GET['limit']) ? max(1, min(100, intval($_GET['limit']))) : $config['range'];
        ?>
        <?php if ($config['show_pagination'] && $count > $actual_range): ?>
            <div class="ca-sales-archive-pagination">
                <?php
                // CHANGED: Use 'pager' parameter instead of 'page'
                $current_page = isset($_GET['pager']) ? max(1, intval($_GET['pager'])) : 1;
                $total_pages = max(1, ceil($count / $actual_range));
                
                if ($total_pages > 1) {
                    $base_params = [];
                    
                    // Preserve current filters
                    if (isset($_GET['search']) && !empty($_GET['search'])) {
                        $base_params['search'] = $_GET['search'];
                    }
                    if (isset($_GET['filter']) && is_array($_GET['filter'])) {
                        foreach ($_GET['filter'] as $key => $value) {
                            if (!empty($value)) {
                                $base_params['filter'][$key] = $value;
                            }
                        }
                    }
                    if (isset($_GET['display_mode'])) {
                        $base_params['display_mode'] = $_GET['display_mode'];
                    }
                    if (isset($_GET['limit'])) {
                        $base_params['limit'] = $_GET['limit'];
                    }
                    
                    ca_render_pagination_links($current_page, $total_pages, $base_params);
                }
                ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Render a minimal sale item
 */
function ca_sales_archive_render_minimal_item($sale) {
    $title = isset($sale['label']['en']) ? $sale['label']['en'] : 'Untitled Sale';
    
    // Handle cases where title might be an array
    if (is_array($title) && isset($title['value'])) {
        $title = $title['value'];
    }
    
    $logo_url = '';
    if (isset($sale['logo'])) {
        if (is_string($sale['logo'])) {
            $logo_url = $sale['logo'];
        } elseif (is_array($sale['logo']) && isset($sale['logo']['url'])) {
            $logo_url = $sale['logo']['url'];
        }
    }
    

    // Use UUID to find WordPress post
    if (!empty($sale['uuid'])) {
        $sale_post_id = ca_get_post_id_by_uuid($sale['uuid'], 'sale');
        
        if ($sale_post_id) {
            $sale_url = get_permalink($sale_post_id);
        } else {
            $sale_url = '#'; // No WordPress post found
        }
    } else {
        $sale_url = '#'; // No UUID available
    }

    
    ?>
    <div class="ca-sales-archive-item-minimal">
        <a href="<?php echo esc_url($sale_url); ?>" class="ca-sales-archive-minimal-link">
            <div class="ca-sales-archive-minimal-logo">
                <?php if (!empty($logo_url)): ?>
                    <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($title); ?>">
                <?php else: ?>
                    <div class="no-logo">No Logo</div>
                <?php endif; ?>
            </div>
            <div class="ca-sales-archive-minimal-title">
                <h3><?php echo esc_html($title); ?></h3>
            </div>
        </a>
    </div>
    <?php
}

/**
 * Render a full sale item
 */
function ca_sales_archive_render_full_item($sale) {
    ?>
    <div class="ca-sales-archive-item">
        <div class="ca-sales-archive-item-header">
            <div class="ca-sales-archive-item-logo">
                <?php 
                $logo_url = '';
                if (isset($sale['logo'])) {
                    if (is_string($sale['logo'])) {
                        $logo_url = $sale['logo'];
                    } elseif (is_array($sale['logo']) && isset($sale['logo']['url'])) {
                        $logo_url = $sale['logo']['url'];
                    }
                }
                ?>
                <?php 
                    // Use UUID to find WordPress post
                    if (!empty($sale['uuid'])) {
                        $sale_post_id = ca_get_post_id_by_uuid($sale['uuid'], 'sale');
                        
                        if ($sale_post_id) {
                            $sale_url = get_permalink($sale_post_id);
                        } else {
                            $sale_url = '#'; // No WordPress post found
                        }
                    } else {
                        $sale_url = '#'; // No UUID available
                    }
                ?>
                <a href="<?php echo esc_url($sale_url); ?>">
                    <?php if (!empty($logo_url)): ?>
                        <img src="<?php echo esc_url($logo_url); ?>" alt="Sale Logo">
                    <?php else: ?>
                        <div class="no-logo">No Logo</div>
                    <?php endif; ?>
                </a>
            </div>
            
            <div class="ca-sales-archive-item-title">
                <?php 
                $title = isset($sale['label']['en']) ? $sale['label']['en'] : 'Untitled Sale';
                $subtitle = isset($sale['subtitle']['en']) ? $sale['subtitle']['en'] : '';
                $description = isset($sale['description']['en']) ? $sale['description']['en'] : '';

                // Handle cases where title might be an array
                if (is_array($title) && isset($title['value'])) {
                    $title = $title['value'];
                }
                if (is_array($subtitle) && isset($subtitle['value'])) {
                    $subtitle = $subtitle['value'];
                }
                ?>
                
                <h3><a href="<?php echo esc_url($sale_url); ?>"><?php echo esc_html($title); ?></a></h3>

                <?php if ($subtitle): ?>
                    <div class="ca-sales-archive-item-subtitle">
                        <a href="<?php echo esc_url($sale_url); ?>"><?php echo esc_html($subtitle); ?></a>
                    </div>
                <?php endif; ?>
                
                
            </div>
        </div>
        
        <?php 
        // Handle description - it might be an array or string
        $description_text = '';
        if (is_string($description)) {
            $description_text = $description;
        } elseif (is_array($description) && isset($description['value'])) {
            $description_text = $description['value'];
        } elseif (is_array($description) && isset($description['safe_value'])) {
            $description_text = $description['safe_value'];
        }
        ?>
        <?php if (!empty($description_text)): ?>
            <div class="ca-sales-archive-item-description">
                <?php echo wp_kses_post($description_text); ?>
            </div>
        <?php endif; ?>
        
        <div class="ca-sales-archive-meta">
            
            <?php 
            $live_start = isset($sale['live_sale_date_from']) ? $sale['live_sale_date_from'] : '';
            $live_end = isset($sale['live_sale_date_to']) ? $sale['live_sale_date_to'] : '';
            ?>
            
            <?php if ($live_start && $live_end) : ?>
                <div class="ca-sales-archive-dates">
                    <strong>Live Sale:</strong>
                    <span class="ca-sales-archive-date">
                        <?php echo esc_html(ca_sales_archive_format_date($live_start)); ?>
                        -
                        <?php echo esc_html(ca_sales_archive_format_date($live_end)); ?>
                    </span>
                </div>
            <?php elseif ($live_start) : ?>
                <div class="ca-sales-archive-dates">
                    <strong>Live Sale:</strong>
                    <span class="ca-sales-archive-date">
                        <?php echo esc_html(ca_sales_archive_format_date($live_start)); ?>
                    </span>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

/**
 * AJAX handler for sales archive data
 */
function ca_sales_archive_ajax_handler() {
    check_ajax_referer('ca_sales_archive_nonce', 'nonce');
    
    $data = ca_sales_archive_get_data();
    
    wp_send_json($data);
}

/**
 * Render pagination links for sales archive
 * UPDATED: Changed to use 'pager' parameter instead of 'page'
 */
function ca_render_pagination_links($current_page, $total_pages, $base_params = []) {
    $range = 2; // Show 2 pages before and after current
    $links = [];
    
    // Previous link - CHANGED: use 'pager' instead of 'page'
    if ($current_page > 1) {
        $prev_params = array_merge($base_params, ['pager' => $current_page - 1]);
        $links[] = '<a href="?' . http_build_query($prev_params) . '" class="prev-page">&laquo; Previous</a>';
    }
    
    // First page - CHANGED: use 'pager' instead of 'page'
    if ($current_page > $range + 1) {
        $first_params = array_merge($base_params, ['pager' => 1]);
        $links[] = '<a href="?' . http_build_query($first_params) . '" class="page-number">1</a>';
        if ($current_page > $range + 2) {
            $links[] = '<span class="dots">...</span>';
        }
    }
    
    // Pages around current page - CHANGED: use 'pager' instead of 'page'
    for ($i = max(1, $current_page - $range); $i <= min($total_pages, $current_page + $range); $i++) {
        if ($i == $current_page) {
            $links[] = '<span class="current-page">' . $i . '</span>';
        } else {
            $page_params = array_merge($base_params, ['pager' => $i]);
            $links[] = '<a href="?' . http_build_query($page_params) . '" class="page-number">' . $i . '</a>';
        }
    }
    
    // Last page - CHANGED: use 'pager' instead of 'page'
    if ($current_page < $total_pages - $range) {
        if ($current_page < $total_pages - $range - 1) {
            $links[] = '<span class="dots">...</span>';
        }
        $last_params = array_merge($base_params, ['pager' => $total_pages]);
        $links[] = '<a href="?' . http_build_query($last_params) . '" class="page-number">' . $total_pages . '</a>';
    }
    
    // Next link - CHANGED: use 'pager' instead of 'page'
    if ($current_page < $total_pages) {
        $next_params = array_merge($base_params, ['pager' => $current_page + 1]);
        $links[] = '<a href="?' . http_build_query($next_params) . '" class="next-page">Next &raquo;</a>';
    }
    
    echo '<div class="pagination-links">' . implode('', $links) . '</div>';
    echo '<div class="pagination-info">Page ' . $current_page . ' of ' . $total_pages . '</div>';
}

// Register AJAX handlers
add_action('wp_ajax_ca_sales_archive', 'ca_sales_archive_ajax_handler');
add_action('wp_ajax_nopriv_ca_sales_archive', 'ca_sales_archive_ajax_handler');

/**
 * Sales Archive Widget Class
 */
class Ca_Sales_Archive_Widget extends WP_Widget {
    
    function __construct() {
        parent::__construct(
            'ca_sales_archive_widget',
            __('Circuit Auction - Sales Archive', 'text_domain'),
            ['description' => __('Display sales archive with configurable options', 'text_domain')]
        );
    }
    
    public function widget($args, $instance) {
        wp_enqueue_style('ca-sales-archive', plugin_dir_url(__FILE__) . 'css/ca-sales-archive.css', [], '1.0.0');
        wp_enqueue_script('ca-sales-archive', plugin_dir_url(__FILE__) . 'js/sales-archive.js', ['jquery'], '1.0.0', true);
        

        $config = [
            'status_filter' => $instance['status_filter'] ?? 'both',
            'display_mode' => $instance['display_mode'] ?? 'full',
            'range' => $instance['range'] ?? 20,
            'show_pagination' => $instance['show_pagination'] ?? true,
            'show_view_toggle' => $instance['show_view_toggle'] ?? true,
            'filters' => [
                'search' => $instance['show_search'] ?? true,
                'year' => $instance['show_year_filter'] ?? true,
                'department' => $instance['show_department_filter'] ?? true,
                'status' => $instance['show_status_filter'] ?? true,
                'per_page' => $instance['show_per_page_filter'] ?? true,
            ],
            'show_filter_actions' => $instance['show_filter_actions'] ?? true,
            'show_results_count' => $instance['show_results_count'] ?? true,
        ];

        echo $args['before_widget'];
        if (!empty($instance['title'])) {
            echo $args['before_title'] . $instance['title'] . $args['after_title'];
        }
        
        ca_sales_archive_render($config);
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : 'Sales Archive';
        $range = !empty($instance['range']) ? $instance['range'] : 20;
        $display_mode = !empty($instance['display_mode']) ? $instance['display_mode'] : 'full';
        $show_view_toggle = isset($instance['show_view_toggle']) ? (bool) $instance['show_view_toggle'] : true;
        $status_filter = !empty($instance['status_filter']) ? $instance['status_filter'] : 'both';
        $show_search = isset($instance['show_search']) ? (bool) $instance['show_search'] : true;
        $show_year_filter = isset($instance['show_year_filter']) ? (bool) $instance['show_year_filter'] : true;
        $show_department_filter = isset($instance['show_department_filter']) ? (bool) $instance['show_department_filter'] : true;
        $show_status_filter = isset($instance['show_status_filter']) ? (bool) $instance['show_status_filter'] : true;
        $show_pagination = isset($instance['show_pagination']) ? (bool) $instance['show_pagination'] : true;
        $show_filter_actions = isset($instance['show_filter_actions']) ? (bool) $instance['show_filter_actions'] : true;
        $show_results_count = isset($instance['show_results_count']) ? (bool) $instance['show_results_count'] : true;
        $show_per_page_filter = isset($instance['show_per_page_filter']) ? (bool) $instance['show_per_page_filter'] : true;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('range'); ?>"><?php _e('Items per page:'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('range'); ?>" name="<?php echo $this->get_field_name('range'); ?>">
                <option value="10" <?php selected($range, 10); ?>>10</option>
                <option value="20" <?php selected($range, 20); ?>>20</option>
                <option value="30" <?php selected($range, 30); ?>>30</option>
                <option value="50" <?php selected($range, 50); ?>>50</option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('display_mode'); ?>"><?php _e('Display Mode:'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('display_mode'); ?>" name="<?php echo $this->get_field_name('display_mode'); ?>">
                <option value="full" <?php selected($display_mode, 'full'); ?>>Full View</option>
                <option value="minimal" <?php selected($display_mode, 'minimal'); ?>>Minimal View</option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('status_filter'); ?>"><?php _e('Status Filter:'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('status_filter'); ?>" name="<?php echo $this->get_field_name('status_filter'); ?>">
                <option value="both" <?php selected($status_filter, 'both'); ?>>Both Published and Finished</option>
                <option value="published" <?php selected($status_filter, 'published'); ?>>Published Only</option>
                <option value="finished" <?php selected($status_filter, 'finished'); ?>>Finished Only</option>
            </select>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_per_page_filter); ?> id="<?php echo $this->get_field_id('show_per_page_filter'); ?>" name="<?php echo $this->get_field_name('show_per_page_filter'); ?>" />
            <label for="<?php echo $this->get_field_id('show_per_page_filter'); ?>"><?php _e('Show sales per page filter'); ?></label>
        </p>
        <h4><?php _e('Filter Options:'); ?></h4>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_search); ?> id="<?php echo $this->get_field_id('show_search'); ?>" name="<?php echo $this->get_field_name('show_search'); ?>" />
            <label for="<?php echo $this->get_field_id('show_search'); ?>"><?php _e('Show search filter'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_year_filter); ?> id="<?php echo $this->get_field_id('show_year_filter'); ?>" name="<?php echo $this->get_field_name('show_year_filter'); ?>" />
            <label for="<?php echo $this->get_field_id('show_year_filter'); ?>"><?php _e('Show year filter'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_department_filter); ?> id="<?php echo $this->get_field_id('show_department_filter'); ?>" name="<?php echo $this->get_field_name('show_department_filter'); ?>" />
            <label for="<?php echo $this->get_field_id('show_department_filter'); ?>"><?php _e('Show department filter'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_status_filter); ?> id="<?php echo $this->get_field_id('show_status_filter'); ?>" name="<?php echo $this->get_field_name('show_status_filter'); ?>" />
            <label for="<?php echo $this->get_field_id('show_status_filter'); ?>"><?php _e('Show status filter'); ?></label>
        </p>
        <h4><?php _e('Display Options:'); ?></h4>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_pagination); ?> id="<?php echo $this->get_field_id('show_pagination'); ?>" name="<?php echo $this->get_field_name('show_pagination'); ?>" />
            <label for="<?php echo $this->get_field_id('show_pagination'); ?>"><?php _e('Show pagination'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_filter_actions); ?> id="<?php echo $this->get_field_id('show_filter_actions'); ?>" name="<?php echo $this->get_field_name('show_filter_actions'); ?>" />
            <label for="<?php echo $this->get_field_id('show_filter_actions'); ?>"><?php _e('Show filter action buttons'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_results_count); ?> id="<?php echo $this->get_field_id('show_results_count'); ?>" name="<?php echo $this->get_field_name('show_results_count'); ?>" />
            <label for="<?php echo $this->get_field_id('show_results_count'); ?>"><?php _e('Show results count'); ?></label>
        </p>
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_view_toggle); ?> id="<?php echo $this->get_field_id('show_view_toggle'); ?>" name="<?php echo $this->get_field_name('show_view_toggle'); ?>" />
            <label for="<?php echo $this->get_field_id('show_view_toggle'); ?>"><?php _e('Show view toggle buttons'); ?></label>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = [];
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['range'] = (!empty($new_instance['range'])) ? intval($new_instance['range']) : 20;
        $instance['display_mode'] = (!empty($new_instance['display_mode'])) ? $new_instance['display_mode'] : 'full';
        $instance['show_view_toggle'] = !empty($new_instance['show_view_toggle']);
        $instance['status_filter'] = (!empty($new_instance['status_filter'])) ? $new_instance['status_filter'] : 'both';
        $instance['show_search'] = !empty($new_instance['show_search']);
        $instance['show_year_filter'] = !empty($new_instance['show_year_filter']);
        $instance['show_department_filter'] = !empty($new_instance['show_department_filter']);
        $instance['show_status_filter'] = !empty($new_instance['show_status_filter']);
        $instance['show_pagination'] = !empty($new_instance['show_pagination']);
        $instance['show_filter_actions'] = !empty($new_instance['show_filter_actions']);
        $instance['show_results_count'] = !empty($new_instance['show_results_count']);
        $instance['show_per_page_filter'] = !empty($new_instance['show_per_page_filter']);
        return $instance;
    }
}

/**
 * Register block for Gutenberg editor
 */
function ca_register_sales_archive_gutenberg_block() {
    if (!function_exists('register_block_type')) {
        return;
    }

    wp_register_script(
        'ca-sales-archive-editor',
        plugins_url('js/sales-archive-editor.js', __FILE__),
        ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
        '1.0.0'
    );

    wp_register_script(
        'ca-sales-archive-frontend',
        plugins_url('js/sales-archive.js', __FILE__),
        ['jquery'],
        '1.0.0',
        true
    );

    register_block_type('circuit-auction/sales-archive', [
        'editor_script' => 'ca-sales-archive-editor',
        'render_callback' => 'ca_render_sales_archive_block',
        'attributes' => [
            'title' => ['type' => 'string', 'default' => 'Sales Archive'],
            'range' => ['type' => 'number', 'default' => 20],
            'display_mode' => ['type' => 'string', 'default' => 'full'],
            'show_view_toggle' => ['type' => 'boolean', 'default' => true],
            'status_filter' => ['type' => 'string', 'default' => 'both'],
            'show_search' => ['type' => 'boolean', 'default' => true],
            'show_year_filter' => ['type' => 'boolean', 'default' => true],
            'show_department_filter' => ['type' => 'boolean', 'default' => true],
            'show_status_filter' => ['type' => 'boolean', 'default' => true],
            'show_pagination' => ['type' => 'boolean', 'default' => true],
            'show_results_count' => ['type' => 'boolean', 'default' => true],
        ]
    ]);
}
add_action('init', 'ca_register_sales_archive_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_sales_archive_block($attributes) {
    $config = [
        'status_filter' => $attributes['status_filter'] ?? 'both',
        'display_mode' => $attributes['display_mode'] ?? 'full',
        'show_view_toggle' => $attributes['show_view_toggle'] ?? true,
        'range' => $attributes['range'] ?? 20,
        'show_pagination' => $attributes['show_pagination'] ?? true,
        'filters' => [
            'search' => $attributes['show_search'] ?? true,
            'year' => $attributes['show_year_filter'] ?? true,
            'department' => $attributes['show_department_filter'] ?? true,
            'status' => $attributes['show_status_filter'] ?? true,
        ],
        'show_filter_actions' => true,
        'show_results_count' => $attributes['show_results_count'] ?? true,
    ];
    
    ob_start();
    ca_sales_archive_render($config);
    return ob_get_clean();
}
?>