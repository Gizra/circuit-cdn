<?php

/**
 * Sales Archive functionality for CircuitAuction plugin
 * UPDATED: Fixed pagination to use 'pager' parameter and range configuration
 */

/**
 * Render the sales archive page
 *
 * @param array $args Configuration arguments
 */
function ca_sales_archive_render() {
    ?>
    <div class="ca-sales-archive">
        <div class="ca-sales-archive-header">
            <div id="ca-sales-list"></div>
        </div>
    </div>
    <?php
}

/**
 * AJAX handler for sales archive data
 */
function ca_sales_archive_ajax_handler() {
    check_ajax_referer('ca_sales_archive_nonce', 'nonce');
}


// Register AJAX handlers
add_action('wp_ajax_ca_sales_archive', 'ca_sales_archive_ajax_handler');
add_action('wp_ajax_nopriv_ca_sales_archive', 'ca_sales_archive_ajax_handler');

// Widget class removed - use Gutenberg block instead

/**
 * Register block for Gutenberg editor
 */
function ca_register_sales_archive_gutenberg_block() {
    if (!function_exists('register_block_type')) {
        return;
    }

    wp_register_script(
        'ca-sales-archive-editor',
        plugins_url('js/sales-archive-editor.js', __FILE__),
        ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
        '2.0.1'
    );

    register_block_type('circuit-auction/sales-archive', [
        'editor_script' => 'ca-sales-archive-editor',
        'render_callback' => 'ca_render_sales_archive_block',
        'attributes' => [
            'first_year' => ['type' => 'string', 'default' => ''],
            'display_mode' => ['type' => 'string', 'default' => ''],
            'remove_filters' => ['type' => 'boolean', 'default' => false],
            'search' => ['type' => 'string', 'default' => ''],
            'year' => ['type' => 'string', 'default' => ''],
            'department' => ['type' => 'string', 'default' => ''],
            'status' => ['type' => 'string', 'default' => ''],
            'show_featured_items' => ['type' => 'boolean', 'default' => false],
            'item_display' => ['type' => 'string', 'default' => ''],
        ]
    ]);
}
add_action('init', 'ca_register_sales_archive_gutenberg_block');

/**
 * Render callback for the Gutenberg block
 */
function ca_render_sales_archive_block($attributes) {
    $data_attrs = [];

    // Add data-first-year if set
    if (!empty($attributes['first_year'])) {
        $data_attrs[] = 'data-first-year="' . esc_attr($attributes['first_year']) . '"';
    }

    // Add data-display-mode if set (grid|list|minimal)
    if (!empty($attributes['display_mode'])) {
        $data_attrs[] = 'data-display-mode="' . esc_attr($attributes['display_mode']) . '"';
    }

    // Add data-remove-filters if true
    if (!empty($attributes['remove_filters'])) {
        $data_attrs[] = 'data-remove-filters="true"';
    }

    // Add data-search if set
    if (!empty($attributes['search'])) {
        $data_attrs[] = 'data-search="' . esc_attr($attributes['search']) . '"';
    }

    // Add data-year if set
    if (!empty($attributes['year'])) {
        $data_attrs[] = 'data-year="' . esc_attr($attributes['year']) . '"';
    }

    // Add data-department if set
    if (!empty($attributes['department'])) {
        $data_attrs[] = 'data-department="' . esc_attr($attributes['department']) . '"';
    }

    // Add data-status if set
    if (!empty($attributes['status'])) {
        $data_attrs[] = 'data-status="' . esc_attr($attributes['status']) . '"';
    }

    // Add data-show-featured-items if true
    if (!empty($attributes['show_featured_items'])) {
        $data_attrs[] = 'data-show-featured-items="true"';
    }

    // Add data-item-display if set
    if (!empty($attributes['item_display'])) {
        $data_attrs[] = 'data-item-display="' . esc_attr($attributes['item_display']) . '"';
    }

    $data_attrs_string = implode(' ', $data_attrs);

    return '<div id="ca-sales-list" ' . $data_attrs_string . '></div>';
}
?>