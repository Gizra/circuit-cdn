<?php
/**
 * Template for Circuit Auction React pages (sale, item, prices-realized).
 *
 * Loaded by the template_include filter when the ca_page query var is set.
 * No WordPress page object is required — routing is handled entirely by the
 * ca_register_slug_rewrite_rules() rewrite rules in the plugin.
 */
defined( 'ABSPATH' ) || exit;

get_header();

$ca_page = get_query_var( 'ca_page', '' );
$sale_id = get_query_var( 'sale_id', '' );
$item_id = get_query_var( 'item_id', '' );

switch ( $ca_page ) {

	case 'sale':
		if ( get_option( 'ca_log_api_requests', false ) ) {
			ca_set_custom_message( 'CA Debug: Sales page template' );
		}
		$attrs = sprintf( 'id="%s" data-show-featured="true"', esc_attr( SERVER_WEBSITE_PAGES_SALE ) );
		if ( $sale_id ) {
			$attrs .= sprintf( ' data-sale-nid="%s"', esc_attr( $sale_id ) );
		}
		echo '<div ' . $attrs . ' class="circuit-user-ui"></div>';
		break;

	case 'item':
		if ( $item_id ) {
			printf(
				'<div id="%s" data-item-id="%s" data-display-mode="full" class="circuit-user-ui"></div>',
				esc_attr( SERVER_WEBSITE_PAGES_ITEM ),
				esc_attr( $item_id )
			);
		}
		break;

	case 'prices-realized':
		if ( ! $sale_id ) {
			$sale_id = ca_sale_get_active_sale_nid();
		}
		if ( $sale_id ) {
			printf(
				'<div id="%s" data-sale-nid="%s" class="circuit-user-ui"></div>',
				esc_attr( SERVER_WEBSITE_PAGES_PRICES_REALIZED ),
				esc_attr( $sale_id )
			);
		}
		break;
}

get_footer();
