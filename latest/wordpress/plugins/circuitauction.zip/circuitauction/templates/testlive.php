<?php
/**
 * Standalone "Test Live Auction" app template (latest CDN channel).
 *
 * Rendered by ca_render_live_app() for the /testlive endpoint.
 * Receives $site and $hostname from the including scope.
 */
defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="google" content="notranslate" />
  <meta id="circuit-setup" class="circuit-user-ui" site="<?php echo esc_attr( $site ); ?>" hostname="<?php echo esc_attr( $hostname ); ?>">
  <title>Live Auction</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <script src="https://cdn.circuitauction.com/latest/live/vendor/copy-button.min.js"></script>
  <script src="https://cdn.circuitauction.com/latest/live/vendor/offline.min.js"></script>
  <script src="https://js.pusher.com/8.4/pusher.min.js"></script>
</head>
<body>
<div id="elm-app-container"></div>
<script src="https://cdn.circuitauction.com/latest/live/app-loader.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-6558346-16"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-6558346-16');
</script>
</body>
</html>
