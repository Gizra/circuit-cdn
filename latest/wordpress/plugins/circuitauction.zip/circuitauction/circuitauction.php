<?php
/**
 * @package CircuitAuction
 * @version 1.1
 */
/*
Plugin Name: CircuitAuction
Plugin URI: https://github.com/Gizra/circuit-wordpress
Description: A plugin to integrate CircuitAuction API systems.
Version: 1.3
Author: CircuitAuction
Author URI: https://circuitauction.com
*/


require_once 'vendor/autoload.php';

include_once 'includes/ca-sales.php';
include_once 'includes/ca-items.php';
include_once 'includes/ca-sync.php';

//define( 'SERVER_WEBSITE_PAGES_EMBED_ITEM_PRE_LIVE_SALE', 'item_pre_live_sale' );
define( 'SERVER_WEBSITE_PAGES_ELM_EMBED_WIDGET_MANAGER', 'widget_manager' );
// React page.
define( 'SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT', 'my-account' );
define( 'SERVER_WEBSITE_PAGES_EMBED_LOGIN', 'login' );
define( 'SERVER_WEBSITE_PAGES_MY_BIDS', 'my-bids' );
define( 'SERVER_WEBSITE_PAGES_MY_CREDIT_LEGACY', 'my-credit' );
define( 'SERVER_WEBSITE_PAGES_EMBED_REGISTER', 'register' );
define( 'SERVER_WEBSITE_PAGES_EMBED_FORGOT_PASSWORD', 'forgot-password' );

require 'vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://cdn.circuitauction.com/stable/wordpress/plugins/plugin.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'circuitauction'
);

function ca_create_custom_meta_table() {
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$table_name      = $wpdb->prefix . 'itemmeta';

	$sql = "CREATE TABLE $table_name (
        meta_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        post_id bigint(20) unsigned NOT NULL DEFAULT '0',
        meta_key varchar(255) DEFAULT NULL,
        meta_value longtext,
        PRIMARY KEY  (meta_id),
        UNIQUE KEY post_id_meta_key (post_id, meta_key),
        KEY post_id (post_id),
        KEY meta_key (meta_key)
    ) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}

register_activation_hook( __FILE__, 'ca_create_custom_meta_table' );

/**
 * In this function, the $uuid argument is passed in and used as the value for
 * the meta_value argument in the get_posts() query. The query searches for a
 * post with a uuid meta key equal to the passed-in $uuid value.
 */
function ca_get_post_id_by_uuid( $uuid, $post_type = 'item' ) {
	global $wpdb;
	$table_name = $wpdb->prefix . 'itemmeta';

	$query = $wpdb->prepare(
		"SELECT p.ID
         FROM {$wpdb->posts} p
         INNER JOIN $table_name m ON p.ID = m.post_id
         WHERE p.post_type = %s AND p.post_status = 'publish' AND m.meta_key = 'uuid' AND m.meta_value = %s
         LIMIT 1",
		$post_type,
		$uuid
	);

	$result = $wpdb->get_var( $query );

	if ( $result !== NULL ) {
		return (int) $result;
	}

	return FALSE;
}

/**
 *
 */
function ca_add_settings_page() {
	add_options_page(
		'CircuitAuction Settings',
		'CircuitAuction',
		'manage_options',
		'ca-settings',
		'ca_render_settings_page'
	);
}

add_action( 'admin_menu', 'ca_add_settings_page' );

/**
 * Register settings.
 */
function ca_register_settings() {
	register_setting( 'ca_create_options_group', 'ca_base_theme' );
	register_setting( 'ca_create_options_group', 'ca_currency' );
	register_setting( 'ca_create_options_group', 'ca_pusher_circuit_bid_key' );
	register_setting( 'ca_create_options_group', 'ca_pusher_circuit_bid_cluster' );
	register_setting( 'ca_create_options_group', 'ca_recaptcha_site_key' );
	register_setting( 'ca_create_options_group', 'ca_bo_base_url' );
	register_setting( 'ca_create_options_group', 'ca_circuit_bid_backend_url' );
	register_setting( 'ca_create_options_group', 'ca_live_app_url' );
	register_setting( 'ca_create_options_group', 'ca_site_short_name' );
	register_setting( 'ca_create_options_group', 'ca_log_api_requests' );
	register_setting( 'ca_create_options_group', 'ca_add_user_block_to_header' );
}

add_action( 'admin_init', 'ca_register_settings' );

/**
 * Settings page callback.
 */
function ca_render_settings_page() {
	// Add a settings section
	add_settings_section(
		'ca_create_section',               // Section ID
		'CircuitAuction Main Settings Section',      // Section title
		'ca_create_section_callback',      // Callback function for the section description
		'ca-create-settings'               // Page slug
	);

	// Add settings fields
	add_settings_field( 'ca_base_theme', 'Base theme', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_base_theme',
		'size'        => 150,
		'default'     => '',
		'description' => 'Enter the base theme name',
	] );

	add_settings_field( 'ca_currency', 'Currency Code', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_currency',
		'size'        => 5,
		'description' => 'Enter the currency code (e.g., "USD" or "EUR").',
		'default'     => 'EUR',
	] );

	add_settings_field( 'ca_pusher_circuit_bid_key', 'Pusher Circuit Bid Key', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_pusher_circuit_bid_key',
		'size'        => 40,
		'default'     => '34bb72def989ed6efc60',
		'description' => 'Enter the Pusher Circuit Bid Key.',
	] );

	add_settings_field( 'ca_pusher_circuit_bid_cluster', 'Pusher Circuit Bid Cluster', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_pusher_circuit_bid_cluster',
		'size'        => 5,
		'default'     => 'eu',
		'description' => 'Enter the Pusher Circuit Bid Cluster (e.g., "eu").',
	] );

	add_settings_field( 'ca_recaptcha_site_key', 'reCAPTCHA Site Key', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_recaptcha_site_key',
		'size'        => 100,
		'default'     => '6LdWt6YUAAAAAMdwSJ7vwnvcOtlRWx0nP19iS03Y',
		'description' => 'Enter the reCAPTCHA Site Key.',
	] );

	add_settings_field( 'ca_bo_base_url', 'Backoffice base URL', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_bo_base_url',
		'size'        => 150,
		'default'     => 'https://backoffice.ddev.site',
		'description' => 'Enter the base URL of the backoffice.',
	] );

	add_settings_field( 'ca_circuit_bid_backend_url', 'Bid server base URL', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_circuit_bid_backend_url',
		'size'        => 150,
		'default'     => 'https://circuit-bid.ddev.site:4443',
		'description' => 'Enter the base URL of the bid server.',
	] );

	add_settings_field( 'ca_live_app_url', 'Live APP URL', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_live_app_url',
		'size'        => 150,
		'default'     => 'http://localhost:3000',
		'description' => 'Enter the base URL of bid live app.',
	] );

	add_settings_field( 'ca_site_short_name', 'Short name', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_site_short_name',
		'size'        => 150,
		'default'     => 'hk',
		'description' => 'Enter the short name of installation on bid server.',
	] );

	add_settings_field( 'ca_log_api_requests', 'Log request URL for debugging', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_log_api_requests',
		'size'        => 150,
		'default'     => FALSE,
		'description' => 'Log to PHP log file sale search requests.',
	] );

	add_settings_field( 'ca_add_user_block_to_header', 'Add user block to page header', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_add_user_block_to_header',
		'size'        => 150,
		'default'     => FALSE,
		'description' => 'In case we did not add it to the theme, will push the user block to header.',
	] );


	?>
    <div class="wrap">
        <h1>CircuitAuction Settings</h1>
        <form method="post" action="options.php">
			<?php
			settings_fields( 'ca_create_options_group' );
			do_settings_sections( 'ca-create-settings' );
			submit_button();
			?>
        </form>
    </div>
	<?php
}

/**
 * Render the input field for the settings page.
 *
 * @param $args
 */
function ca_create_option_callback( $args ) {
	// Get the settings option array
	$options = get_option( $args['id'] );

	// Get the value of the specified setting, if available, or use the default value
	$option_value = isset( $options ) ? $options : $args['default'];

	// Render the input field
	echo '<input type="text" name="' . esc_attr( $args['id'] ) . '" value="' . esc_attr( $option_value ) . '" size="' . esc_attr( $args['size'] ) . '" />';
	echo '<p class="description">' . esc_html( $args['description'] ) . '</p>';
}

/**
 * Section callback.
 */
function ca_create_section_callback() {
	echo '<p>CiruitAuction settings. Update the values below and click "Save Changes" to apply your settings.</p>';
}

/**
 * @param $pageId
 *
 * @return string[]|void
 */
function ca_custom_page_info($pageId) {
  switch ($pageId) {
    case SERVER_WEBSITE_PAGES_EMBED_FORGOT_PASSWORD:
      return [
        'title' => 'Forgot Password',
        'path' => 'forgot-password',
        'id' => 'forgotpassword',
      ];
    case SERVER_WEBSITE_PAGES_EMBED_LOGIN:
      return [
        'title' => 'Login',
        'path' => 'login',
        'id' => 'login',
      ];
    case SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT:
      return [
        'title' => 'My Account',
        'path' => 'my-account',
        'id' => 'my-account',
      ];
    case SERVER_WEBSITE_PAGES_MY_BIDS:
      return [
        'title' => 'My Bids',
        'path' => 'my-bids',
        'id' => 'my-bids',
      ];
    case SERVER_WEBSITE_PAGES_MY_CREDIT_LEGACY:
      return [
        'title' => 'My Bids',
        'path' => 'my-credit',
        'id' => 'my-bids',
      ];
    case SERVER_WEBSITE_PAGES_EMBED_REGISTER:
      return [
        'title' => 'Register',
        'path' => 'register',
        'id' => 'register',
      ];

      default:
        return [];
  }
}

/**
 * Custom register page.
 */
function ca_create_custom_pages() {
	$pages = [
		SERVER_WEBSITE_PAGES_EMBED_FORGOT_PASSWORD,
    SERVER_WEBSITE_PAGES_EMBED_LOGIN,
		SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT,
    SERVER_WEBSITE_PAGES_MY_BIDS,
    SERVER_WEBSITE_PAGES_MY_CREDIT_LEGACY,
		SERVER_WEBSITE_PAGES_EMBED_REGISTER,
	];

	foreach ( $pages as $page ) {
    $pageInfo = ca_custom_page_info($page);
    $title = $pageInfo['title'];
		// Check if the page already exists.
		$register_page = get_page_by_path( $pageInfo['path'] );

		// If the page doesn't exist, create it
		if ( ! $register_page ) {
			// Page attributes
			$register_page_args = [
				'post_title'     => $title,
				'post_name'      => $page,
				'post_content'   => '',
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'post_author'    => 1,
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
				'page_template'  => 'pages-elm.php',
				// Set the custom page template
			];

			// Create the page
			$register_page_id = wp_insert_post( $register_page_args );
		}
	}
}

add_action( 'after_setup_theme', 'ca_create_custom_pages' );

/**
 * Exclude our pages from default menu page.
 */
function ca_exclude_page_from_menu( $pages ) {
	$excluded_pages = [
		SERVER_WEBSITE_PAGES_EMBED_FORGOT_PASSWORD,
    SERVER_WEBSITE_PAGES_EMBED_LOGIN,
		SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT,
		SERVER_WEBSITE_PAGES_EMBED_REGISTER,
	];

	foreach ( $excluded_pages as $excluded_page ) {
    $pageInfo = ca_custom_page_info($excluded_page);
		$excluded_page = $pageInfo['path'];
		$page          = get_page_by_path( $excluded_page );
		$pages[]       = $page->ID;
	}

	return $pages;
}

add_filter( 'wp_list_pages_excludes', 'ca_exclude_page_from_menu', 10, 2 );

/**
 * Allow to pass sale uuid to some pages.
 */
function ca_rewrite_rules() {
	add_rewrite_rule(
		'^my-credit/([^/]+)/?$',
		'index.php?pagename=my-credit&sale_uuid=$matches[1]',
		'top'
	);

	add_rewrite_rule(
		'^my-bids/([^/]+)/?$',
		'index.php?pagename=my-bids&sale_uuid=$matches[1]',
		'top'
	);
}

add_action( 'init', 'ca_rewrite_rules', 10, 0 );

/**
 * @param $query_vars
 *
 * @return mixed
 */
function ca_query_vars( $query_vars ) {
	$query_vars[] = 'sale_uuid';

	return $query_vars;
}

add_filter( 'query_vars', 'ca_query_vars' );

/**
 *
 */
function ca_set_permalink_structure() {
	// Set permalink structure to "Post name"
	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure( '/%postname%/' );
}

add_action( 'init', 'ca_set_permalink_structure', 999 );

/**
 * Return the base object to pass to elm apps.
 */
function ca_get_base_elm_object() {
  $elm_data  = [];
  $elm_data[SERVER_WEBSITE_PAGES_ELM_EMBED_WIDGET_MANAGER] = [
		"language"      => 'en',
		"saleUuid"      => ca_sale_get_current_sale_uuid(),
		"baseHostUrl"   => home_url(),
		"backendUrl"    => get_option( 'ca_circuit_bid_backend_url', 'https://circuit-bid.ddev.site:4443' ),
		"circuitBidUrl" => get_option( 'ca_live_app_url', 'http://localhost:3000' ),
		"siteShortName" => get_option( 'ca_site_short_name', 'hk' ),
		"currency"      => get_option( 'ca_currency', 'EUR' ),
    "page"     => SERVER_WEBSITE_PAGES_ELM_EMBED_WIDGET_MANAGER,
    "itemUuid" => str_replace( '_', '-', SERVER_WEBSITE_PAGES_ELM_EMBED_WIDGET_MANAGER ),
    "values"   => [
      "pusher" => [
        "key"     => get_option( 'ca_pusher_circuit_bid_key', '34bb72def989ed6efc60' ),
        "cluster" => get_option( 'ca_pusher_circuit_bid_cluster', 'eu' ),
      ],
    ],
	];

	return $elm_data;
}

/**
 * Load js for elm app.
 */
function ca_enqueue_load() {
	$base_path = '/wp-content/themes/ca-theme';
	wp_enqueue_style( 'ca-css', $base_path . '/sass/css.css' );
	wp_enqueue_script( 'jquery' );
	// Add application only when there's values.
	wp_enqueue_script( 'pusher', 'https://js.pusher.com/3.2/pusher.min.js' );
  // Load JS from CDN.
	wp_enqueue_script( 'server_website_pages_main',  'https://cdn.circuitauction.com/stable/front-end/Main.js');
	wp_enqueue_script( 'server_website_pages_react',  'https://cdn.circuitauction.com/stable/user-ui/app-loader.js');
	wp_enqueue_script( 'server_website_pages_elm', plugins_url( 'circuitauction/js/elm.js'), [], '1.0.0', TRUE );
	// Elm settings.
	wp_localize_script( 'server_website_pages_elm', 'elm_apps_settings', ca_get_base_elm_object() );
	// Enqueue the Google reCAPTCHA script.
	wp_enqueue_script(
		'google-recaptcha',
		'https://www.google.com/recaptcha/api.js?render=explicit',
		[],
		'',
		TRUE
	);
}

add_action( 'wp_enqueue_scripts', 'ca_enqueue_load' );

/**
 * Add widget manager to all pages, this is required by the elm app.
 */
function ca_add_widget_manager_div() {
	// Add widget manager required for elm blocks on all pages.-->
	echo '<div id="' . SERVER_WEBSITE_PAGES_ELM_EMBED_WIDGET_MANAGER . '"></div>';
	if ( get_option( 'ca_add_user_block_to_header', FALSE ) ) {
    // React user menu.
		echo '<div id="user-block"></div>';
	}
}

add_action( 'wp_head', 'ca_add_widget_manager_div' );

class Ca_User_Block_Widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'ca_user_block_widget', // Widget ID
			__( 'Circuit Auction User Block Widget', 'text_domain' ), // Widget name
			[ 'description' => __( 'Display CA user menu', 'text_domain' ), ] // Widget description
		);
	}

	public function widget( $args, $instance ) {
		echo '<div id="user-block"></div>';
	}

}

function ca_register_user_block_widget() {
	register_widget( 'Ca_User_Block_Widget' );
}

add_action( 'widgets_init', 'ca_register_user_block_widget' );

add_action( 'admin_notices', function () {
	$class   = 'notice notice-success'; // CSS class: notice, notice-info, notice-warning, notice-success, notice-error
	$message = __( 'Settings saved successfully.', 'text-domain' );

	printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
} );

function ca_set_custom_message( $message, $type = 'success' ) {
	$_SESSION['custom_message'] = [ 'message' => $message, 'type' => $type ];
}

add_action( 'wp_footer', 'ca_display_custom_message' );
function ca_display_custom_message() {
	if ( isset( $_SESSION['custom_message'] ) ) {
		$message_data = $_SESSION['custom_message'];

		// Inline CSS for the message box
		$css = "
            <style>
                .custom-message {
                    position: fixed;
                    top: 30px;
                    left: 50%;
                    transform: translateX(-50%);
                    z-index: 9999;
                    border: 1px solid #ddd;
                    padding: 10px 20px;
                    border-radius: 5px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    background-color: #f7f7f7;
                    color: #333;
                    width: auto;
                    max-width: 90%;
                    box-sizing: border-box;
                }
                .custom-message.success { border-color: #4CAF50; background-color: #edf7ed; color: #4CAF50; }
                .custom-message.error { border-color: #F44336; background-color: #fdecea; color: #F44336; }
                .custom-message.info { border-color: #2196F3; background-color: #e8f4fd; color: #2196F3; }
                .custom-message.warning { border-color: #ff9800; background-color: #fff4e5; color: #ff9800; }
            </style>
        ";

		// Allowed tags
		$allowed_tags = '<a>';

		// Message HTML
		$message_html = sprintf( '<div class="custom-message %1$s">%2$s</div>', esc_attr( $message_data['type'] ), strip_tags( $message_data['message'], $allowed_tags ) );

		// Echo CSS and message
		echo $css . $message_html;

		unset( $_SESSION['custom_message'] );
	}
}

/**
 * For select list in search, check if the value is selected.
 *
 * @param $value
 *
 * @return bool
 */
function ca_select_is_selected( $value, $selected_value_name, $is_value = TRUE ) {
	if ( $is_value && isset( $_GET['filter'][ $selected_value_name ]['value'] ) && $_GET['filter'][ $selected_value_name ]['value'] == $value ) {
		return 'selected';
	}
	if ( ! $is_value && isset( $_GET[ $selected_value_name ] ) && $_GET[ $selected_value_name ] == $value ) {
		return 'selected';
	}

	return '';

}

