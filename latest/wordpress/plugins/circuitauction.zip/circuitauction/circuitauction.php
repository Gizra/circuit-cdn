<?php
/**
 * @package CircuitAuction
 * @version 2.0.13
 */
/*
Plugin Name: CircuitAuction
Plugin URI: https://github.com/Gizra/circuit-wordpress
Description: A plugin to integrate CircuitAuction API systems.
Version: 2.0.13
Author: CircuitAuction
Author URI: https://circuitauction.com
*/

// Define plugin version constant
define('CA_PLUGIN_VERSION', '2.0.13');

require_once 'vendor/autoload.php';

include_once 'includes/sale-catalog-part.php';
include_once 'includes/sale-sessions.php';
include_once 'includes/ca-sales-archive.php';
include_once 'includes/featured-items.php';
include_once 'includes/ca-prices-realized.php';
include_once 'includes/user-block.php';

/**
 * Register custom block category for Circuit Auction blocks
 */
function ca_register_block_category( $categories ) {
	return array_merge(
		$categories,
		[
			[
				'slug'  => 'circuit',
				'title' => 'Circuit Auction',
				'icon'  => 'hammer',
			],
		]
	);
}
add_filter( 'block_categories_all', 'ca_register_block_category', 10, 1 );

// React page.
define( 'SERVER_WEBSITE_PAGES_USER_BLOCK', 'user-block' );
define( 'SERVER_WEBSITE_PAGES_FORGOT_PASSWORD', 'forgotpassword' );
define( 'SERVER_WEBSITE_PAGES_LOGIN', 'login' );
define( 'SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT', 'my-account' );
define( 'SERVER_WEBSITE_PAGES_TERMS', 'terms' );
define( 'SERVER_WEBSITE_PAGES_CONDITIONS', 'conditions' );
define( 'SERVER_WEBSITE_PAGES_MY_BIDS', 'my-bids' );
define( 'SERVER_WEBSITE_PAGES_REGISTER', 'register' );
define( 'SERVER_WEBSITE_PAGES_FAVORITES', 'my-favorites' );
define( 'SERVER_WEBSITE_PAGES_INTERESTS', 'my-interests' );
define( 'SERVER_WEBSITE_PAGES_SALES_LIST', 'ca-sales-list' );
define( 'SERVER_WEBSITE_PAGES_PRICES_REALIZED', 'ca-prices-realized' );
define( 'SERVER_WEBSITE_PAGES_SALE', 'ca-sale-page' );
define( 'SERVER_WEBSITE_PAGES_BILLING', 'billing-history' );
define( 'SERVER_WEBSITE_PAGES_PAYMENT_METHOD', 'payment-method' );
define( 'SERVER_WEBSITE_PAGES_SUBSCRIPTION_MAGAZINE', 'subscription-magazine' );
define( 'SERVER_WEBSITE_PAGES_SUBSCRIPTION_PURCHASE', 'subscription-purchase' );
define( 'SERVER_WEBSITE_PAGES_BALLANCE', 'balance-btn' );
define( 'SERVER_WEBSITE_PAGES_ITEM', 'ca-item-page' );
define( 'SERVER_WEBSITE_PAGES_FEATURED_ITEMS', 'ca-featured-items' );
define( 'SERVER_WEBSITE_PAGES_PLACE_BID_STANDALONE', 'place-bid-standalone' );


require 'vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://cdn.circuitauction.com/latest/wordpress/plugins/plugin.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'circuitauction'
);


function ca_sale_get_active_sale_nid() {

    // Base url for the API.
    $url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/api/v1.0/sales-public/';

    // Add query parameters
    $query_params = [
        'filter[status][operator]' => 'IN',
        'filter[status][value][0]' => 'published_on_site',
        'range' => 1,
        'sort' => '-id',
        'fields' => 'id',
    ];

    // Use WordPress's built-in HTTP API to fetch the JSON data
    $url = add_query_arg( $query_params, $url );
    $response = wp_remote_get( $url );

    // Check for an error in the response
    if ( is_wp_error( $response ) ) {
        return new WP_Error( 'server-error', __( 'Unable to retrieve active sale ID.', 'text-domain' ) );
    }

    // Parse the JSON response body
    $data = json_decode( wp_remote_retrieve_body( $response ), TRUE );

    // add cache here?

    // Check for JSON decoding error or empty data
    if ( NULL === $data || empty( $data['data'][0] ) ) {
        return new WP_Error( 'json-error', __( 'Invalid or empty JSON response.', 'text-domain' ) );
    }

    return $data['data']['0']['id'];
}

/**
 * Get sale data from BO.
 */
function ca_get_sale_from_server( $sale_nid ) {
	// Base url for the API.
	$url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/get-sale-info/' . $sale_nid;

	// Use WordPress's built-in HTTP API to fetch the JSON data
	$response = wp_remote_get( $url );

	// Check for an error in the response
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'server-error', __( 'Unable to retrieve sale data.', 'text-domain' ) );
	}

	// Parse the JSON response body
	$data = json_decode( wp_remote_retrieve_body( $response ), TRUE );

	// Check for JSON decoding error or empty data
	if ( NULL === $data || empty( $data ) ) {
		return new WP_Error( 'json-error', __( 'Invalid or empty JSON response.', 'text-domain' ) );
	}
    // TODO: cache sale data

	return $data;
}

/**
 * Get item data from BO.
 */
function ca_get_item_from_server( $item_nid ) {
	// Base url for the API.
	$url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/api/items-json/' . $item_nid;

	// Use WordPress's built-in HTTP API to fetch the JSON data
	$response = wp_remote_get( $url );

	// Check for an error in the response
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'server-error', __( 'Unable to retrieve sale data.', 'text-domain' ) );
	}

	// Parse the JSON response body
	$data = json_decode( wp_remote_retrieve_body( $response ), TRUE );

	// Check for JSON decoding error or empty data
	if ( NULL === $data || empty( $data ) ) {
		return new WP_Error( 'json-error', __( 'Invalid or empty JSON response.', 'text-domain' ) );
	}

    // TODO: cache item data
//	ca_items_create_custom_meta_field( $post_id, 'json_data', $data, 'replace' );

	return $data;
}

/**
 *
 */
function ca_add_settings_page() {
	add_options_page(
		'CircuitAuction Settings',
		'CircuitAuction',
		'manage_options',
		'ca-settings',
		'ca_render_settings_page'
	);
}

add_action( 'admin_menu', 'ca_add_settings_page' );

/**
 * Register settings.
 */
function ca_register_settings() {
//	register_setting( 'ca_create_options_group', 'ca_recaptcha_site_key' );
	register_setting( 'ca_create_options_group', 'ca_bo_base_url' );
//	register_setting( 'ca_create_options_group', 'ca_circuit_bid_backend_url' );
//	register_setting( 'ca_create_options_group', 'ca_live_app_url' );
	register_setting( 'ca_create_options_group', 'ca_site_short_name' );
	register_setting( 'ca_create_options_group', 'ca_log_api_requests' );
	register_setting( 'ca_create_options_group', 'ca_add_user_block_to_header' );
	register_setting( 'ca_create_options_group', 'ca_add_circuit_settings_div' );
}

add_action( 'admin_init', 'ca_register_settings' );

/**
 * Settings page callback.
 */
function ca_render_settings_page() {
	// Add a settings section
	add_settings_section(
		'ca_create_section',               // Section ID
		'CircuitAuction Main Settings Section',      // Section title
		'ca_create_section_callback',      // Callback function for the section description
		'ca-create-settings'               // Page slug
	);

	// Add settings fields

//	add_settings_field( 'ca_recaptcha_site_key', 'reCAPTCHA Site Key', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
//		'id'          => 'ca_recaptcha_site_key',
//		'size'        => 100,
//		'default'     => '6LdWt6YUAAAAAMdwSJ7vwnvcOtlRWx0nP19iS03Y',
//		'description' => 'Enter the reCAPTCHA Site Key.',
//	] );

	add_settings_field( 'ca_bo_base_url', 'Hostname', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_bo_base_url',
		'size'        => 150,
		'default'     => 'https://backoffice.ddev.site',
		'description' => 'For circuit ui settings, (domain only), if live just enter the WP domain, or live BO, if test enter backoffice test domain.',
	] );

//	add_settings_field( 'ca_circuit_bid_backend_url', 'Bid server base URL', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
//		'id'          => 'ca_circuit_bid_backend_url',
//		'size'        => 150,
//		'default'     => 'https://circuit-bid.ddev.site:4443',
//		'description' => 'Enter the base URL of the bid server.',
//	] );

//	add_settings_field( 'ca_live_app_url', 'Live APP URL', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
//		'id'          => 'ca_live_app_url',
//		'size'        => 150,
//		'default'     => 'http://localhost:3000',
//		'description' => 'Enter the base URL of bid live app.',
//	] );

	add_settings_field( 'ca_site_short_name', 'Short name', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_site_short_name',
		'size'        => 150,
		'default'     => 'backoffice-hk-eu',
		'description' => 'Enter the short name of installation on bid server.',
	] );

	add_settings_field( 'ca_log_api_requests', 'Log request URL for debugging', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_log_api_requests',
		'size'        => 150,
		'default'     => FALSE,
		'description' => 'Log to PHP log file sale search requests.',
	] );

	add_settings_field( 'ca_add_user_block_to_header', 'Add user block to page header', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_add_user_block_to_header',
		'size'        => 150,
		'default'     => FALSE,
		'description' => 'In case we did not add it to the theme, will push the user block to header.',
	] );

    add_settings_field( 'ca_add_circuit_settings_div', 'Add circuit div settings', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_add_circuit_settings_div',
		'size'        => 150,
		'default'     => TRUE,
		'description' => 'Add div with settings for react app in header.',
	] );


	?>
  <div class="wrap">
    <h1>CircuitAuction Settings</h1>
    <form method="post" action="options.php">
		<?php
		settings_fields( 'ca_create_options_group' );
		do_settings_sections( 'ca-create-settings' );
		submit_button();
		?>
    </form>
  </div>
	<?php
}

/**
 * Render the input field for the settings page.
 *
 * @param $args
 */
function ca_create_option_callback( $args ) {
	// Get the settings option array
	$options = get_option( $args['id'] );

	// Get the value of the specified setting, if available, or use the default value
	$option_value = isset( $options ) ? $options : $args['default'];

	// Render the input field
	echo '<input type="text" name="' . esc_attr( $args['id'] ) . '" value="' . esc_attr( $option_value ) . '" size="' . esc_attr( $args['size'] ) . '" />';
	echo '<p class="description">' . esc_html( $args['description'] ) . '</p>';
}

/**
 * Section callback.
 */
function ca_create_section_callback() {
	echo '<p>CiruitAuction settings. Update the values below and click "Save Changes" to apply your settings.</p>';
}

/**
 * @param $pageId
 *
 * @return string[]|void
 */
function ca_custom_page_info($pageId) {
	switch ( $pageId ) {
		case SERVER_WEBSITE_PAGES_FORGOT_PASSWORD:
			return [
				'title' => 'Forgot Password',
				'path'  => 'forgot-password',
				'id'    => SERVER_WEBSITE_PAGES_FORGOT_PASSWORD,
			];
		case SERVER_WEBSITE_PAGES_LOGIN:
			return [
				'title' => 'Sign in to your account',
				'path'  => 'login',
				'id'    => SERVER_WEBSITE_PAGES_LOGIN,
			];
		case SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT:
			return [
				'title' => 'My Account',
				'path'  => 'my-account',
				'id'    => SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT,
			];
		case SERVER_WEBSITE_PAGES_MY_BIDS:
			return [
				'title' => 'My Bids & Bidding Limits',
				'path'  => 'my-bids',
				'id'    => SERVER_WEBSITE_PAGES_MY_BIDS,
			];
		case SERVER_WEBSITE_PAGES_TERMS:
			return [
				'title' => 'Terms of Service',
				'path'  => 'terms',
			];
		case SERVER_WEBSITE_PAGES_CONDITIONS:
			return [
				'title' => 'Conditions of Sale',
				'path'  => 'conditions',
			];
		case SERVER_WEBSITE_PAGES_REGISTER:
			return [
				'title' => 'Create an Account',
				'path'  => 'register',
				'id'    => SERVER_WEBSITE_PAGES_REGISTER,
			];
		case SERVER_WEBSITE_PAGES_FAVORITES:
			return [
				'title' => 'My Favorites',
				'path'  => 'my-favorites',
				'id'    => SERVER_WEBSITE_PAGES_FAVORITES,
			];
		case SERVER_WEBSITE_PAGES_INTERESTS:
			return [
				'title' => 'My Interests',
				'path'  => 'my-interests',
				'id'    => 'my-interests',
			];
		case SERVER_WEBSITE_PAGES_SALES_LIST:
			return [
				'title' => 'Sales Archive',
				'path'  => 'sales-archive',
				'id'    => SERVER_WEBSITE_PAGES_SALES_LIST,
			];
		case SERVER_WEBSITE_PAGES_PRICES_REALIZED:
			return [
				'title' => 'Prices Realized',
				'path'  => 'prices-realized',
			];
		case SERVER_WEBSITE_PAGES_SALE:
			return [
				'title' => 'Sale',
				'path'  => 'sale',
                // Default search all sales.
                'id'    => SERVER_WEBSITE_PAGES_SALE,
			];
		case SERVER_WEBSITE_PAGES_SUBSCRIPTION_MAGAZINE:
			return [
				'title' => 'Subscription Magazine',
				'path'  => 'subscription-magazine',
				'id'    => SERVER_WEBSITE_PAGES_SUBSCRIPTION_MAGAZINE,
			];
		case SERVER_WEBSITE_PAGES_BILLING:
			return [
				'title' => 'Billing History',
				'path'  => 'billing',
				'id'    => SERVER_WEBSITE_PAGES_BILLING,
			];
		case SERVER_WEBSITE_PAGES_ITEM:
			return [
				'title' => 'Item',
				'path'  => 'item',
			];

		default:
			return [];
	}
}

/**
 * Get all pages that should exist for this plugin version
 */
function ca_get_all_plugin_pages() {
	return [
		SERVER_WEBSITE_PAGES_FORGOT_PASSWORD,
		SERVER_WEBSITE_PAGES_LOGIN,
		SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT,
		SERVER_WEBSITE_PAGES_MY_BIDS,
		SERVER_WEBSITE_PAGES_REGISTER,
		SERVER_WEBSITE_PAGES_FAVORITES,
		SERVER_WEBSITE_PAGES_INTERESTS,
		SERVER_WEBSITE_PAGES_SALES_LIST,
		SERVER_WEBSITE_PAGES_PRICES_REALIZED,
		SERVER_WEBSITE_PAGES_SALE,
		SERVER_WEBSITE_PAGES_SUBSCRIPTION_MAGAZINE,
		SERVER_WEBSITE_PAGES_BILLING,
		SERVER_WEBSITE_PAGES_ITEM,
	];
}

/**
 * Create a single page if it doesn't exist, or update it if needed
 *
 * @param string $page_constant The page constant identifier
 * @param bool $update_if_exists Whether to update the page content if it already exists but is missing the required div
 * @return bool|string Returns true if page was created, 'updated' if page was updated, false if no action taken
 */
function ca_create_single_page($page_constant, $update_if_exists = false) {
	$pageInfo = ca_custom_page_info($page_constant);

	// Skip if page info is empty
	if (empty($pageInfo)) {
		return false;
	}

	// Check if page already exists using multiple methods
	$existing_page = get_page_by_path($pageInfo['path']);

	if (!$existing_page) {
		// Double check with get_posts
		$existing_posts = get_posts([
			'name' => $pageInfo['path'],
			'post_type' => 'page',
			'post_status' => ['publish', 'pending', 'draft', 'private'],
			'posts_per_page' => 1
		]);
		$existing_page = !empty($existing_posts) ? $existing_posts[0] : null;
	}

	// If page doesn't exist, create it
	if (!$existing_page) {
		$template = isset($pageInfo['template']) ? $pageInfo['template'] : 'pages-elm.php';
		$page_args = [
			'post_title' => $pageInfo['title'],
			'post_name' => $pageInfo['path'],
			'post_content' => !empty($pageInfo['id']) ? '<div id="' . esc_attr($pageInfo['id']) . '" class="circuit-user-ui"></div>' : '',
			'post_status' => 'publish',
			'post_type' => 'page',
			'post_author' => 1,
			'comment_status' => 'closed',
			'ping_status' => 'closed',
			'page_template' => $template,
		];

		$page_id = wp_insert_post($page_args);

		if (is_wp_error($page_id)) {
			error_log('Failed to create page: ' . $pageInfo['title']);
			return false;
		}

		error_log('Created page: ' . $pageInfo['title'] . ' with ID: ' . $page_id);
		return true;
	}

	// If page exists and we should update it
	if ($existing_page && $update_if_exists && !empty($pageInfo['id'])) {
		$expected_div = '<div id="' . esc_attr($pageInfo['id']) . '" class="circuit-user-ui"></div>';
		$current_content = $existing_page->post_content;

		// Only update if the div with this id is not already present
		if (strpos($current_content, 'id="' . esc_attr($pageInfo['id']) . '"') === false) {
			// If content is empty, just add the div
			// If content exists, prepend the div to existing content
			$new_content = empty(trim($current_content)) ? $expected_div : $expected_div . "\n\n" . $current_content;

			wp_update_post([
				'ID' => $existing_page->ID,
				'post_content' => $new_content
			]);

			error_log('Updated page: ' . $pageInfo['title'] . ' (ID: ' . $existing_page->ID . ') with div id: ' . $pageInfo['id']);
			return 'updated';
		}
	}

	return false; // Page already exists and doesn't need updating
}

/**
 * Create all plugin pages and optionally update existing ones
 *
 * @param bool $update_if_exists Whether to update existing pages that are missing the required div
 * @return array Array with 'created' and 'updated' counts
 */
function ca_create_custom_pages($update_if_exists = false) {
	$pages = ca_get_all_plugin_pages();
	$created_count = 0;
	$updated_count = 0;

	foreach ($pages as $page) {
		$result = ca_create_single_page($page, $update_if_exists);
		if ($result === true) {
			$created_count++;
		} elseif ($result === 'updated') {
			$updated_count++;
		}
	}

	return ['created' => $created_count, 'updated' => $updated_count];
}

/**
 * Update existing pages to add the div with proper ID if missing
 * This function now uses ca_create_custom_pages() with update flag
 *
 * @return int Number of pages updated
 */
function ca_update_existing_pages_content() {
	$result = ca_create_custom_pages(true);
	return $result['updated'];
}

/**
 * Check plugin version and run updates if needed
 */
function ca_check_plugin_version() {
	$current_version = get_option('ca_plugin_version', '0');

	// If no version stored or version is different, run updates
//	$current_version = '1.7';
	if (version_compare($current_version, CA_PLUGIN_VERSION, '<')) {
		ca_run_plugin_updates($current_version);
		update_option('ca_plugin_version', CA_PLUGIN_VERSION);
	}
}

/**
 * Run plugin updates on version change
 * Automatically ensures all pages exist and are properly configured on every version update
 *
 * @param string $from_version The previous version being upgraded from
 */
function ca_run_plugin_updates($from_version = '0') {
	// Force update all pages if upgrading from version below 2.0.9
	$force_update = version_compare($from_version, '2.0.9', '<');

	// On any version change, ensure all pages exist and are properly updated
	// This creates missing pages and updates existing ones with required divs
	$result = ca_create_custom_pages($force_update);

	if ($result['created'] > 0 || $result['updated'] > 0) {
		error_log(sprintf(
			'CircuitAuction plugin update: %d page(s) created, %d page(s) updated (from version %s, force_update: %s)',
			$result['created'],
			$result['updated'],
			$from_version,
			$force_update ? 'true' : 'false'
		));
	}
}

// Run version check on plugin load
add_action('init', 'ca_check_plugin_version', 20);

/**
 * Flush rewrite rules if needed (one-time after code update)
 */
function ca_maybe_flush_rewrite_rules() {
	if (!get_option('ca_rewrite_rules_flushed_v2')) {
		flush_rewrite_rules();
		update_option('ca_rewrite_rules_flushed_v2', true);
		error_log('CircuitAuction: Rewrite rules flushed');
	}
}
add_action('init', 'ca_maybe_flush_rewrite_rules', 999);

// Also run on activation for new installations
register_activation_hook(__FILE__, function() {
	flush_rewrite_rules();
});

// Clean up version option on deactivation
function ca_cleanup_plugin_options() {
	delete_option('ca_plugin_version');
	// Remove the old option if it exists
	delete_option('ca_custom_pages_created');
}
register_deactivation_hook(__FILE__, 'ca_cleanup_plugin_options');

/**
 * Allow to pass sale uuid to some pages.
 */
function ca_rewrite_rules() {
	// Add Rules for Items with optional language prefix
	// With language: example.com/en/item/123
	add_rewrite_rule(
		'^([a-z]{2})/item/([^/]*)/?',
		'index.php?pagename=item&item_id=$matches[2]',
		'top'
	);

	// Without language: example.com/item/123
	add_rewrite_rule(
		'^item/([^/]*)/?',
		'index.php?pagename=item&item_id=$matches[1]',
		'top'
	);

	// 3. Add Rules for Sales with optional language prefix
	// With language: example.com/en/sale/123
	add_rewrite_rule(
		'^([a-z]{2})/sale/([^/]*)/?',
		'index.php?pagename=sale&sale_id=$matches[2]',
		'top'
	);

	// Without language: example.com/sale/123
	add_rewrite_rule(
		'^sale/([^/]*)/?',
		'index.php?pagename=sale&sale_id=$matches[1]',
		'top'
	);

	// 3. Add Rules for Sales with optional language prefix
	// With language: example.com/en/sale/123
	add_rewrite_rule(
		'^([a-z]{2})/prices-realized/([^/]*)/?',
		'index.php?pagename=prices-realized&sale_id=$matches[2]',
		'top'
	);

	// Without language: example.com/sale/123
	add_rewrite_rule(
		'^prices-realized/([^/]*)/?',
		'index.php?pagename=prices-realized&sale_id=$matches[1]',
		'top'
	);
	if ( get_option( 'ca_log_api_requests', FALSE ) ) {
		ca_set_custom_message( 'CA Debug: Added rewrite rules' );
	}
}

add_action( 'init', 'ca_rewrite_rules', 10, 0 );


/**
 * Register custom query variables
 */
function ca_register_query_vars( $vars ) {
	$vars[] = 'item_id';
	$vars[] = 'sale_id';
	return $vars;
}
add_filter( 'query_vars', 'ca_register_query_vars' );

/**
 * Inject item page React div into page content
 */
function ca_inject_item_page_content($content) {
	// Only inject on the item page
	if (!is_page('item')) {
		return $content;
	}

	// Get the item_id from the query variable
	$item_id = get_query_var('item_id', '');

	// If no item_id, return original content
	if (empty($item_id)) {
		return $content;
	}

	// Build the React div
	$item_div = sprintf(
		'<div id="%s" data-item-id="%s" data-display-mode="full" class="circuit-user-ui"></div>',
		esc_attr(SERVER_WEBSITE_PAGES_ITEM),
		esc_attr($item_id)
	);

	// Return the div (replace page content with the div)
	return $item_div;
}
add_filter('the_content', 'ca_inject_item_page_content');

/**
 * Inject sale page React div into page content
 */
function ca_inject_sale_page_content($content) {
	// Only inject on the sale page
	if (!is_page('sale')) {
		return $content;
	}
	if ( get_option( 'ca_log_api_requests', FALSE ) ) {
		ca_set_custom_message( 'CA Debug: Sales callback' );
	}

	// Get the sale_id from the query variable
	$sale_id = get_query_var('sale_id', '');

	if (empty($sale_id)) {
		if ( get_option( 'ca_log_api_requests', FALSE ) ) {
			ca_set_custom_message( 'CA Debug: Sales callback - no sale id' );
		}
		return sprintf( '<div id="%s" data-show-featured="true" class="circuit-user-ui"></div>', esc_attr( SERVER_WEBSITE_PAGES_SALE ) );
	}

	// Build the React div
	$sale_div = sprintf(
		'<div id="%s" data-sale-nid="%s" data-show-featured="true" class="circuit-user-ui"></div>',
		esc_attr(SERVER_WEBSITE_PAGES_SALE),
		esc_attr($sale_id)
	);

	// Return the div (replace page content with the div)
	return $sale_div;
}
add_filter('the_content', 'ca_inject_sale_page_content');

/**
 * Inject prices-realized page React div into page content
 */
function ca_inject_prices_realized_page_content($content) {
	// Only inject on the sale page
	if (!is_page('prices-realized')) {
		return $content;
	}

	// Get the sale_id from the query variable
	$sale_id = get_query_var('sale_id', '');

	// If no sale_id, return original content
	if (empty($sale_id)) {
		$sale_id = ca_sale_get_active_sale_nid();
		if (empty($sale_id)) {
			return $content;
		}
	}

	// Build the React div
	$sale_div = sprintf(
		'<div id="%s" data-sale-nid="%s" class="circuit-user-ui"></div>',
		esc_attr(SERVER_WEBSITE_PAGES_PRICES_REALIZED),
		esc_attr($sale_id)
	);

	// Return the div (replace page content with the div)
	return $sale_div;
}
add_filter('the_content', 'ca_inject_prices_realized_page_content');

/**
 * Load js for elm app.
 */
function ca_enqueue_load() {
	// Load in footer to ensure DOM is ready before the React app initializes.
	wp_enqueue_script( 'server_website_pages_react', 'https://cdn.circuitauction.com/latest/user-ui/app-loader.js', array( 'jquery' ), false, true );
}

add_action( 'wp_enqueue_scripts', 'ca_enqueue_load' );

/**
 * Add widget manager to all pages, this is required by the elm app.
 */
function ca_add_circuit_div() {
	// Add widget manager required for elm blocks on all pages.-->
	if ( get_option( 'ca_add_user_block_to_header', FALSE ) ) {
		// React user menu. SERVER_WEBSITE_PAGES_USER_BLOCK
		echo '<div id="user-block" class="circuit-user-ui"></div>';
	}
	if ( get_option( 'ca_add_circuit_settings_div', TRUE ) ) {
		// React div settings.
		$hostname = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' );
        $site = get_option( 'ca_site_short_name', 'backoffice-hk-eu' );
		$current_lang = 'en';
		if ( function_exists('pll_the_languages') ) {
            $current_lang = pll_current_language();
		}
		echo '<div id="circuit-setup" site="' . $site . '" hostname="' . $hostname . '" language="' . $current_lang . '"></div>';
	}
}

add_action( 'wp_head', 'ca_add_circuit_div' );

// Widget class removed - use Gutenberg block instead (includes/user-block.php)

add_action( 'admin_notices', function () {
	$class   = 'notice notice-success'; // CSS class: notice, notice-info, notice-warning, notice-success, notice-error
	$message = __( 'Settings saved successfully.', 'text-domain' );

	printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
} );

function ca_set_custom_message( $message, $type = 'success' ) {
	$_SESSION['custom_message'] = [ 'message' => $message, 'type' => $type ];
}

add_action( 'wp_footer', 'ca_display_custom_message' );
function ca_display_custom_message() {
	if ( isset( $_SESSION['custom_message'] ) ) {
		$message_data = $_SESSION['custom_message'];

		// Inline CSS for the message box
		$css = "
            <style>
                .custom-message {
                    position: fixed;
                    top: 30px;
                    left: 50%;
                    transform: translateX(-50%);
                    z-index: 9999;
                    border: 1px solid #ddd;
                    padding: 10px 20px;
                    border-radius: 5px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    background-color: #f7f7f7;
                    color: #333;
                    width: auto;
                    max-width: 90%;
                    box-sizing: border-box;
                }
                .custom-message.success { border-color: #4CAF50; background-color: #edf7ed; color: #4CAF50; }
                .custom-message.error { border-color: #F44336; background-color: #fdecea; color: #F44336; }
                .custom-message.info { border-color: #2196F3; background-color: #e8f4fd; color: #2196F3; }
                .custom-message.warning { border-color: #ff9800; background-color: #fff4e5; color: #ff9800; }
            </style>
        ";

		// Allowed tags
		$allowed_tags = '<a>';

		// Message HTML
		$message_html = sprintf( '<div class="custom-message %1$s">%2$s</div>', esc_attr( $message_data['type'] ), strip_tags( $message_data['message'], $allowed_tags ) );

		// Echo CSS and message
		echo $css . $message_html;

		unset( $_SESSION['custom_message'] );
	}
}

/**
 * Debug helper function that uses WordPress native tools
 *
 * @param mixed $data The data to debug
 * @param string $title Optional title for the debug section
 * @param bool $print Whether to print to screen (true) or log to debug.log (false)
 */
function ca_debug($data, $title = '', $print = true) {
  if (!defined('WP_DEBUG') || !WP_DEBUG) {
    return;
  }

  $output = '';

  // Add backtrace information
  $trace = wp_debug_backtrace_summary();

  // Format the debug output
  if ($title) {
    $output .= "=== {$title} ===\n";
  }

  $output .= "Called from: {$trace}\n";
  $output .= "Time: " . current_time('mysql') . "\n";
  $output .= "Data:\n";
  $output .= print_r($data, true);
  $output .= "\n=================\n";

  if ($print) {
    echo '<pre style="background: #f5f5f5; padding: 15px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; overflow: auto;">';
    echo esc_html($output);
    echo '</pre>';
  } else {
    error_log($output);
  }
}
