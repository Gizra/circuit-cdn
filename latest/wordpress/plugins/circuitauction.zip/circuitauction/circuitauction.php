<?php
/**
 * @package CircuitAuction
 * @version 2.0.36
 */
/*
Plugin Name: CircuitAuction
Plugin URI: https://github.com/Gizra/circuit-wordpress
Description: A plugin to integrate CircuitAuction API systems.
Version: 2.0.36
Author: CircuitAuction
Author URI: https://circuitauction.com
*/

// Define plugin version constant
define('CA_PLUGIN_VERSION', '2.0.36');

require_once 'vendor/autoload.php';

include_once 'includes/sale-catalog-part.php';
include_once 'includes/sale-sessions.php';
include_once 'includes/ca-sales-archive.php';
include_once 'includes/featured-items.php';
include_once 'includes/ca-prices-realized.php';
include_once 'includes/user-block.php';

/**
 * Register custom block category for Circuit Auction blocks
 */
function ca_register_block_category( $categories ) {
	return array_merge(
		$categories,
		[
			[
				'slug'  => 'circuit',
				'title' => 'Circuit Auction',
				'icon'  => 'hammer',
			],
		]
	);
}
add_filter( 'block_categories_all', 'ca_register_block_category', 10, 1 );

// React page.
define( 'SERVER_WEBSITE_PAGES_USER_BLOCK', 'user-block' );
define( 'SERVER_WEBSITE_PAGES_FORGOT_PASSWORD', 'forgotpassword' );
define( 'SERVER_WEBSITE_PAGES_LOGIN', 'login' );
define( 'SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT', 'my-account' );
define( 'SERVER_WEBSITE_PAGES_TERMS', 'terms' );
define( 'SERVER_WEBSITE_PAGES_CONDITIONS', 'conditions' );
define( 'SERVER_WEBSITE_PAGES_MY_BIDS', 'my-bids' );
define( 'SERVER_WEBSITE_PAGES_REGISTER', 'register' );
define( 'SERVER_WEBSITE_PAGES_FAVORITES', 'my-favorites' );
define( 'SERVER_WEBSITE_PAGES_INTERESTS', 'my-interests' );
define( 'SERVER_WEBSITE_PAGES_SALES_LIST', 'ca-sales-list' );
define( 'SERVER_WEBSITE_PAGES_PRICES_REALIZED', 'ca-prices-realized' );
define( 'SERVER_WEBSITE_PAGES_SALE', 'ca-sale-page' );
define( 'SERVER_WEBSITE_PAGES_BILLING', 'billing-history' );
define( 'SERVER_WEBSITE_PAGES_PAYMENT_METHOD', 'payment-method' );
define( 'SERVER_WEBSITE_PAGES_SUBSCRIPTION_MAGAZINE', 'subscription-magazine' );
define( 'SERVER_WEBSITE_PAGES_SUBSCRIPTION_PURCHASE', 'subscription-purchase' );
define( 'SERVER_WEBSITE_PAGES_BALLANCE', 'balance-btn' );
define( 'SERVER_WEBSITE_PAGES_ITEM', 'ca-item-page' );
define( 'SERVER_WEBSITE_PAGES_FEATURED_ITEMS', 'ca-featured-items' );
define( 'SERVER_WEBSITE_PAGES_PLACE_BID_STANDALONE', 'place-bid-standalone' );


require 'vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://cdn.circuitauction.com/latest/wordpress/plugins/plugin.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'circuitauction'
);


function ca_sale_get_active_sale_nid() {

    // Base url for the API.
    $url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/api/v1.0/sales-public/';

    // Add query parameters
    $query_params = [
        'filter[status][operator]' => 'IN',
        'filter[status][value][0]' => 'published_on_site',
        'range' => 1,
        'sort' => '-id',
        'fields' => 'id',
    ];

    // Use WordPress's built-in HTTP API to fetch the JSON data
    $url = add_query_arg( $query_params, $url );
    $response = wp_remote_get( $url );

    // Check for an error in the response
    if ( is_wp_error( $response ) ) {
        return new WP_Error( 'server-error', __( 'Unable to retrieve active sale ID.', 'text-domain' ) );
    }

    // Parse the JSON response body
    $data = json_decode( wp_remote_retrieve_body( $response ), TRUE );

    // add cache here?

    // Check for JSON decoding error or empty data
    if ( NULL === $data || empty( $data['data'][0] ) ) {
        return new WP_Error( 'json-error', __( 'Invalid or empty JSON response.', 'text-domain' ) );
    }

    return $data['data']['0']['id'];
}

/**
 * Get sale data from BO.
 */
function ca_get_sale_from_server( $sale_nid ) {
	// Base url for the API.
	$url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/get-sale-info/' . $sale_nid;

	// Use WordPress's built-in HTTP API to fetch the JSON data
	$response = wp_remote_get( $url );

	// Check for an error in the response
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'server-error', __( 'Unable to retrieve sale data.', 'text-domain' ) );
	}

	// Parse the JSON response body
	$data = json_decode( wp_remote_retrieve_body( $response ), TRUE );

	// Check for JSON decoding error or empty data
	if ( NULL === $data || empty( $data ) ) {
		return new WP_Error( 'json-error', __( 'Invalid or empty JSON response.', 'text-domain' ) );
	}
    // TODO: cache sale data

	return $data;
}

/**
 * Get item data from BO.
 */
function ca_get_item_from_server( $item_nid ) {
	// Base url for the API.
	$url = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' ) . '/api/items-json/' . $item_nid;

	// Use WordPress's built-in HTTP API to fetch the JSON data
	$response = wp_remote_get( $url );

	// Check for an error in the response
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'server-error', __( 'Unable to retrieve sale data.', 'text-domain' ) );
	}

	// Parse the JSON response body
	$data = json_decode( wp_remote_retrieve_body( $response ), TRUE );

	// Check for JSON decoding error or empty data
	if ( NULL === $data || empty( $data ) ) {
		return new WP_Error( 'json-error', __( 'Invalid or empty JSON response.', 'text-domain' ) );
	}

    // TODO: cache item data
//	ca_items_create_custom_meta_field( $post_id, 'json_data', $data, 'replace' );

	return $data;
}

/**
 * ---------------------------------------------------------------------------
 * Dynamic SEO head for sale/item detail pages.
 *
 * /sale/{id} and /item/{id} all render the same React template, so without
 * this every sale/item shares one <title>/og/twitter set. These helpers fetch
 * the sale/item name + description from the BO public API, cache them in a
 * transient (API hit at most once per id/lang/TTL), and override AIOSEO's
 * title/description/OG/Twitter output for the current request only.
 * ---------------------------------------------------------------------------
 */

/**
 * Pull a language-specific scalar out of a BO field that may be
 * ['en' => 'x'], ['en' => ['value' => '<p>x</p>']], or a plain string.
 */
function ca_meta_lang_value( $field, $lang ) {
	if ( is_string( $field ) ) {
		return $field;
	}
	if ( ! is_array( $field ) || empty( $field ) ) {
		return '';
	}
	$val = $field[ $lang ] ?? $field['en'] ?? reset( $field );
	if ( is_array( $val ) ) {
		$val = $val['value'] ?? reset( $val );
	}
	return is_string( $val ) ? $val : '';
}

/**
 * Strip HTML, decode entities (so &nbsp;/&amp; don't leak into meta tags), and
 * collapse whitespace — including non-breaking spaces — to single spaces.
 */
function ca_meta_clean_text( $text ) {
	$text = wp_strip_all_tags( (string) $text );
	$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
	$text = str_replace( "\xC2\xA0", ' ', $text ); // UTF-8 non-breaking space.
	return trim( preg_replace( '/\s+/u', ' ', $text ) );
}

/**
 * Pick the record matching $id from a {"data":[...]} payload (fallback: first).
 */
function ca_meta_pick_record( $data, $id ) {
	if ( empty( $data['data'] ) || ! is_array( $data['data'] ) ) {
		return null;
	}
	foreach ( $data['data'] as $record ) {
		if ( isset( $record['id'] ) && (int) $record['id'] === (int) $id ) {
			return $record;
		}
	}
	return is_array( $data['data'][0] ) ? $data['data'][0] : null;
}

/**
 * Build [ 'title' => ..., 'description' => ... ] from a BO record, or null
 * when no usable title is present.
 */
function ca_meta_from_record( $record, $lang ) {
	if ( ! is_array( $record ) ) {
		return null;
	}

	$title = '';
	foreach ( [ 'label', 'title', 'name' ] as $key ) {
		if ( ! empty( $record[ $key ] ) ) {
			$title = ca_meta_clean_text( ca_meta_lang_value( $record[ $key ], $lang ) );
			if ( '' !== $title ) {
				break;
			}
		}
	}
	if ( '' === $title ) {
		return null;
	}

	$description = '';
	foreach ( [ 'description', 'body', 'subtitle', 'summary' ] as $key ) {
		if ( ! empty( $record[ $key ] ) ) {
			$description = ca_meta_clean_text( ca_meta_lang_value( $record[ $key ], $lang ) );
			if ( '' !== $description ) {
				break;
			}
		}
	}
	if ( function_exists( 'mb_strlen' ) && mb_strlen( $description ) > 160 ) {
		$description = rtrim( mb_substr( $description, 0, 157 ) ) . '…';
	}

	return [
		'title'       => $title,
		'description' => $description,
	];
}

/**
 * Fetch + cache the SEO meta for a sale or item.
 *
 * @param string $type 'sale' or 'item'.
 * @param int    $id   The BO node id.
 * @param string $lang Language code.
 * @return array|null  [ 'title' => ..., 'description' => ... ] or null.
 */
function ca_get_remote_meta( $type, $id, $lang ) {
	$id = (int) $id;
	if ( ! $id ) {
		return null;
	}

	$transient_key = 'ca_meta_' . $type . '_' . $id . '_' . $lang;
	$cached        = get_transient( $transient_key );
	if ( false !== $cached ) {
		// '' is a short-lived negative cache (lookup failed) — don't override.
		return is_array( $cached ) ? $cached : null;
	}

	$base = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' );
	// The option is sometimes stored without a scheme (e.g. "backoffice.ddev.site")
	// because other consumers (like the `hostname` meta attr) want a bare host.
	// wp_remote_get() requires a scheme, so add one if missing.
	if ( ! preg_match( '#^https?://#i', $base ) ) {
		$base = 'https://' . ltrim( $base, '/' );
	}
	$base = trailingslashit( $base );
	$path = ( 'sale' === $type ) ? 'api/v1.0/sales-public/' . $id : 'api/items-json/' . $id;

	$response = wp_remote_get( $base . $path, [ 'timeout' => 5 ] );
	$meta     = null;

	if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( is_array( $data ) ) {
			// sales-public wraps records in `data[]`; items-json may return the record directly.
			$record = isset( $data['data'] ) ? ca_meta_pick_record( $data, $id ) : $data;
			$meta   = ca_meta_from_record( $record, $lang );
		}
	}

	set_transient(
		$transient_key,
		$meta ? $meta : '',
		$meta ? 12 * HOUR_IN_SECONDS : 5 * MINUTE_IN_SECONDS
	);

	return $meta;
}

/**
 * Resolve the SEO meta for the current request when it is a sale/item detail
 * page (ca_page = 'sale'|'item'). Memoized so the lookup (and any API call)
 * happens once per request.
 *
 * @return array|null [ 'title' => ..., 'description' => ... ] or null.
 */
function ca_current_page_meta() {
	static $resolved = false;
	static $meta     = null;

	if ( $resolved ) {
		return $meta;
	}
	$resolved = true;

	$lang = 'en';
	if ( function_exists( 'pll_current_language' ) ) {
		$current = pll_current_language();
		if ( $current ) {
			$lang = $current;
		}
	}

	$ca_page = get_query_var( 'ca_page', '' );
	if ( 'sale' === $ca_page ) {
		$sale_id = get_query_var( 'sale_id', '' );
		if ( ! empty( $sale_id ) ) {
			$meta = ca_get_remote_meta( 'sale', $sale_id, $lang );
		}
	} elseif ( 'item' === $ca_page ) {
		$item_id = get_query_var( 'item_id', '' );
		if ( ! empty( $item_id ) ) {
			$meta = ca_get_remote_meta( 'item', $item_id, $lang );
		}
	}

	return $meta;
}

/**
 * Full document/SEO title for the current sale/item, matching AIOSEO's
 * "{title} - {site name}" format. Returns the original when not applicable.
 */
function ca_filter_seo_title( $title ) {
	$meta = ca_current_page_meta();
	if ( empty( $meta['title'] ) ) {
		return $title;
	}
	return $meta['title'] . ' - ' . get_bloginfo( 'name' );
}

/**
 * Meta description for the current sale/item. Returns the original when not
 * applicable or when the sale/item has no description.
 */
function ca_filter_seo_description( $description ) {
	$meta = ca_current_page_meta();
	if ( empty( $meta['description'] ) ) {
		return $description;
	}
	return $meta['description'];
}

/**
 * Override og:/twitter: title + description tags for sale/item pages.
 *
 * @param array  $tags   The AIOSEO social tag array.
 * @param string $prefix 'og' or 'twitter'.
 */
function ca_filter_social_tags( $tags, $prefix ) {
	$meta = ca_current_page_meta();
	if ( empty( $meta['title'] ) || ! is_array( $tags ) ) {
		return $tags;
	}

	$encode = function ( $value ) {
		if ( function_exists( 'aioseo' ) && isset( aioseo()->helpers ) && method_exists( aioseo()->helpers, 'encodeOutputHtml' ) ) {
			return aioseo()->helpers->encodeOutputHtml( $value );
		}
		return esc_attr( $value );
	};

	$tags[ $prefix . ':title' ] = $encode( $meta['title'] . ' - ' . get_bloginfo( 'name' ) );
	if ( ! empty( $meta['description'] ) ) {
		$tags[ $prefix . ':description' ] = $encode( $meta['description'] );
	}

	return $tags;
}

function ca_filter_facebook_tags( $tags ) {
	return ca_filter_social_tags( $tags, 'og' );
}

function ca_filter_twitter_tags( $tags ) {
	return ca_filter_social_tags( $tags, 'twitter' );
}

// <title> + meta description (AIOSEO), with a WordPress-core title fallback.
add_filter( 'aioseo_title', 'ca_filter_seo_title', 20 );
add_filter( 'aioseo_description', 'ca_filter_seo_description', 20 );
add_filter( 'pre_get_document_title', 'ca_filter_seo_title', 20 );
// Open Graph + Twitter card title/description.
add_filter( 'aioseo_facebook_tags', 'ca_filter_facebook_tags', 20 );
add_filter( 'aioseo_twitter_tags', 'ca_filter_twitter_tags', 20 );

/**
 *
 */
function ca_add_settings_page() {
	add_options_page(
		'CircuitAuction Settings',
		'CircuitAuction',
		'manage_options',
		'ca-settings',
		'ca_render_settings_page'
	);
}

add_action( 'admin_menu', 'ca_add_settings_page' );

/**
 * Register settings.
 */
function ca_register_settings() {
//	register_setting( 'ca_create_options_group', 'ca_recaptcha_site_key' );
	register_setting( 'ca_create_options_group', 'ca_bo_base_url' );
	register_setting( 'ca_create_options_group', 'ca_circuit_debug' );
	register_setting( 'ca_create_options_group', 'ca_local_serverless' );
	register_setting( 'ca_create_options_group', 'ca_site_short_name' );
	register_setting( 'ca_create_options_group', 'ca_log_api_requests' );
	register_setting( 'ca_create_options_group', 'ca_add_user_block_to_header' );
	register_setting( 'ca_create_options_group', 'ca_add_circuit_settings_div' );
	register_setting( 'ca_create_options_group', 'ca_use_latest_cdn' );
	register_setting( 'ca_create_options_group', 'ca_extra_frame_ancestors' );
}

add_action( 'admin_init', 'ca_register_settings' );

/**
 * Settings page callback.
 */
function ca_render_settings_page() {
	// Add a settings section
	add_settings_section(
		'ca_create_section',               // Section ID
		'CircuitAuction Main Settings Section',      // Section title
		'ca_create_section_callback',      // Callback function for the section description
		'ca-create-settings'               // Page slug
	);

	// Add settings fields

//	add_settings_field( 'ca_recaptcha_site_key', 'reCAPTCHA Site Key', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
//		'id'          => 'ca_recaptcha_site_key',
//		'size'        => 100,
//		'default'     => '6LdWt6YUAAAAAMdwSJ7vwnvcOtlRWx0nP19iS03Y',
//		'description' => 'Enter the reCAPTCHA Site Key.',
//	] );

	add_settings_field( 'ca_bo_base_url', 'Hostname', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_bo_base_url',
		'size'        => 150,
		'default'     => 'https://backoffice.ddev.site',
		'description' => 'For circuit ui settings, (domain only), if live just enter the WP domain, or live BO, if test enter backoffice test domain.',
	] );

	add_settings_field( 'ca_circuit_debug', 'Debug mode enabled', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_circuit_debug',
        'size'        => 150,
        'default'     => FALSE,
        'description' => 'Display debug info and functions.',
	] );

	add_settings_field( 'ca_local_serverless', 'Use dev local serverless', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_local_serverless',
		'size'        => 150,
		'default'     => FALSE,
		'description' => 'Enter the base URL of bid live app.',
	] );

	add_settings_field( 'ca_site_short_name', 'Short name', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_site_short_name',
		'size'        => 150,
		'default'     => 'backoffice-hk-eu',
		'description' => 'Enter the short name of installation on bid server.',
	] );

	add_settings_field( 'ca_log_api_requests', 'Log request URL for debugging', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_log_api_requests',
		'size'        => 150,
		'default'     => FALSE,
		'description' => 'Log to PHP log file sale search requests.',
	] );

	add_settings_field( 'ca_add_user_block_to_header', 'Add user block to page header', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_add_user_block_to_header',
		'size'        => 150,
		'default'     => FALSE,
		'description' => 'In case we did not add it to the theme, will push the user block to header.',
	] );

    add_settings_field( 'ca_add_circuit_settings_div', 'Add circuit div settings', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_add_circuit_settings_div',
		'size'        => 150,
		'default'     => TRUE,
		'description' => 'Add div with settings for react app in header.',
	] );

	add_settings_field( 'ca_use_latest_cdn', 'Use latest CDN build', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_use_latest_cdn',
		'size'        => 150,
		'default'     => FALSE,
		'description' => 'Load the latest CDN build instead of the stable build for the user UI app loader.',
	] );

	add_settings_field( 'ca_extra_frame_ancestors', 'Extra frame ancestors', 'ca_create_option_callback', 'ca-create-settings', 'ca_create_section', [
		'id'          => 'ca_extra_frame_ancestors',
		'size'        => 150,
		'default'     => '',
		'description' => 'Additional origins allowed to embed this site in an iframe, space-separated (e.g. https://office.hk1913.de). The backoffice URL above is always allowed.',
	] );


	?>
  <div class="wrap">
    <h1>CircuitAuction Settings</h1>
    <form method="post" action="options.php">
		<?php
		settings_fields( 'ca_create_options_group' );
		do_settings_sections( 'ca-create-settings' );
		submit_button();
		?>
    </form>
  </div>
	<?php
}

/**
 * Render the input field for the settings page.
 *
 * @param $args
 */
function ca_create_option_callback( $args ) {
	// Get the settings option array
	$options = get_option( $args['id'] );

	// Get the value of the specified setting, if available, or use the default value
	$option_value = isset( $options ) ? $options : $args['default'];

	// Render the input field
	echo '<input type="text" name="' . esc_attr( $args['id'] ) . '" value="' . esc_attr( $option_value ) . '" size="' . esc_attr( $args['size'] ) . '" />';
	echo '<p class="description">' . esc_html( $args['description'] ) . '</p>';
}

/**
 * Section callback.
 */
function ca_create_section_callback() {
	echo '<p>CiruitAuction settings. Update the values below and click "Save Changes" to apply your settings.</p>';
}

/**
 * @param $pageId
 *
 * @return string[]|void
 */
function ca_custom_page_info($pageId) {
	switch ( $pageId ) {
		case SERVER_WEBSITE_PAGES_FORGOT_PASSWORD:
			return [
				'title' => 'Forgot Password',
				'path'  => 'forgot-password',
				'id'    => SERVER_WEBSITE_PAGES_FORGOT_PASSWORD,
			];
		case SERVER_WEBSITE_PAGES_LOGIN:
			return [
				'title' => 'Sign in to your account',
				'path'  => 'login',
				'id'    => SERVER_WEBSITE_PAGES_LOGIN,
			];
		case SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT:
			return [
				'title' => 'My Account',
				'path'  => 'my-account',
				'id'    => SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT,
			];
		case SERVER_WEBSITE_PAGES_MY_BIDS:
			return [
				'title' => 'My Bids & Bidding Limits',
				'path'  => 'my-bids',
				'id'    => SERVER_WEBSITE_PAGES_MY_BIDS,
			];
		case SERVER_WEBSITE_PAGES_TERMS:
			return [
				'title' => 'Terms of Service',
				'path'  => 'terms',
			];
		case SERVER_WEBSITE_PAGES_CONDITIONS:
			return [
				'title' => 'Conditions of Sale',
				'path'  => 'conditions',
			];
		case SERVER_WEBSITE_PAGES_REGISTER:
			return [
				'title' => 'Create an Account',
				'path'  => 'register',
				'id'    => SERVER_WEBSITE_PAGES_REGISTER,
			];
		case SERVER_WEBSITE_PAGES_FAVORITES:
			return [
				'title' => 'My Favorites',
				'path'  => 'my-favorites',
				'id'    => SERVER_WEBSITE_PAGES_FAVORITES,
			];
		case SERVER_WEBSITE_PAGES_INTERESTS:
			return [
				'title' => 'My Interests',
				'path'  => 'my-interests',
				'id'    => 'my-interests',
			];
		case SERVER_WEBSITE_PAGES_SALES_LIST:
			return [
				'title' => 'Sales Archive',
				'path'  => 'sales-archive',
				'id'    => SERVER_WEBSITE_PAGES_SALES_LIST,
			];
		case SERVER_WEBSITE_PAGES_PRICES_REALIZED:
			return [
				'title' => 'Prices Realized',
				'path'  => 'prices-realized',
			];
		case SERVER_WEBSITE_PAGES_SALE:
			return [
				'title' => 'Sale',
				'path'  => 'sale',
                // Default search all sales.
                'id'    => SERVER_WEBSITE_PAGES_SALE,
			];
		case SERVER_WEBSITE_PAGES_SUBSCRIPTION_MAGAZINE:
			return [
				'title' => 'Subscription Magazine',
				'path'  => 'subscription-magazine',
				'id'    => SERVER_WEBSITE_PAGES_SUBSCRIPTION_MAGAZINE,
			];
		case SERVER_WEBSITE_PAGES_BILLING:
			return [
				'title' => 'Billing History',
				'path'  => 'billing',
				'id'    => SERVER_WEBSITE_PAGES_BILLING,
			];
		case SERVER_WEBSITE_PAGES_ITEM:
			return [
				'title' => 'Item',
				'path'  => 'item',
			];

		default:
			return [];
	}
}

/**
 * Get all pages that should exist for this plugin version
 */
function ca_get_all_plugin_pages() {
	return [
		SERVER_WEBSITE_PAGES_FORGOT_PASSWORD,
		SERVER_WEBSITE_PAGES_LOGIN,
		SERVER_WEBSITE_PAGES_EMBED_MY_ACCOUNT,
		SERVER_WEBSITE_PAGES_MY_BIDS,
		SERVER_WEBSITE_PAGES_REGISTER,
		SERVER_WEBSITE_PAGES_FAVORITES,
		SERVER_WEBSITE_PAGES_INTERESTS,
		SERVER_WEBSITE_PAGES_SALES_LIST,
		SERVER_WEBSITE_PAGES_PRICES_REALIZED,
		SERVER_WEBSITE_PAGES_SALE,
		SERVER_WEBSITE_PAGES_SUBSCRIPTION_MAGAZINE,
		SERVER_WEBSITE_PAGES_BILLING,
		SERVER_WEBSITE_PAGES_ITEM,
	];
}

/**
 * Find an existing CA-created page by base slug, optionally filtered by language.
 *
 * Looks for both the base slug (default-language form) and the language-suffixed
 * form ('login-en'). With $lang given, returns the matching translation.
 * Legacy fallback: a slug-matching page with no language assigned is adopted as
 * the default-language post.
 */
function ca_find_page_in_lang($base_path, $lang = null) {
	$slugs = [$base_path];
	if ($lang) {
		$slugs[] = ca_slug_for_lang($base_path, $lang);
	}
	$slugs = array_unique($slugs);

	foreach ($slugs as $slug) {
		$posts = get_posts([
			'name'             => $slug,
			'post_type'        => 'page',
			'post_status'      => ['publish', 'pending', 'draft', 'private'],
			'posts_per_page'   => -1,
			'suppress_filters' => true,
		]);
		if (empty($posts)) {
			continue;
		}
		if ($lang === null || !function_exists('pll_get_post_language')) {
			return $posts[0];
		}
		$default_lang = function_exists('pll_default_language') ? pll_default_language() : null;
		foreach ($posts as $p) {
			$post_lang = pll_get_post_language($p->ID);
			if ($post_lang === $lang) {
				return $p;
			}
			// Legacy fallback: page exists without a language assigned — treat it as
			// the default-language post and assign it now.
			if (!$post_lang && $lang === $default_lang && function_exists('pll_set_post_language')) {
				pll_set_post_language($p->ID, $lang);
				return $p;
			}
		}
	}
	return null;
}

/**
 * Migration: fix CA pages that were created (by an earlier version of this
 * plugin) with duplicate slugs across languages. For each known CA page, rename
 * any non-default-language translation whose post_name still equals the base
 * slug to "{base}-{lang}", so WP's get_page_by_path() resolves URLs to the
 * right page.
 */
function ca_fix_duplicate_ca_page_slugs() {
	if (!function_exists('pll_languages_list') || !function_exists('pll_get_post_language') || !function_exists('pll_default_language')) {
		return 0;
	}
	$default = pll_default_language();
	$languages = pll_languages_list();
	$fixed = 0;

	foreach (ca_get_all_plugin_pages() as $page_constant) {
		$info = ca_custom_page_info($page_constant);
		if (empty($info['path'])) {
			continue;
		}
		$base = $info['path'];

		$posts = get_posts([
			'name'             => $base,
			'post_type'        => 'page',
			'post_status'      => ['publish', 'pending', 'draft', 'private'],
			'posts_per_page'   => -1,
			'suppress_filters' => true,
		]);
		foreach ($posts as $p) {
			$post_lang = pll_get_post_language($p->ID);
			if (!$post_lang || $post_lang === $default || !in_array($post_lang, $languages, true)) {
				continue;
			}
			$new_slug = $base . '-' . $post_lang;
			wp_update_post([
				'ID'        => $p->ID,
				'post_name' => $new_slug,
			]);
			error_log('Renamed CA page #' . $p->ID . ' from "' . $base . '" to "' . $new_slug . '" (lang=' . $post_lang . ')');
			$fixed++;
		}
	}
	return $fixed;
}

/**
 * Compute the slug to use for a CA page in a given language. Default language
 * keeps the base slug ('login'); non-default languages get a "-{lang}" suffix
 * ('login-en'). Free Polylang doesn't support the same slug across languages
 * (Pro's "Translate URL slugs" would), and duplicate slugs cause WP's
 * get_page_by_path() — which is not language-aware — to always pick the same
 * post and trigger a Polylang canonical-URL redirect.
 */
function ca_slug_for_lang($base_slug, $lang) {
	if (!$lang || !function_exists('pll_default_language')) {
		return $base_slug;
	}
	$default = pll_default_language();
	return ($lang === $default) ? $base_slug : $base_slug . '-' . $lang;
}

/**
 * Insert a CA page in a given language. Uses ca_slug_for_lang() to avoid
 * cross-language slug collisions.
 */
function ca_insert_ca_page($page_info, $lang = null) {
	$desired_slug = ca_slug_for_lang($page_info['path'], $lang);

	$template = isset($page_info['template']) ? $page_info['template'] : 'pages-elm.php';
	$page_id = wp_insert_post([
		'post_title'     => $page_info['title'],
		'post_name'      => $desired_slug,
		'post_content'   => !empty($page_info['id'])
			? '<div id="' . esc_attr($page_info['id']) . '" class="circuit-user-ui"></div>'
			: '',
		'post_status'    => 'publish',
		'post_type'      => 'page',
		'post_author'    => 1,
		'comment_status' => 'closed',
		'ping_status'    => 'closed',
		'page_template'  => $template,
	]);

	if (is_wp_error($page_id) || !$page_id) {
		error_log('Failed to create page: ' . $page_info['title'] . ($lang ? " [{$lang}]" : ''));
		return null;
	}

	if (function_exists('pll_set_post_language') && $lang) {
		pll_set_post_language($page_id, $lang);
	}

	error_log('Created page: ' . $page_info['title'] . ($lang ? " [{$lang}]" : '') . ' slug=' . $desired_slug . ' ID:' . $page_id);
	return $page_id;
}

/**
 * Ensure the page has the expected elm-mount <div>. Returns true if updated.
 */
function ca_update_page_div($existing_page, $div_id) {
	if (strpos($existing_page->post_content, 'id="' . esc_attr($div_id) . '"') !== false) {
		return false;
	}
	$expected = '<div id="' . esc_attr($div_id) . '" class="circuit-user-ui"></div>';
	$new_content = trim($existing_page->post_content) === ''
		? $expected
		: $expected . "\n\n" . $existing_page->post_content;
	wp_update_post([
		'ID'           => $existing_page->ID,
		'post_content' => $new_content,
	]);
	error_log('Updated page #' . $existing_page->ID . ' with div: ' . $div_id);
	return true;
}

/**
 * Create a single page (one per Polylang language when active) if missing, or
 * update its content if needed. Links all per-language variants as Polylang
 * translations so the language switcher follows the page across locales.
 *
 * @param string $page_constant The page constant identifier
 * @param bool $update_if_exists Whether to add the elm mount div to existing pages that don't have it
 * @return bool|string Returns true if a page was created, 'updated' if existing content was patched, false otherwise
 */
function ca_create_single_page($page_constant, $update_if_exists = false) {
	$pageInfo = ca_custom_page_info($page_constant);
	if (empty($pageInfo)) {
		return false;
	}

	$polylang_active = function_exists('pll_languages_list');
	$languages = $polylang_active ? pll_languages_list() : [];
	// When Polylang isn't active, operate on a single "no language" pass.
	if (empty($languages)) {
		$languages = [null];
	}

	$ids_by_lang = [];
	$created_any = false;
	$updated_any = false;

	foreach ($languages as $lang) {
		$existing = ca_find_page_in_lang($pageInfo['path'], $lang);
		if ($existing) {
			$ids_by_lang[$lang ?: '_'] = $existing->ID;
			if ($update_if_exists && !empty($pageInfo['id']) && ca_update_page_div($existing, $pageInfo['id'])) {
				$updated_any = true;
			}
			continue;
		}
		$new_id = ca_insert_ca_page($pageInfo, $lang);
		if ($new_id) {
			$ids_by_lang[$lang ?: '_'] = $new_id;
			$created_any = true;
		}
	}

	// Link all per-language variants as Polylang translations so the language
	// switcher can hop between them.
	if ($polylang_active && count($ids_by_lang) > 1 && function_exists('pll_save_post_translations')) {
		pll_save_post_translations($ids_by_lang);
	}

	if ($created_any) {
		return true;
	}
	if ($updated_any) {
		return 'updated';
	}
	return false;
}

/**
 * Create all plugin pages and optionally update existing ones
 *
 * @param bool $update_if_exists Whether to update existing pages that are missing the required div
 * @return array Array with 'created' and 'updated' counts
 */
function ca_create_custom_pages($update_if_exists = false) {
	$pages = ca_get_all_plugin_pages();
	$created_count = 0;
	$updated_count = 0;

	foreach ($pages as $page) {
		$result = ca_create_single_page($page, $update_if_exists);
		if ($result === true) {
			$created_count++;
		} elseif ($result === 'updated') {
			$updated_count++;
		}
	}

	return ['created' => $created_count, 'updated' => $updated_count];
}

/**
 * Update existing pages to add the div with proper ID if missing
 * This function now uses ca_create_custom_pages() with update flag
 *
 * @return int Number of pages updated
 */
function ca_update_existing_pages_content() {
	$result = ca_create_custom_pages(true);
	return $result['updated'];
}

/**
 * Check plugin version and run updates if needed
 */
function ca_check_plugin_version() {
	$current_version = get_option('ca_plugin_version', '0');

	// If no version stored or version is different, run updates
//	$current_version = '1.7';
	if (version_compare($current_version, CA_PLUGIN_VERSION, '<')) {
		ca_run_plugin_updates($current_version);
		update_option('ca_plugin_version', CA_PLUGIN_VERSION);
	}
}

/**
 * Run plugin updates on version change
 * Automatically ensures all pages exist and are properly configured on every version update
 *
 * @param string $from_version The previous version being upgraded from
 */
function ca_run_plugin_updates($from_version = '0') {
	// Force update all pages if upgrading from version below 2.0.9
	$force_update = version_compare($from_version, '2.0.9', '<');

	// One-time fix for installs that have non-default-language CA pages sharing
	// the default-language slug (caused by an earlier per-language migration).
	// Rename them to "{base}-{lang}" so WP's get_page_by_path() returns the
	// right post per URL and Polylang stops issuing canonical redirects.
	if (version_compare($from_version, '2.0.36', '<')) {
		$renamed = ca_fix_duplicate_ca_page_slugs();
		if ($renamed > 0) {
			error_log("CircuitAuction migration: renamed {$renamed} duplicate-slug CA page(s).");
		}
	}

	// On any version change, ensure all pages exist and are properly updated.
	// Creates missing per-language translations and links them.
	$result = ca_create_custom_pages($force_update);

	if ($result['created'] > 0 || $result['updated'] > 0) {
		error_log(sprintf(
			'CircuitAuction plugin update: %d page(s) created, %d page(s) updated (from version %s, force_update: %s)',
			$result['created'],
			$result['updated'],
			$from_version,
			$force_update ? 'true' : 'false'
		));
	}
}

// Run version check on plugin load
add_action('init', 'ca_check_plugin_version', 20);

/**
 * Flush rewrite rules if needed (one-time after code update)
 */
function ca_maybe_flush_rewrite_rules() {
	if (!get_option('ca_rewrite_rules_flushed_v5')) {
		flush_rewrite_rules();
		update_option('ca_rewrite_rules_flushed_v5', true);
		error_log('CircuitAuction: Rewrite rules flushed');
	}
}
add_action('init', 'ca_maybe_flush_rewrite_rules', 999);

// Also run on activation for new installations
register_activation_hook(__FILE__, function() {
	flush_rewrite_rules();
});

// Clean up version option on deactivation
function ca_cleanup_plugin_options() {
	delete_option('ca_plugin_version');
	// Remove the old option if it exists
	delete_option('ca_custom_pages_created');
}
register_deactivation_hook(__FILE__, 'ca_cleanup_plugin_options');

/**
 * Register rewrite rules for a single CA slug using the ca_page query var.
 * No WordPress page is required — the plugin serves the React div directly.
 *
 * @param string $slug      URL slug (e.g. 'sale', 'item', 'prices-realized').
 * @param string $query_var ID query var ('sale_id' or 'item_id'), or '' for none.
 */
function ca_register_slug_rewrite_rules( $slug, $query_var = '' ) {
	$s   = preg_quote( $slug, '#' );
	$qv2 = $query_var ? "&{$query_var}=\$matches[2]" : '';
	$qv1 = $query_var ? "&{$query_var}=\$matches[1]" : '';

	// /{lang}/{slug}/123/title/  and  /{lang}/{slug}/123/
	add_rewrite_rule( "^([a-z]{2})/{$s}/([^/]*)/[^/]*/?", "index.php?ca_page={$slug}{$qv2}", 'top' );
	add_rewrite_rule( "^([a-z]{2})/{$s}/([^/]*)/?",       "index.php?ca_page={$slug}{$qv2}", 'top' );
	// /{lang}/{slug}/
	add_rewrite_rule( "^([a-z]{2})/{$s}/?$",               "index.php?ca_page={$slug}",       'top' );
	// /{slug}/123/title/  and  /{slug}/123/
	add_rewrite_rule( "^{$s}/([^/]*)/[^/]*/?",             "index.php?ca_page={$slug}{$qv1}", 'top' );
	add_rewrite_rule( "^{$s}/([^/]*)/?",                   "index.php?ca_page={$slug}{$qv1}", 'top' );
	// /{slug}/
	add_rewrite_rule( "^{$s}/?$",                          "index.php?ca_page={$slug}",       'top' );
}

/**
 * Register CA rewrite rules.
 * Uses ca_page query var — no WordPress pages or Polylang translations required.
 */
function ca_rewrite_rules() {
	ca_register_slug_rewrite_rules( 'sale',            'sale_id' );
	ca_register_slug_rewrite_rules( 'item',            'item_id' );
	ca_register_slug_rewrite_rules( 'prices-realized', 'sale_id' );

	// Standalone live-app endpoints (full HTML, no WP theme).
	add_rewrite_rule( '^live/?$',     'index.php?ca_page=live',     'top' );
	add_rewrite_rule( '^testlive/?$', 'index.php?ca_page=testlive', 'top' );

	if ( get_option( 'ca_log_api_requests', FALSE ) ) {
		ca_set_custom_message( 'CA Debug: Added rewrite rules' );
	}
}

add_action( 'init', 'ca_rewrite_rules', 10, 0 );

/**
 * Fallback URL parser for CA pages.
 *
 * Polylang's directory mode (e.g. /de/, /en/) rewrites the rule set in ways
 * that can prevent our `^([a-z]{2})/{slug}/{id}` rules from matching, so the
 * /de/item/123/ URL never sets ca_page. This handler runs after Polylang has
 * resolved the language, inspects the raw request path, and sets the query
 * vars manually when the rewrite engine missed. Idempotent: skips when
 * ca_page is already set (i.e. the rewrite rule already matched).
 */
add_action( 'parse_request', function ( $wp ) {
	if ( ! empty( $wp->query_vars['ca_page'] ) ) {
		return;
	}

	$path = isset( $wp->request ) ? trim( $wp->request, '/' ) : '';
	if ( '' === $path ) {
		return;
	}

	// Strip a leading 2-letter language prefix (de/, en/, fr/, …).
	if ( preg_match( '#^[a-z]{2}/(.*)$#i', $path, $m ) ) {
		$path = $m[1];
	}

	$slugs = [
		'item'            => 'item_id',
		'sale'            => 'sale_id',
		'prices-realized' => 'sale_id',
	];

	foreach ( $slugs as $slug => $qv ) {
		if ( $path === $slug || 0 === strpos( $path, $slug . '/' ) ) {
			$wp->query_vars['ca_page'] = $slug;
			$rest = trim( substr( $path, strlen( $slug ) ), '/' );
			if ( $rest !== '' ) {
				$parts = explode( '/', $rest );
				if ( ctype_digit( $parts[0] ) ) {
					$wp->query_vars[ $qv ] = $parts[0];
				}
			}
			return;
		}
	}
}, 20 );

/**
 * Register custom query variables.
 */
function ca_register_query_vars( $vars ) {
	$vars[] = 'item_id';
	$vars[] = 'sale_id';
	$vars[] = 'ca_page'; // which CA page type (sale / item / prices-realized)
	return $vars;
}
add_filter( 'query_vars', 'ca_register_query_vars' );

/**
 * When ca_page is set, tell WordPress this is a valid request (not a 404)
 * and mark it as a page context so theme templates behave normally.
 * Also unset WP's own `page` pagination var so the React app can use ?page=N
 * without WordPress trying to paginate a post that has no nextpage markers.
 */
add_action( 'pre_get_posts', function ( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( $query->get( 'ca_page' ) ) {
		$query->is_404 = false;
		$query->is_page = true;
		$query->set( 'page', '' );
	}
} );

/**
 * Load the plugin's React-page template for all CA URLs.
 * This replaces the old WordPress-page + the_content injection approach,
 * so no WP pages or Polylang translations are needed for sale/item/prices-realized.
 */
// Priority PHP_INT_MAX so we win over plugins that also hook template_include
// (e.g. Elementor's Header/Footer template) when ca_page is set.
add_filter( 'template_include', function ( $template ) {
	if ( get_query_var( 'ca_page' ) ) {
		$plugin_template = plugin_dir_path( __FILE__ ) . 'templates/ca-react-page.php';
		if ( file_exists( $plugin_template ) ) {
			return $plugin_template;
		}
	}
	return $template;
}, PHP_INT_MAX );

/**
 * Render the standalone live-app HTML for /live and /testlive and exit.
 *
 * Mirrors the Drupal `server_general_render_live_template()` callback:
 * a full HTML document with `<meta id="circuit-setup" site=... hostname=...>`
 * and the CDN app-loader, served without the WP theme.
 */
function ca_render_live_app() {
	$ca_page = get_query_var( 'ca_page' );
	if ( $ca_page !== 'live' && $ca_page !== 'testlive' ) {
		return;
	}

	$template = plugin_dir_path( __FILE__ ) . 'templates/' . $ca_page . '.php';
	if ( ! file_exists( $template ) ) {
		return;
	}

	$site     = get_option( 'ca_site_short_name', 'backoffice-hk-eu' );
	$hostname = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' );

	status_header( 200 );
	nocache_headers();
	header( 'Content-Type: text/html; charset=utf-8' );

	include $template;
	exit;
}
add_action( 'template_redirect', 'ca_render_live_app', 0 );

/**
 * For CA pages without a language prefix, redirect to the language-prefixed URL.
 *
 * Since the rewrite rules use ca_page (not pagename), Polylang has no page slug
 * to worry about. The only redirect needed is:
 *   /sale/123  →  /de/sale/123  (prepend current Polylang language)
 *
 * URLs that already have a language prefix are served directly — no redirect.
 * Runs at priority 0 to fire before any other template_redirect hooks.
 */
function ca_language_redirects() {
	// Only act on CA pages and when Polylang is active.
	$ca_page = get_query_var( 'ca_page' );
	if ( ! $ca_page ) {
		return;
	}
	// Standalone live-app endpoints are not language-prefixed.
	if ( $ca_page === 'live' || $ca_page === 'testlive' ) {
		return;
	}
	if ( ! function_exists( 'pll_languages_list' ) ) {
		return;
	}
	$languages = pll_languages_list();
	if ( empty( $languages ) ) {
		return;
	}

	$request_uri = $_SERVER['REQUEST_URI'];
	$path        = trim( parse_url( $request_uri, PHP_URL_PATH ), '/' );
	$qs          = parse_url( $request_uri, PHP_URL_QUERY );
	$qs_suffix   = $qs ? '?' . $qs : '';

	// Strip WordPress subdirectory prefix.
	$home_path = trim( parse_url( home_url(), PHP_URL_PATH ), '/' );
	if ( $home_path !== '' && strpos( $path, $home_path . '/' ) === 0 ) {
		$path = trim( substr( $path, strlen( $home_path ) ), '/' );
	}

	// Already has a language prefix — serve it as-is.
	foreach ( $languages as $l ) {
		if ( $path === $l || strpos( $path, $l . '/' ) === 0 ) {
			return;
		}
	}

	// No language prefix — redirect to the current/default language version.
	$lang = ( function_exists( 'pll_current_language' ) ? pll_current_language() : '' )
	     ?: ( function_exists( 'pll_default_language' ) ? pll_default_language() : $languages[0] );

	$redirect = rtrim( home_url( '/' . $lang . '/' . $path ), '/' ) . '/' . $qs_suffix;

	// Safety: don't redirect if the computed path equals the current path
	// (e.g. Polylang "hide default language prefix" where the default lang has no prefix).
	$rpath = trim( parse_url( $redirect, PHP_URL_PATH ), '/' );
	if ( $home_path !== '' && strpos( $rpath, $home_path . '/' ) === 0 ) {
		$rpath = trim( substr( $rpath, strlen( $home_path ) ), '/' );
	}
	if ( $rpath === $path ) {
		return;
	}

	wp_redirect( $redirect, 301 );
	exit;
}
add_action( 'template_redirect', 'ca_language_redirects', 0 );

/**
 * Allow the backoffice to embed the site in an iframe.
 *
 * X-Frame-Options can only express SAMEORIGIN/DENY, so it is removed and
 * replaced with a CSP frame-ancestors directive whitelisting the backoffice
 * origin (from ca_bo_base_url), the Circuit serverless config service and
 * EU bid server (live/test), plus any origins in ca_extra_frame_ancestors
 * (space-separated). Hooked on send_headers for regular frontend responses
 * and on template_redirect at -1 so it also runs before ca_render_live_app
 * exits. Admin and login screens keep the WP core SAMEORIGIN protection.
 */
function ca_send_frame_headers() {
	if ( headers_sent() ) {
		return;
	}

	$ancestors = [ "'self'" ];

	$bo = wp_parse_url( get_option( 'ca_bo_base_url', '' ) );
	if ( ! empty( $bo['host'] ) ) {
		$origin = ( $bo['scheme'] ?? 'https' ) . '://' . $bo['host'];
		if ( ! empty( $bo['port'] ) ) {
			$origin .= ':' . $bo['port'];
		}
		$ancestors[] = $origin;
	}

	// Circuit serverless config service — always allowed, live and test.
	$ancestors[] = 'https://live-serverless.circuit.auction';
	$ancestors[] = 'https://test-serverless.circuit.auction';

	// Circuit EU bid server — always allowed, live and test.
	$ancestors[] = 'https://live-bids-eu.circuitauction.com';
	$ancestors[] = 'https://test-bids-eu.circuitauction.com';

	$extra = trim( (string) get_option( 'ca_extra_frame_ancestors', '' ) );
	if ( $extra !== '' ) {
		$ancestors = array_merge( $ancestors, preg_split( '/\s+/', $extra ) );
	}

	header_remove( 'X-Frame-Options' );
	header( 'Content-Security-Policy: frame-ancestors ' . implode( ' ', array_unique( $ancestors ) ) );
}
add_action( 'send_headers', 'ca_send_frame_headers', 999 );
add_action( 'template_redirect', 'ca_send_frame_headers', -1 );

/**
 * Translate the language-switcher URL for CA pages.
 *
 * Polylang's switcher only knows how to translate real posts/pages, so on a
 * CA URL like /en/item/2044504/388-auktion---/ it falls back to the language
 * home. We swap the leading language segment to the target language and drop
 * the (per-language) title slug, keeping the id so the elm app renders the
 * same item/sale in the new language.
 *
 * Filter signature: ($url, $language_slug).
 */
add_filter( 'pll_translation_url', function ( $url, $lang ) {
	$ca_page = get_query_var( 'ca_page' );
	if ( ! $ca_page || $ca_page === 'live' || $ca_page === 'testlive' ) {
		return $url;
	}

	// Build {slug}/{id}/ from the current query vars.
	$slug_map = [
		'item'            => 'item_id',
		'sale'            => 'sale_id',
		'prices-realized' => 'sale_id',
	];
	if ( ! isset( $slug_map[ $ca_page ] ) ) {
		return $url;
	}
	$id = get_query_var( $slug_map[ $ca_page ], '' );

	$path = $ca_page . ( $id !== '' ? '/' . $id . '/' : '/' );
	return home_url( '/' . $lang . '/' . $path );
}, 10, 2 );

// sale / item / prices-realized content is now rendered by
// templates/ca-react-page.php via the template_include filter above.

/**
 * Load js for elm app.
 *
 * Also wires up a client-side failure banner — see ca_cdn_failure_banner_js()
 * and the script_loader_tag filter below.
 */
function ca_enqueue_load() {
	// Load in footer to ensure DOM is ready before the React app initializes.
	$cdn_channel = get_option( 'ca_use_latest_cdn', FALSE ) ? 'latest' : 'stable';
	wp_enqueue_script( 'server_website_pages_react', 'https://cdn.circuitauction.com/' . $cdn_channel . '/user-ui/app-loader.js', array( 'jquery' ), false, true );
	// Inline the banner helper just before the CDN script so it exists when
	// the script tag's onerror fires.
	wp_add_inline_script( 'server_website_pages_react', ca_cdn_failure_banner_js(), 'before' );
}

add_action( 'wp_enqueue_scripts', 'ca_enqueue_load' );

/**
 * JS helper that renders a fixed banner if the CDN asset fails to load.
 */
function ca_cdn_failure_banner_js() {
	return "window.caShowCdnError=function(msg){"
		. "if(document.getElementById('ca-cdn-error'))return;"
		. "var d=document.createElement('div');"
		. "d.id='ca-cdn-error';"
		. "d.setAttribute('role','alert');"
		. "d.style.cssText='position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#b91c1c;color:#fff;font:14px/1.4 system-ui,sans-serif;padding:10px 16px;text-align:center;box-shadow:0 2px 6px rgba(0,0,0,.3);';"
		. "d.textContent=msg||'Auction app failed to load (CDN unreachable). Please refresh or check your connection.';"
		. "(document.body||document.documentElement).appendChild(d);"
		. "};";
}

/**
 * Attach onerror to the CDN script tag so a failed load triggers the banner.
 */
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( 'server_website_pages_react' !== $handle ) {
		return $tag;
	}
	return str_replace(
		'<script ',
		'<script onerror="window.caShowCdnError && window.caShowCdnError();" ',
		$tag
	);
}, 10, 2 );

/**
 * GlitchTip DSN configured for this site. Empty string disables error reporting.
 *
 * Override per environment with `update_option('ca_glitchtip_dsn', '...')`,
 * or set to empty string to suppress the meta tag.
 */
function ca_glitchtip_dsn() {
	return (string) get_option(
		'ca_glitchtip_dsn',
		'https://5505c8b31c5a4a579e6ddd18e37ee9a2@glitchtip.circuit.auction/2'
	);
}

/**
 * Build the `<meta id="error-monitoring">` tag read by the CDN-loaded app to
 * init GlitchTip/Sentry. Returns '' when no DSN is configured.
 *
 * @param string $site     The short site name (e.g. 'backoffice-hk-eu').
 * @param string $hostname The BO base URL / hostname.
 */
function ca_error_monitoring_meta_tag( $site, $hostname ) {
	$dsn = ca_glitchtip_dsn();
	if ( '' === $dsn ) {
		return '';
	}
	return sprintf(
		'<meta id="error-monitoring" dsn="%s" environment="%s">',
		esc_attr( $dsn ),
		esc_attr( $site . '-' . $hostname )
	);
}

/**
 * Sentry browser SDK CDN tag — loaded so the CDN-bundled app can call
 * Sentry.init() with the DSN from the error-monitoring meta tag.
 *
 * Returns '' when error monitoring is disabled. Override the version with
 * `update_option('ca_sentry_cdn_version', '8.x.y')`.
 */
function ca_sentry_cdn_script_tag() {
	if ( '' === ca_glitchtip_dsn() ) {
		return '';
	}
	$version = (string) get_option( 'ca_sentry_cdn_version', '8.50.0' );
	return sprintf(
		'<script src="https://browser.sentry-cdn.com/%s/bundle.min.js" crossorigin="anonymous"></script>',
		esc_attr( $version )
	);
}

/**
 * Add widget manager to all pages, this is required by the elm app.
 */
function ca_add_circuit_div() {
	// Add widget manager required for elm blocks on all pages.-->
	if ( get_option( 'ca_add_user_block_to_header', FALSE ) ) {
		// React user menu. SERVER_WEBSITE_PAGES_USER_BLOCK
		echo '<div id="user-block" class="circuit-user-ui"></div>';
	}
	if ( get_option( 'ca_add_circuit_settings_div', TRUE ) ) {
		// React div settings.
		$hostname = get_option( 'ca_bo_base_url', 'https://backoffice.ddev.site' );
        $site = get_option( 'ca_site_short_name', 'backoffice-hk-eu' );
		$current_lang = 'en';
		if ( function_exists('pll_current_language') ) {
            $current_lang = pll_current_language();
		}
        if (get_option( 'ca_local_serverless', FALSE )) {
            echo '<div id="circuit-setup" site="' . $site . '" hostname="' . $hostname . '" language="' . $current_lang . '" serverless="local" debug="1"></div>';
        }
        else {
            if (get_option( 'ca_circuit_debug', FALSE )) {
                echo '<div id="circuit-setup" site="' . $site . '" hostname="' . $hostname . '" language="' . $current_lang . '" debug="1"></div>';
            }
            else {
                echo '<div id="circuit-setup" site="' . $site . '" hostname="' . $hostname . '" language="' . $current_lang . '"></div>';
            }
        }

		// GlitchTip error monitoring (picked up by the CDN-loaded app).
		echo ca_error_monitoring_meta_tag( $site, $hostname );
		echo ca_sentry_cdn_script_tag();
	}
}

add_action( 'wp_head', 'ca_add_circuit_div' );

// Widget class removed - use Gutenberg block instead (includes/user-block.php)

add_action( 'admin_notices', function () {
	$class   = 'notice notice-success'; // CSS class: notice, notice-info, notice-warning, notice-success, notice-error
	$message = __( 'Settings saved successfully.', 'text-domain' );

	printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
} );

function ca_set_custom_message( $message, $type = 'success' ) {
	$_SESSION['custom_message'] = [ 'message' => $message, 'type' => $type ];
}

add_action( 'wp_footer', 'ca_display_custom_message' );
function ca_display_custom_message() {
	if ( isset( $_SESSION['custom_message'] ) ) {
		$message_data = $_SESSION['custom_message'];

		// Inline CSS for the message box
		$css = "
            <style>
                .custom-message {
                    position: fixed;
                    top: 30px;
                    left: 50%;
                    transform: translateX(-50%);
                    z-index: 9999;
                    border: 1px solid #ddd;
                    padding: 10px 20px;
                    border-radius: 5px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    background-color: #f7f7f7;
                    color: #333;
                    width: auto;
                    max-width: 90%;
                    box-sizing: border-box;
                }
                .custom-message.success { border-color: #4CAF50; background-color: #edf7ed; color: #4CAF50; }
                .custom-message.error { border-color: #F44336; background-color: #fdecea; color: #F44336; }
                .custom-message.info { border-color: #2196F3; background-color: #e8f4fd; color: #2196F3; }
                .custom-message.warning { border-color: #ff9800; background-color: #fff4e5; color: #ff9800; }
            </style>
        ";

		// Allowed tags
		$allowed_tags = '<a>';

		// Message HTML
		$message_html = sprintf( '<div class="custom-message %1$s">%2$s</div>', esc_attr( $message_data['type'] ), strip_tags( $message_data['message'], $allowed_tags ) );

		// Echo CSS and message
		echo $css . $message_html;

		unset( $_SESSION['custom_message'] );
	}
}

/**
 * Debug helper function that uses WordPress native tools
 *
 * @param mixed $data The data to debug
 * @param string $title Optional title for the debug section
 * @param bool $print Whether to print to screen (true) or log to debug.log (false)
 */
function ca_debug($data, $title = '', $print = true) {
  if (!defined('WP_DEBUG') || !WP_DEBUG) {
    return;
  }

  $output = '';

  // Add backtrace information
  $trace = wp_debug_backtrace_summary();

  // Format the debug output
  if ($title) {
    $output .= "=== {$title} ===\n";
  }

  $output .= "Called from: {$trace}\n";
  $output .= "Time: " . current_time('mysql') . "\n";
  $output .= "Data:\n";
  $output .= print_r($data, true);
  $output .= "\n=================\n";

  if ($print) {
    echo '<pre style="background: #f5f5f5; padding: 15px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; overflow: auto;">';
    echo esc_html($output);
    echo '</pre>';
  } else {
    error_log($output);
  }
}
