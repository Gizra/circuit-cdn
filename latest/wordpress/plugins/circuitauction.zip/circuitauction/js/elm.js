/**
 * @file
 */
jQuery(document).ready(function ($) {

    var accessToken = localStorage.getItem('bs_access_token');
    var onLogin = function () {
        $('.form-item-my-favorites select').prop("disabled", false);
        // Set the value of the hidden input field with the access token.
        var favoriteElement = document.getElementById('access_token_field');
        if (favoriteElement) {
            favoriteElement.value = accessToken;
        }
    };
    var onReady = function () {
        $('.form-item-my-favorites select').prop("disabled", true);
    }

    if (accessToken != null) {
        onLogin();
    }
    else {
        onReady();
    }

    // We can have multiple Elm apps in the same page.
    var onLoginDone = false;

    function fetchData(dataContainer) {
        var page = dataContainer.data('page');
        var saleUuid = dataContainer.data('saleUuid');
        var language = dataContainer.data('language');
        var itemUuid = dataContainer.data('itemUuid');
        var baseHostUrl = dataContainer.data('baseHostUrl');
        var backendUrl = dataContainer.data('backendUrl');
        var circuitBidUrl = dataContainer.data('circuitBidUrl');
        var currency = dataContainer.data('currency');
        var siteShortName = dataContainer.data('siteShortName');

        return {
            page: page,
            saleUuid: saleUuid,
            language: language,
            itemUuid: itemUuid,
            baseHostUrl: baseHostUrl,
            backendUrl: backendUrl,
            circuitBidUrl: circuitBidUrl,
            currency: currency,
            siteShortName: siteShortName,
        };
    }

    var elmApps = [];
    // Push settings for elm pages/blocks.
    if (elm_apps_settings != undefined) {
        for (var key in elm_apps_settings) {
            if (elm_apps_settings.hasOwnProperty(key)) {
                elmApps.push(elm_apps_settings[key]);
            }
        }
    }

    $('.data-container').each(function() {
        var data = fetchData($(this));
        elmApps.push(data);
    });

    var initializedElmApps = {};


    // Iterate over the apps.
    elmApps.forEach(function (appSettings) {

        // appName would the unique css ID, e.g. `elm-app-100`.
        var id = appSettings.page;
        if ( appSettings.page == 'item_pre_live_sale' ) {
            id = appSettings.itemUuid;
        }
        var node = document.getElementById(id);

        if (!node) {
            // We haven't found the div, so prevent an error.
            if ( appSettings.page == 'item_pre_live_sale' ) {
                // Only display error for missing item divs.
                console.error('a div with the ID ' + appSettings.itemUuid + ' is missing in the page, thus its Elm cannot be loaded');
            }
            return;
        }

        var $node = $(node);

        if ($node.hasClass('elm-processed')) {
            // Element was already processed.
            return;
        }

        // Mark element as processed, so we won't re-bind to it.
        $node.addClass('elm-processed');

        var page = appSettings.page;

        var elmApp = Elm.Main.embed(node, {
            // Elm's RESTful module expects a stringified object.
            accessToken: accessToken ? JSON.stringify({access_token: accessToken}) : '{}',
            // The current URL, along with query strings.
            hostUrl: window.location.href,
            saleUuid: appSettings.saleUuid,
            itemUuid: appSettings.itemUuid,
            // The base URL.
            baseHostUrl: appSettings.baseHostUrl,
            page: page,
            language: appSettings.language,
            currency: appSettings.currency,
            siteShortName: appSettings.siteShortName,
            backendUrl: appSettings.backendUrl,
            circuitBidUrl: appSettings.circuitBidUrl,
            // Indicate if BO wan't to get the user's credentials.
            bidServerAuthStatusRequiredByBo: !!appSettings.recaptchaSiteKey
        });

        initializedElmApps[appSettings.itemUuid] = elmApp;

        // Inject the expected values to the right port based on the selected page.
        var property
        if (page == 'widget_manager') {
            property = elmApp.ports.widgetIds;
            // Widget IDs are all apps which are not the Widget manager.
            var widgetIds = [];
            elmApps.forEach(function (widgetAppSettings) {
                if (widgetAppSettings.page == 'widget_manager') {
                    return;
                }

                widgetIds.push({'id': widgetAppSettings.itemUuid, 'page': widgetAppSettings.page});
            });
            property.send(widgetIds);
        }

        // Just the login is responsible for settings the access token.
        elmApp.ports.cacheCredentials.subscribe(function (params) {
            // Elm's RESTful module sends a stringified object.
            var credentials = JSON.parse(params[1]);
            localStorage.setItem('bs_access_token', credentials.access_token);
        });

        if (page === 'widget_manager') {

            /**
             * Send Authenticated User (if logged-in) and data to other widgets.
             */
            elmApp.ports.sendUserAndData.subscribe(function (params) {
                // TODO: Add user id to local storage to use in the user_account page
                const encodedUserAndData = JSON.parse(params[0]);
                const widgetIds = params[1];

                widgetIds.forEach(function (widget) {

                    if (!!initializedElmApps[widget] && !!initializedElmApps[widget].ports) {

                        // Send date via ports.
                        if (accessToken != null) {
                            initializedElmApps[widget].ports.getAuthenticatedUserAndData.send(encodedUserAndData);
                        } else {
                            initializedElmApps[widget].ports.getAnonymousUserAndData.send(encodedUserAndData);
                        }
                    }

                });

                if (!onLoginDone && accessToken != null) {
                    onLogin();
                    onLoginDone = true;
                }
            });

            // Pusher integration.
            var pusherConnections = [];
            var pusherConfig = {
                key: appSettings.values.pusher.key,
                cluster: appSettings.values.pusher.cluster
            };

            elmApp.ports.pusherLogout.subscribe(function () {
                pusherConnections.forEach(function (pusher) {
                    pusher.disconnect();
                    pusher = null;
                    pusherConfig = null;
                });
            });

            elmApp.ports.pusherLogin.subscribe(function (config) {

                pusherConnections.forEach(function (pusher) {
                    pusher.disconnect();
                });

                config.channelNames.forEach(function (channelName) {
                    var pusher = new Pusher(pusherConfig.key, {
                        cluster: pusherConfig.cluster,
                        authEndpoint: config.authEndpoint
                    });

                    pusherConnections[channelName] = pusher;

                    pusher.connection.bind('error', function (error) {
                        elmApp.ports.pusherErrors.send({
                            message: error.error.data.message ? error.error.data.message : null,
                            code: error.error.code ? error.error.code : null
                        });
                    });

                    pusher.connection.bind('state_change', function (states) {
                        elmApp.ports.pusherState.send(states.current);
                    });

                    if (!pusher.channel(channelName)) {
                        var channel = pusher.subscribe(channelName);

                        config.eventNames.forEach(function (eventName) {
                            channel.bind(eventName, function (data) {
                                // Add a local timestamp of this specific client.
                                data.clientTimestamp = Date.now();

                                var event = {
                                    eventType: eventName,
                                    data: data
                                };

                                // Uncomment to debug.
                                // console.log(data, eventName);
                                elmApp.ports.pusherIncomingEvents.send(event);

                            });
                        });
                    }
                });
            });
        }
    });


});